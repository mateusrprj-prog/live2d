# Mobile 2D Studio

Editor de personagens 2D e animação para Android (inspirado no fluxo de trabalho de editores
profissionais de rigging). Implementação independente, sem código ou recursos de terceiros proprietários.

## Como gerar o APK (sem PC)
1. Suba para o GitHub: (a) o conteúdo desta pasta inteiro (inclusive `.github`), OU (b) apenas o `.zip` + `.github/workflows/build.yml` (deixe só um `.zip`).
2. GitHub → **Actions** → **Build Android APK** → **Run workflow**.
3. Ao terminar, baixe o artifact **mobile2dstudio-debug-apk** e instale o `.apk`.
4. O artifact **gradle-wrapper-files** contém `gradlew` e `gradle/wrapper/`: commite-os para que as
   próximas execuções não precisem gerar o wrapper (o workflow gera sozinho se faltarem).

## Estado atual — Fase 2, Parte D (v0.2.0-D)
Veja `PROJETO_CONTEXTO.md` (contexto completo, roteiro e registro de todas as atualizações).

| Item | Estado |
|---|---|
| Fase 1: arquitetura, canvas GPU, projetos `.v2d`, autosave, Actions | Implementado; validação no aparelho ainda parcial |
| Fase 2-A: modelo v2, transformações, hierarquia (PartTree), histórico | Implementado e agora ligado à UI |
| Fase 2-B: importação PNG/JPEG/ORA/PSD | Importadores implementados; sem teste com arquivos reais do usuário |
| Fase 2-C: textura real, matriz por parte, seleção, mover, histórico e importação SAF | Código implementado; build Android/Actions e teste no POCO pendentes |
| Fase 2-D: nova interface baseada nas referências (workspace em paisagem, docks, árvore e inspetor funcional) | Código implementado; build Android/Actions e teste no POCO pendentes |
| Mesh Editor | Fase 3 |
| Deformadores e parâmetros avançados | Fase 4 |
| Física | Fase 5 |
| Animação, timeline, áudio e lip-sync | Fase 6 |
| Exportação | Fase 7 |

## Limitações conhecidas
- O teste alfa por pixel ainda não faz parte do HitTest; a seleção por retângulo usa limites transformados.
- A primeira decodificação de texturas acontece na thread GL e pode causar uma pausa em documentos pesados.
- Build Android/Gradle, Compose e renderer ainda precisam passar no GitHub Actions e ser testados no aparelho.
- A 2D ainda não possui resize de docks por alça, menu contextual nem reordenação/reparentação por arrasto. Parâmetros/deformadores e timeline pertencem às fases 4 e 6.
- Build Release não está assinado (sem chaves inventadas).
