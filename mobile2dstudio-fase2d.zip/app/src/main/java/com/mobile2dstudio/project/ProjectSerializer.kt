package com.mobile2dstudio.project

import com.mobile2dstudio.geometry.Transform2D
import com.mobile2dstudio.mesh.ArtMesh
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject

/** Converte projeto <-> JSON (conteúdo de project.json dentro do .v2d). */
object ProjectSerializer {

    fun toJson(project: V2dProject): String {
        val root = JSONObject()
        root.put("schemaVersion", CURRENT_SCHEMA)
        root.put("generator", "Mobile 2D Studio")
        root.put("meta", metaToJson(project.meta))
        val parts = JSONArray()
        for (p in project.parts) parts.put(partToJson(p))
        root.put("parts", parts)
        val assets = JSONArray()
        for (a in project.assets) assets.put(assetToJson(a))
        root.put("assets", assets)
        return root.toString()
    }

    /**
     * [assetBytes] resolve o caminho de uma textura (ex.: "textures/ID.png") para os bytes
     * guardados no ZIP; null = recurso ausente (o projeto ainda abre, com a textura marcada ausente).
     */
    fun fromJson(text: String, assetBytes: (String) -> ByteArray? = { null }): V2dProject {
        try {
            val root = migrate(JSONObject(text))
            val meta = metaFromJson(root.getJSONObject("meta"))
            val partsJson = root.getJSONArray("parts")
            val parts = ArrayList<Part>(partsJson.length())
            for (i in 0 until partsJson.length()) parts += partFromJson(partsJson.getJSONObject(i))
            val assets = ArrayList<ImageAsset>()
            val assetsJson = root.optJSONArray("assets")
            if (assetsJson != null) {
                for (i in 0 until assetsJson.length()) {
                    assets += assetFromJson(assetsJson.getJSONObject(i), assetBytes)
                }
            }
            return V2dProject(meta, parts, assets)
        } catch (e: JSONException) {
            throw ProjectFormatException("Arquivo de projeto inválido: ${e.message}", e)
        } catch (e: IllegalArgumentException) {
            throw ProjectFormatException("Arquivo de projeto inválido: ${e.message}", e)
        }
    }

    fun metaFromJson(text: String): ProjectMeta {
        try {
            val root = migrate(JSONObject(text))
            return metaFromJson(root.getJSONObject("meta"))
        } catch (e: JSONException) {
            throw ProjectFormatException("Arquivo de projeto inválido: ${e.message}", e)
        }
    }

    /** Ponto único para migrações entre versões do esquema. */
    private fun migrate(root: JSONObject): JSONObject {
        val version = root.optInt("schemaVersion", -1)
        if (version < 1) throw ProjectFormatException("Projeto sem versão de esquema válida")
        if (version > CURRENT_SCHEMA) {
            throw ProjectFormatException(
                "Projeto criado por uma versão mais nova do app (esquema $version, suportado até $CURRENT_SCHEMA)"
            )
        }
        // Esquema 1 -> 2: partes ganham kind/opacity/transform/textureId e o projeto ganha "assets".
        // Todos esses campos são lidos com valores padrão, então nenhum ajuste no JSON é necessário.
        return root
    }

    private fun metaToJson(m: ProjectMeta): JSONObject {
        val o = JSONObject()
        o.put("id", m.id)
        o.put("name", m.name)
        o.put("createdAt", m.createdAt)
        o.put("modifiedAt", m.modifiedAt)
        o.put("width", m.width)
        o.put("height", m.height)
        o.put("fps", m.fps)
        return o
    }

    private fun metaFromJson(o: JSONObject) = ProjectMeta(
        id = o.getString("id"),
        name = o.getString("name"),
        createdAt = o.getLong("createdAt"),
        modifiedAt = o.getLong("modifiedAt"),
        width = o.getInt("width"),
        height = o.getInt("height"),
        fps = o.getInt("fps")
    )

    private fun partToJson(p: Part): JSONObject {
        val o = JSONObject()
        o.put("id", p.id)
        o.put("name", p.name)
        o.put("parentId", p.parentId ?: JSONObject.NULL)
        o.put("visible", p.visible)
        o.put("locked", p.locked)
        o.put("kind", p.kind.name)
        o.put("opacity", p.opacity.toDouble())
        o.put("textureId", p.textureId ?: JSONObject.NULL)
        val t = JSONObject()
        t.put("x", p.transform.x.toDouble())
        t.put("y", p.transform.y.toDouble())
        t.put("rotationDeg", p.transform.rotationDeg.toDouble())
        t.put("scaleX", p.transform.scaleX.toDouble())
        t.put("scaleY", p.transform.scaleY.toDouble())
        o.put("transform", t)
        val mesh = p.mesh
        if (mesh == null) {
            o.put("mesh", JSONObject.NULL)
        } else {
            val problems = mesh.validate()
            if (problems.isNotEmpty()) {
                throw ProjectFormatException("Malha inválida na parte '${p.name}': ${problems.joinToString("; ")}")
            }
            val m = JSONObject()
            m.put("positions", floatsToJson(mesh.positions))
            m.put("uvs", floatsToJson(mesh.uvs))
            m.put("indices", intsToJson(mesh.indices))
            o.put("mesh", m)
        }
        return o
    }

    private fun partFromJson(o: JSONObject): Part {
        var mesh: ArtMesh? = null
        if (!o.isNull("mesh")) {
            val m = o.getJSONObject("mesh")
            val parsed = ArtMesh(
                positions = jsonToFloats(m.getJSONArray("positions")),
                uvs = jsonToFloats(m.getJSONArray("uvs")),
                indices = jsonToInts(m.getJSONArray("indices"))
            )
            val problems = parsed.validate()
            if (problems.isNotEmpty()) {
                throw ProjectFormatException(
                    "Malha inválida na parte '${o.optString("name")}': ${problems.joinToString("; ")}"
                )
            }
            mesh = parsed
        }
        val kind = when (o.optString("kind", "")) {
            "GROUP" -> PartKind.GROUP
            "MESH" -> PartKind.MESH
            else -> if (mesh != null) PartKind.MESH else PartKind.GROUP
        }
        val tj = o.optJSONObject("transform")
        val transform = if (tj == null) {
            Transform2D.IDENTITY
        } else {
            Transform2D(
                x = tj.optDouble("x", 0.0).toFloat(),
                y = tj.optDouble("y", 0.0).toFloat(),
                rotationDeg = tj.optDouble("rotationDeg", 0.0).toFloat(),
                scaleX = tj.optDouble("scaleX", 1.0).toFloat(),
                scaleY = tj.optDouble("scaleY", 1.0).toFloat()
            )
        }
        if (!transform.isFinite()) {
            throw ProjectFormatException("Transformação inválida na parte '${o.optString("name")}'")
        }
        val opacity = o.optDouble("opacity", 1.0).toFloat()
        if (!opacity.isFinite()) {
            throw ProjectFormatException("Opacidade inválida na parte '${o.optString("name")}'")
        }
        return Part(
            id = o.getString("id"),
            name = o.getString("name"),
            parentId = if (o.isNull("parentId")) null else o.getString("parentId"),
            visible = o.getBoolean("visible"),
            locked = o.getBoolean("locked"),
            mesh = mesh,
            kind = kind,
            opacity = opacity.coerceIn(0f, 1f),
            transform = transform,
            textureId = if (o.isNull("textureId")) null else o.getString("textureId")
        )
    }

    private fun assetToJson(a: ImageAsset): JSONObject {
        val o = JSONObject()
        o.put("id", a.id)
        o.put("name", a.name)
        o.put("width", a.width)
        o.put("height", a.height)
        o.put("format", a.format.name)
        o.put("file", a.entryName())
        return o
    }

    private fun assetFromJson(o: JSONObject, assetBytes: (String) -> ByteArray?): ImageAsset {
        val format = try {
            ImageFormat.valueOf(o.getString("format"))
        } catch (e: IllegalArgumentException) {
            throw ProjectFormatException("Formato de textura desconhecido: ${o.optString("format")}", e)
        }
        val file = o.getString("file")
        return ImageAsset(
            id = o.getString("id"),
            name = o.optString("name", ""),
            width = o.getInt("width"),
            height = o.getInt("height"),
            format = format,
            bytes = assetBytes(file) ?: ByteArray(0)
        )
    }

    private fun floatsToJson(a: FloatArray): JSONArray {
        val j = JSONArray()
        for (v in a) j.put(v.toDouble())
        return j
    }

    private fun intsToJson(a: IntArray): JSONArray {
        val j = JSONArray()
        for (v in a) j.put(v)
        return j
    }

    private fun jsonToFloats(j: JSONArray) = FloatArray(j.length()) { j.getDouble(it).toFloat() }

    private fun jsonToInts(j: JSONArray) = IntArray(j.length()) { j.getInt(it) }
}
