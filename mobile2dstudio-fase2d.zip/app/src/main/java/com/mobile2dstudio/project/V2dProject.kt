package com.mobile2dstudio.project

import com.mobile2dstudio.geometry.Transform2D
import com.mobile2dstudio.mesh.ArtMesh
import com.mobile2dstudio.mesh.MeshGenerator
import java.util.UUID

/** Versão atual do esquema do arquivo .v2d. */
const val CURRENT_SCHEMA = 2

data class ProjectMeta(
    val id: String,
    val name: String,
    val createdAt: Long,
    val modifiedAt: Long,
    val width: Int,
    val height: Int,
    val fps: Int
)

enum class PartKind { GROUP, MESH }

/**
 * Parte do personagem. A ORDEM da lista de partes é a ordem de desenho (primeiro = fundo)
 * e, dentro de um pai, a ordem entre irmãos. Só partes GROUP podem ter filhas.
 * [transform] é local (espaço do pai); a mesh fica em coordenadas locais da parte.
 */
data class Part(
    val id: String,
    val name: String,
    val parentId: String?,
    val visible: Boolean,
    val locked: Boolean,
    val mesh: ArtMesh?,
    val kind: PartKind = if (mesh != null) PartKind.MESH else PartKind.GROUP,
    val opacity: Float = 1f,
    val transform: Transform2D = Transform2D.IDENTITY,
    val textureId: String? = null
)

data class V2dProject(
    val meta: ProjectMeta,
    val parts: List<Part>,
    val assets: List<ImageAsset> = emptyList()
)

/** Estado editável (o que o desfazer/refazer protege). Listas imutáveis compartilham referências. */
data class EditState(val parts: List<Part>, val assets: List<ImageAsset>)

data class ProjectInfo(val meta: ProjectMeta, val sizeBytes: Long)

class ProjectFormatException(message: String, cause: Throwable? = null) : Exception(message, cause)

object ProjectFactory {
    /**
     * Parte de teste com malha em grade 8x8. Sem asset associado, o renderer mostra
     * o padrão de recurso ausente; serve para exercitar a geometria/GPU.
     */
    fun testPart(canvasWidth: Int, canvasHeight: Int, index: Int): Part {
        val size = minOf(canvasWidth, canvasHeight) * 0.4f
        val shift = index * size * 0.15f
        val mesh = MeshGenerator.grid(size, size, 8, 8, -size / 2f + shift, -size / 2f - shift)
        return Part(
            id = UUID.randomUUID().toString(),
            name = "Parte de teste ${index + 1}",
            parentId = null,
            visible = true,
            locked = false,
            mesh = mesh
        )
    }
}
