package com.mobile2dstudio.project

import com.mobile2dstudio.imports.ImportedDocument
import com.mobile2dstudio.imports.LayerImport
import java.io.File
import java.nio.file.AtomicMoveNotSupportedException
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.util.UUID
import java.util.zip.Deflater
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * Armazena projetos como arquivos `.v2d` (ZIP contendo `project.json`) em [dir].
 * Salvamento atômico: grava em arquivo temporário, valida lendo de volta,
 * guarda a versão anterior como `.bak` e só então troca o arquivo final.
 */
class ProjectRepository(
    private val dir: File,
    private val clock: () -> Long = { System.currentTimeMillis() },
    private val logger: (String) -> Unit = {}
) {
    init {
        dir.mkdirs()
    }

    fun create(name: String, width: Int, height: Int, fps: Int): V2dProject {
        require(name.isNotBlank()) { "O nome do projeto não pode ser vazio" }
        require(width in 16..8192 && height in 16..8192) { "Resolução deve estar entre 16 e 8192 px" }
        require(fps in 1..120) { "FPS deve estar entre 1 e 120" }
        val now = clock()
        val meta = ProjectMeta(UUID.randomUUID().toString(), name.trim(), now, now, width, height, fps)
        return save(V2dProject(meta, listOf(ProjectFactory.testPart(width, height, 0))))
    }

    /**
     * Cria um projeto novo com o tamanho do documento importado (mínimo 16 px) e as camadas
     * convertidas em partes/texturas. Devolve o projeto salvo e os avisos da importação.
     */
    fun createFromImport(
        name: String,
        doc: ImportedDocument,
        fps: Int = 24
    ): Pair<V2dProject, List<String>> {
        require(name.isNotBlank()) { "O nome do projeto não pode ser vazio" }
        require(fps in 1..120) { "FPS deve estar entre 1 e 120" }
        val w = doc.width.coerceAtLeast(16)
        val h = doc.height.coerceAtLeast(16)
        require(w <= 8192 && h <= 8192) { "Resolução deve estar entre 16 e 8192 px" }
        val converted = LayerImport.toParts(doc)
        val now = clock()
        val meta = ProjectMeta(UUID.randomUUID().toString(), name.trim(), now, now, w, h, fps)
        val saved = save(V2dProject(meta, converted.parts, converted.assets))
        return saved to converted.warnings
    }

    fun list(): List<ProjectInfo> {
        val files = dir.listFiles { f -> f.isFile && f.name.endsWith(EXT) } ?: return emptyList()
        val out = ArrayList<ProjectInfo>()
        for (f in files) {
            try {
                out += ProjectInfo(ProjectSerializer.metaFromJson(readJson(f)), f.length())
            } catch (e: Exception) {
                logger("Ignorando arquivo ilegível ${f.name}: ${e.message}")
            }
        }
        return out.sortedByDescending { it.meta.modifiedAt }
    }

    fun load(id: String): V2dProject {
        val main = fileFor(id)
        try {
            return readProject(main)
        } catch (e: Exception) {
            logger("Falha ao ler ${main.name}: ${e.message}")
            val bak = backupFor(id)
            if (bak.exists()) {
                try {
                    val recovered = readProject(bak)
                    logger("Projeto $id recuperado do backup")
                    return recovered
                } catch (e2: Exception) {
                    logger("Backup também ilegível: ${e2.message}")
                }
            }
            if (e is ProjectFormatException) throw e
            throw ProjectFormatException("Não foi possível abrir o projeto: ${e.message}", e)
        }
    }

    fun save(project: V2dProject): V2dProject {
        val updated = project.copy(meta = project.meta.copy(modifiedAt = clock()))
        val id = updated.meta.id
        val target = fileFor(id)
        val tmp = File(dir, "$id$EXT.tmp")
        dir.mkdirs()

        val bytes = ProjectSerializer.toJson(updated).toByteArray(Charsets.UTF_8)
        try {
            ZipOutputStream(tmp.outputStream().buffered()).use { zip ->
                // project.json PRIMEIRO: list() só precisa ler o início do arquivo.
                zip.putNextEntry(ZipEntry(ENTRY_NAME))
                zip.write(bytes)
                zip.closeEntry()
                // Texturas já são PNG/JPEG comprimidos: só armazena.
                zip.setLevel(Deflater.NO_COMPRESSION)
                for (asset in updated.assets) {
                    if (asset.isMissing) {
                        logger("Textura ausente não gravada: ${asset.name} (${asset.id})")
                        continue
                    }
                    zip.putNextEntry(ZipEntry(asset.entryName()))
                    zip.write(asset.bytes)
                    zip.closeEntry()
                }
            }
            // Integridade: o que foi gravado precisa ser relido como projeto válido e com as mesmas texturas.
            val reread = readProject(tmp)
            check(reread.parts.size == updated.parts.size) { "Verificação falhou: número de partes difere" }
            for (asset in updated.assets) {
                if (asset.isMissing) continue
                val back = reread.assets.firstOrNull { it.id == asset.id }
                check(back != null && back.bytes.size == asset.bytes.size) {
                    "Verificação falhou: textura ${asset.id} não foi gravada corretamente"
                }
            }

            if (target.exists() && isReadable(target)) {
                Files.copy(target.toPath(), backupFor(id).toPath(), StandardCopyOption.REPLACE_EXISTING)
            }
            try {
                Files.move(
                    tmp.toPath(), target.toPath(),
                    StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING
                )
            } catch (e: AtomicMoveNotSupportedException) {
                Files.move(tmp.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING)
            }
        } finally {
            if (tmp.exists()) tmp.delete()
        }
        return updated
    }

    fun rename(id: String, newName: String): V2dProject {
        require(newName.isNotBlank()) { "O nome do projeto não pode ser vazio" }
        val p = load(id)
        return save(p.copy(meta = p.meta.copy(name = newName.trim())))
    }

    fun duplicate(id: String): V2dProject {
        val p = load(id)
        val now = clock()
        val meta = p.meta.copy(
            id = UUID.randomUUID().toString(),
            name = "${p.meta.name} (cópia)",
            createdAt = now,
            modifiedAt = now
        )
        return save(p.copy(meta = meta))
    }

    fun delete(id: String): Boolean {
        val removed = fileFor(id).delete()
        backupFor(id).delete()
        return removed
    }

    private fun isReadable(f: File): Boolean {
        return try {
            readProject(f)
            true
        } catch (e: Exception) {
            false
        }
    }

    /** Lê project.json e todas as texturas do ZIP. Textura referenciada e ausente vira recurso ausente. */
    private fun readProject(file: File): V2dProject {
        var json: String? = null
        val textures = HashMap<String, ByteArray>()
        var total = 0L
        ZipInputStream(file.inputStream().buffered()).use { zip ->
            var entry = zip.nextEntry
            while (entry != null) {
                val name = entry.name
                if (name == ENTRY_NAME || name.startsWith("textures/")) {
                    val data = zip.readBytes()
                    total += data.size
                    if (total > MAX_PROJECT_BYTES) {
                        throw ProjectFormatException("Projeto grande demais para abrir (limite ${MAX_PROJECT_BYTES / (1024 * 1024)} MB)")
                    }
                    if (name == ENTRY_NAME) json = data.toString(Charsets.UTF_8) else textures[name] = data
                }
                entry = zip.nextEntry
            }
        }
        val text = json ?: throw ProjectFormatException("$ENTRY_NAME ausente em ${file.name}")
        val project = ProjectSerializer.fromJson(text) { path -> textures[path] }
        for (a in project.assets) {
            if (a.isMissing) logger("Textura ausente no arquivo ${file.name}: ${a.name} (${a.id})")
        }
        return project
    }

    private fun readJson(file: File): String {
        ZipInputStream(file.inputStream().buffered()).use { zip ->
            var entry = zip.nextEntry
            while (entry != null) {
                if (entry.name == ENTRY_NAME) return zip.readBytes().toString(Charsets.UTF_8)
                entry = zip.nextEntry
            }
        }
        throw ProjectFormatException("$ENTRY_NAME ausente em ${file.name}")
    }

    private fun fileFor(id: String): File {
        require(ID_REGEX.matches(id)) { "ID de projeto inválido" }
        return File(dir, "$id$EXT")
    }

    private fun backupFor(id: String): File = File(fileFor(id).path + ".bak")

    companion object {
        const val EXT = ".v2d"
        const val ENTRY_NAME = "project.json"
        private const val MAX_PROJECT_BYTES = 512L * 1024 * 1024
        private val ID_REGEX = Regex("[A-Za-z0-9-]+")
    }
}
