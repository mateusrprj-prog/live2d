package com.mobile2dstudio.project

import com.mobile2dstudio.geometry.Affine
import com.mobile2dstudio.geometry.Transform2D

/**
 * Operações puras de hierarquia sobre a lista de partes. Toda função devolve uma NOVA lista
 * em ordem canônica (pré-ordem: pai antes dos filhos; irmãos na ordem da lista; fundo -> frente).
 * Partes não alteradas mantêm a mesma instância. Dados inconsistentes (pai inexistente,
 * ciclos) são normalizados em vez de derrubar o projeto.
 */
object PartTree {

    /** Parte já resolvida: transformação de mundo, visibilidade/bloqueio/opacidade herdados. */
    class Resolved(
        val part: Part,
        val world: Affine,
        val visible: Boolean,
        val locked: Boolean,
        val opacity: Float
    )

    // ---------------------------------------------------------------- consulta

    fun canonicalOrder(parts: List<Part>): List<Part> {
        val map = childMap(parts)
        val visited = HashSet<String>()
        val out = ArrayList<Part>(parts.size)
        walk(map, null, visited, out)
        if (out.size < parts.size) {
            // Ciclos: reconecta a primeira parte não visitada na raiz.
            for (p in parts) {
                if (!visited.contains(p.id)) {
                    visited.add(p.id)
                    out.add(if (p.parentId == null) p else p.copy(parentId = null))
                    walk(map, p.id, visited, out)
                }
            }
        }
        return out
    }

    fun resolve(parts: List<Part>): List<Resolved> {
        val ordered = canonicalOrder(parts)
        val byId = HashMap<String, Resolved>(ordered.size * 2 + 1)
        val out = ArrayList<Resolved>(ordered.size)
        for (p in ordered) {
            val pid = p.parentId
            val parent = if (pid == null) null else byId[pid]
            val local = p.transform.toAffine()
            val r = if (parent == null) {
                Resolved(p, local, p.visible, p.locked, p.opacity)
            } else {
                Resolved(
                    p,
                    parent.world * local,
                    parent.visible && p.visible,
                    parent.locked || p.locked,
                    parent.opacity * p.opacity
                )
            }
            byId[p.id] = r
            out.add(r)
        }
        return out
    }

    /** Partes com malha, de trás para frente (ordem de desenho). */
    fun renderList(parts: List<Part>): List<Resolved> = resolve(parts).filter { it.part.mesh != null }

    fun worldOf(parts: List<Part>, id: String): Affine? {
        for (r in resolve(parts)) if (r.part.id == id) return r.world
        return null
    }

    fun descendantIds(parts: List<Part>, id: String): Set<String> {
        val map = childMap(canonicalOrder(parts))
        val out = LinkedHashSet<String>()
        fun collect(pid: String) {
            val kids = map[pid] ?: return
            for (k in kids) {
                if (out.add(k.id)) collect(k.id)
            }
        }
        collect(id)
        return out
    }

    fun depthOf(parts: List<Part>, id: String): Int {
        val byId = HashMap<String, Part>()
        for (p in canonicalOrder(parts)) byId[p.id] = p
        var depth = 0
        var cur = byId[id]?.parentId
        while (cur != null && depth <= byId.size) {
            depth++
            cur = byId[cur]?.parentId
        }
        return depth
    }

    fun unusedAssets(project: V2dProject): List<ImageAsset> {
        val used = HashSet<String>()
        for (p in project.parts) p.textureId?.let { used.add(it) }
        return project.assets.filter { !used.contains(it.id) }
    }

    // ---------------------------------------------------------------- edição

    fun add(parts: List<Part>, part: Part, parentId: String? = null, index: Int = -1): List<Part> {
        val canon = canonicalOrder(parts)
        require(canon.none { it.id == part.id }) { "ID de parte duplicado: ${part.id}" }
        requireValidParent(canon, parentId)
        val map = mutableChildMap(canon)
        val target = map.getOrPut(parentId) { ArrayList() }
        val at = if (index < 0 || index > target.size) target.size else index
        target.add(at, part.copy(parentId = parentId))
        return flattenMap(map, canon.size + 1)
    }

    fun remove(parts: List<Part>, id: String): List<Part> = removeAll(parts, listOf(id))

    /** Remove as partes e todas as suas descendentes. */
    fun removeAll(parts: List<Part>, ids: Collection<String>): List<Part> {
        val canon = canonicalOrder(parts)
        val doomed = HashSet<String>()
        for (id in ids) {
            doomed.add(id)
            doomed.addAll(descendantIds(canon, id))
        }
        return canon.filter { !doomed.contains(it.id) }
    }

    fun update(parts: List<Part>, id: String, change: (Part) -> Part): List<Part> =
        parts.map { if (it.id == id) change(it) else it }

    fun rename(parts: List<Part>, id: String, name: String): List<Part> {
        require(name.isNotBlank()) { "O nome não pode ser vazio" }
        return update(parts, id) { it.copy(name = name.trim()) }
    }

    /**
     * Move [id] para dentro de [newParentId] (null = raiz) na posição [index] entre as irmãs
     * (contada depois de remover a parte da posição antiga; fora do intervalo = no fim/frente).
     * Com [preserveWorld] a posição visual é mantida, recalculando a transformação local.
     */
    fun move(
        parts: List<Part>,
        id: String,
        newParentId: String?,
        index: Int = -1,
        preserveWorld: Boolean = true
    ): List<Part> {
        val canon = canonicalOrder(parts)
        val node = canon.firstOrNull { it.id == id }
            ?: throw IllegalArgumentException("Parte inexistente: $id")
        require(newParentId != id) { "Uma parte não pode ser filha de si mesma" }
        requireValidParent(canon, newParentId)
        if (newParentId != null) {
            require(!descendantIds(canon, id).contains(newParentId)) {
                "Não é possível mover uma parte para dentro de uma descendente"
            }
        }

        val resolvedBefore = if (preserveWorld) resolve(canon) else emptyList()
        var worldBefore: Affine? = null
        var oldParentWorld: Affine = Affine.IDENTITY
        for (r in resolvedBefore) {
            if (r.part.id == id) worldBefore = r.world
            if (r.part.id == node.parentId) oldParentWorld = r.world
        }

        val map = mutableChildMap(canon)
        map[node.parentId]?.removeAll { it.id == id }
        val target = map.getOrPut(newParentId) { ArrayList() }
        val at = if (index < 0 || index > target.size) target.size else index
        target.add(at, if (node.parentId == newParentId) node else node.copy(parentId = newParentId))
        var result = flattenMap(map, canon.size)

        val wb = worldBefore
        if (preserveWorld && wb != null) {
            var newParentWorld: Affine = Affine.IDENTITY
            if (newParentId != null) {
                for (r in resolve(result)) if (r.part.id == newParentId) newParentWorld = r.world
            }
            if (!newParentWorld.isNearly(oldParentWorld)) {
                val inv = newParentWorld.inverse()
                if (inv != null) {
                    val local = Transform2D.fromAffine(inv * wb)
                    result = result.map { if (it.id == id) it.copy(transform = local) else it }
                }
            }
        }
        return result
    }

    /** Sobe/desce [id] entre as irmãs. delta > 0 = em direção à frente. */
    fun reorder(parts: List<Part>, id: String, delta: Int): List<Part> {
        val canon = canonicalOrder(parts)
        val node = canon.firstOrNull { it.id == id }
            ?: throw IllegalArgumentException("Parte inexistente: $id")
        val siblings = canon.filter { it.parentId == node.parentId }
        val current = siblings.indexOfFirst { it.id == id }
        val target = (current + delta).coerceIn(0, siblings.size - 1)
        if (target == current) return canon
        return move(canon, id, node.parentId, target, preserveWorld = false)
    }

    /** Cria um grupo no lugar da primeira parte selecionada e move as selecionadas para dentro. */
    fun group(parts: List<Part>, ids: Collection<String>, groupId: String, name: String): List<Part> {
        require(name.isNotBlank()) { "O nome do grupo não pode ser vazio" }
        val canon = canonicalOrder(parts)
        require(canon.none { it.id == groupId }) { "ID de grupo duplicado: $groupId" }
        val byId = HashMap<String, Part>()
        for (p in canon) byId[p.id] = p
        val selected = HashSet<String>()
        for (id in ids) if (byId.containsKey(id)) selected.add(id)
        require(selected.isNotEmpty()) { "Nenhuma parte selecionada para agrupar" }

        val top = canon.filter { p -> selected.contains(p.id) && !hasSelectedAncestor(p, byId, selected) }
        val first = top[0]
        val parentId = first.parentId
        val siblings = canon.filter { it.parentId == parentId }
        val index = siblings.indexOfFirst { it.id == first.id }
        val groupPart = Part(
            id = groupId,
            name = name.trim(),
            parentId = parentId,
            visible = true,
            locked = false,
            mesh = null,
            kind = PartKind.GROUP
        )
        var result = add(canon, groupPart, parentId, index)
        for (p in top) result = move(result, p.id, groupId, -1, true)
        return result
    }

    /** Desfaz um grupo: as filhas assumem o lugar dele (posição visual preservada). */
    fun ungroup(parts: List<Part>, groupId: String): List<Part> {
        val canon = canonicalOrder(parts)
        val group = canon.firstOrNull { it.id == groupId }
            ?: throw IllegalArgumentException("Parte inexistente: $groupId")
        require(group.kind == PartKind.GROUP) { "Só grupos podem ser desfeitos" }
        val parentId = group.parentId
        val siblings = canon.filter { it.parentId == parentId }
        val groupIndex = siblings.indexOfFirst { it.id == groupId }
        val kids = canon.filter { it.parentId == groupId }
        var result = canon
        for ((i, k) in kids.withIndex()) {
            result = move(result, k.id, parentId, groupIndex + i, true)
        }
        return remove(result, groupId)
    }

    /**
     * Desloca no MUNDO as partes [ids] por (dx, dy). Partes bloqueadas (própria ou herdada) e
     * partes cujo ancestral também está na seleção não são tocadas diretamente.
     */
    fun translateWorld(parts: List<Part>, ids: Collection<String>, dx: Float, dy: Float): List<Part> {
        val resolved = resolve(parts)
        val byId = HashMap<String, Resolved>()
        for (r in resolved) byId[r.part.id] = r
        val partById = HashMap<String, Part>()
        for (r in resolved) partById[r.part.id] = r.part
        val selected = HashSet<String>(ids)

        val newTransforms = HashMap<String, Transform2D>()
        for (id in selected) {
            val r = byId[id] ?: continue
            if (r.locked) continue
            if (hasSelectedAncestor(r.part, partById, selected)) continue
            val pid = r.part.parentId
            val parentWorld = if (pid == null) Affine.IDENTITY else (byId[pid]?.world ?: Affine.IDENTITY)
            val inv = parentWorld.inverse() ?: continue
            val v = inv.applyVector(dx, dy)
            val t = r.part.transform
            newTransforms[id] = t.copy(x = t.x + v.x, y = t.y + v.y)
        }
        if (newTransforms.isEmpty()) return parts
        return parts.map { p ->
            val t = newTransforms[p.id]
            if (t == null) p else p.copy(transform = t)
        }
    }

    // ---------------------------------------------------------------- internos

    private fun requireValidParent(canon: List<Part>, parentId: String?) {
        if (parentId == null) return
        val parent = canon.firstOrNull { it.id == parentId }
            ?: throw IllegalArgumentException("Pai inexistente: $parentId")
        require(parent.kind == PartKind.GROUP) { "Só grupos podem conter outras partes" }
    }

    private fun hasSelectedAncestor(p: Part, byId: Map<String, Part>, selected: Set<String>): Boolean {
        var cur = p.parentId
        var steps = 0
        while (cur != null && steps <= byId.size) {
            if (selected.contains(cur)) return true
            cur = byId[cur]?.parentId
            steps++
        }
        return false
    }

    private fun childMap(parts: List<Part>): Map<String?, List<Part>> {
        val ids = HashSet<String>()
        for (p in parts) ids.add(p.id)
        val map = LinkedHashMap<String?, ArrayList<Part>>()
        for (p in parts) {
            val pid = p.parentId
            val key: String? = if (pid != null && pid != p.id && ids.contains(pid)) pid else null
            var list = map[key]
            if (list == null) {
                list = ArrayList()
                map[key] = list
            }
            list.add(p)
        }
        return map
    }

    private fun mutableChildMap(canon: List<Part>): LinkedHashMap<String?, ArrayList<Part>> {
        val map = LinkedHashMap<String?, ArrayList<Part>>()
        for (p in canon) {
            var list = map[p.parentId]
            if (list == null) {
                list = ArrayList()
                map[p.parentId] = list
            }
            list.add(p)
        }
        return map
    }

    private fun flattenMap(map: Map<String?, List<Part>>, expected: Int): List<Part> {
        val out = ArrayList<Part>(expected)
        walk(map, null, HashSet<String>(), out)
        return out
    }

    private fun walk(
        map: Map<String?, List<Part>>,
        parentId: String?,
        visited: HashSet<String>,
        out: ArrayList<Part>
    ) {
        val kids = map[parentId] ?: return
        for (k in kids) {
            if (!visited.add(k.id)) continue
            out.add(if (k.parentId == parentId) k else k.copy(parentId = parentId))
            walk(map, k.id, visited, out)
        }
    }
}
