package com.mobile2dstudio.project

enum class ImageFormat(val extension: String) {
    PNG("png"),
    JPEG("jpg")
}

/**
 * Textura embutida no projeto. [bytes] guarda o arquivo original (PNG/JPEG já comprimido);
 * a decodificação para GPU acontece no renderer. bytes vazio = recurso ausente.
 */
class ImageAsset(
    val id: String,
    val name: String,
    val width: Int,
    val height: Int,
    val format: ImageFormat,
    val bytes: ByteArray
) {
    val isMissing: Boolean get() = bytes.isEmpty()

    /** Caminho da entrada dentro do ZIP .v2d. */
    fun entryName(): String = "textures/$id.${format.extension}"
}
