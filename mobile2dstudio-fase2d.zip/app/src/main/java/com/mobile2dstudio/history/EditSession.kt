package com.mobile2dstudio.history

import com.mobile2dstudio.project.EditState

/** Comando de edição do projeto: guarda o estado antes/depois (referências compartilhadas). */
class EditCommand(
    override val label: String,
    private val before: EditState,
    private val after: EditState,
    override val mergeKey: Any? = null
) : Command<EditState> {
    override fun redo(state: EditState): EditState = after
    override fun undo(state: EditState): EditState = before

    override fun mergeWith(next: Command<EditState>): Command<EditState>? {
        if (next !is EditCommand) return null
        return EditCommand(label, before, next.after, mergeKey)
    }
}

/**
 * Dono do estado editável + histórico. Toda alteração passa por [apply]; a UI não deve
 * mexer na lista de partes por fora (senão o desfazer perde a alteração).
 */
class EditSession(initial: EditState, historyLimit: Int = 200) {
    var state: EditState = initial
        private set

    private val history = History<EditState>(historyLimit)

    val canUndo: Boolean get() = history.canUndo
    val canRedo: Boolean get() = history.canRedo
    val undoLabel: String? get() = history.undoLabel
    val redoLabel: String? get() = history.redoLabel

    /**
     * Aplica [change]. Retorna false (e não registra nada) se nada mudou.
     * [mergeKey]: use a mesma chave em todos os passos de um arrastar para virarem um só desfazer.
     */
    fun apply(label: String, mergeKey: Any? = null, change: (EditState) -> EditState): Boolean {
        val before = state
        val after = change(before)
        if (after.parts === before.parts && after.assets === before.assets) return false
        state = after
        history.record(EditCommand(label, before, after, mergeKey))
        return true
    }

    fun endGesture() = history.endGesture()

    fun undo(): Boolean {
        if (!history.canUndo) return false
        state = history.undo(state)
        return true
    }

    fun redo(): Boolean {
        if (!history.canRedo) return false
        state = history.redo(state)
        return true
    }

    /** Troca o estado sem registrar histórico (ex.: abrir projeto) e limpa as pilhas. */
    fun reset(newState: EditState) {
        state = newState
        history.clear()
    }
}
