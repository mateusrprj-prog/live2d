package com.mobile2dstudio.history

/** Comando reversível sobre um estado imutável [S]. */
interface Command<S> {
    val label: String

    /** Se não for null, comandos consecutivos com a mesma chave podem ser fundidos (ex.: arrastar). */
    val mergeKey: Any? get() = null

    fun redo(state: S): S
    fun undo(state: S): S

    /** Comando equivalente a this seguido de [next], ou null se não for possível fundir. */
    fun mergeWith(next: Command<S>): Command<S>? = null
}

/**
 * Pilhas de desfazer/refazer. Não guarda o estado: só comandos. Com estados imutáveis
 * que compartilham referências, cada comando custa pouca memória (não copia o projeto).
 */
class History<S>(private val limit: Int = 200) {
    private val undoStack = ArrayList<Command<S>>()
    private val redoStack = ArrayList<Command<S>>()
    private var mergeOpen = false

    val canUndo: Boolean get() = undoStack.isNotEmpty()
    val canRedo: Boolean get() = redoStack.isNotEmpty()
    val undoLabel: String? get() = if (undoStack.isEmpty()) null else undoStack[undoStack.size - 1].label
    val redoLabel: String? get() = if (redoStack.isEmpty()) null else redoStack[redoStack.size - 1].label
    val undoCount: Int get() = undoStack.size

    /** Registra um comando JÁ aplicado ao estado. */
    fun record(command: Command<S>) {
        redoStack.clear()
        if (mergeOpen && undoStack.isNotEmpty()) {
            val last = undoStack[undoStack.size - 1]
            val key = command.mergeKey
            if (key != null && key == last.mergeKey) {
                val merged = last.mergeWith(command)
                if (merged != null) {
                    undoStack[undoStack.size - 1] = merged
                    return
                }
            }
        }
        undoStack.add(command)
        while (undoStack.size > limit) undoStack.removeAt(0)
        mergeOpen = command.mergeKey != null
    }

    /** Fecha a janela de fusão (chamar ao soltar o dedo). */
    fun endGesture() {
        mergeOpen = false
    }

    fun undo(state: S): S {
        if (undoStack.isEmpty()) return state
        val cmd = undoStack.removeAt(undoStack.size - 1)
        redoStack.add(cmd)
        mergeOpen = false
        return cmd.undo(state)
    }

    fun redo(state: S): S {
        if (redoStack.isEmpty()) return state
        val cmd = redoStack.removeAt(redoStack.size - 1)
        undoStack.add(cmd)
        mergeOpen = false
        return cmd.redo(state)
    }

    fun clear() {
        undoStack.clear()
        redoStack.clear()
        mergeOpen = false
    }
}
