package com.mobile2dstudio.ui

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.mobile2dstudio.geometry.Transform2D
import com.mobile2dstudio.history.EditSession
import com.mobile2dstudio.imports.DocumentImporter
import com.mobile2dstudio.imports.ImportedDocument
import com.mobile2dstudio.imports.LayerImport
import com.mobile2dstudio.project.EditState
import com.mobile2dstudio.project.Part
import com.mobile2dstudio.project.PartKind
import com.mobile2dstudio.project.PartTree
import com.mobile2dstudio.project.ProjectRepository
import com.mobile2dstudio.project.V2dProject
import com.mobile2dstudio.rendering.GLCanvasView
import com.mobile2dstudio.rendering.RenderPart
import com.mobile2dstudio.rendering.RenderScene
import com.mobile2dstudio.selection.HitTest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.util.UUID

private const val MAX_IMPORT_BYTES = 512L * 1024L * 1024L
private val UiBg = Color(0xFF252525)
private val UiPanel = Color(0xFF323232)
private val UiPanelAlt = Color(0xFF2D2D2D)
private val UiLine = Color(0xFF1E1E1E)
private val UiText = Color(0xFFD0D0D0)
private val UiMuted = Color(0xFF929292)
private val UiOrange = Color(0xFFE8A33D)

private data class PendingImport(val fileName: String, val document: ImportedDocument)

@Composable
fun EditorScreen(
    repository: ProjectRepository,
    projectId: String,
    onClose: () -> Unit,
    onOpenProject: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val glView = remember { GLCanvasView(context) }
    val saveMutex = remember { Mutex() }
    val editSession = remember(projectId) { EditSession(EditState(emptyList(), emptyList())) }
    val moveMergeKey = remember(projectId) { Any() }

    var project by remember { mutableStateOf<V2dProject?>(null) }
    var loadError by remember { mutableStateOf<String?>(null) }
    var dirty by remember { mutableStateOf(false) }
    var showWire by remember { mutableStateOf(false) }
    var showLeftPanel by remember { mutableStateOf(true) }
    var showInspector by remember { mutableStateOf(true) }
    var panTool by remember { mutableStateOf(false) }
    var multiSelect by remember { mutableStateOf(false) }
    var rectangleSelect by remember { mutableStateOf(false) }
    var selectedIds by remember(projectId) { mutableStateOf<Set<String>>(emptySet()) }
    var status by remember { mutableStateOf("") }
    var editRevision by remember { mutableIntStateOf(0) }
    var importing by remember { mutableStateOf(false) }
    var pendingImport by remember { mutableStateOf<PendingImport?>(null) }

    fun syncEditedState() {
        val state = editSession.state
        project = project?.copy(parts = state.parts, assets = state.assets)
        dirty = true
        editRevision++
    }

    fun applyEdit(label: String, mergeKey: Any? = null, change: (EditState) -> EditState) {
        if (editSession.apply(label, mergeKey, change)) syncEditedState()
    }

    LaunchedEffect(projectId) {
        try {
            val loaded = withContext(Dispatchers.IO) { repository.load(projectId) }
            editSession.reset(EditState(loaded.parts, loaded.assets))
            project = loaded
            selectedIds = emptySet()
            dirty = false
            editRevision++
        } catch (e: Exception) {
            loadError = e.message ?: "Falha ao abrir o projeto"
        }
    }

    suspend fun save(): Boolean {
        val snapshot = project ?: return true
        return saveMutex.withLock {
            try {
                val saved = withContext(Dispatchers.IO) { repository.save(snapshot) }
                project = project?.copy(meta = saved.meta)
                if (project?.parts === snapshot.parts && project?.assets === snapshot.assets) dirty = false
                status = "Salvo"
                true
            } catch (e: Exception) {
                status = "Erro ao salvar: ${e.message}"
                false
            }
        }
    }

    fun closeAfterSave() { scope.launch { if (!dirty || save()) onClose() } }
    BackHandler { closeAfterSave() }

    LaunchedEffect(Unit) {
        while (true) {
            delay(20_000)
            if (dirty && save()) status = "Autosave concluído"
        }
    }

    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner, glView) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME -> glView.onResume()
                Lifecycle.Event.ON_PAUSE -> glView.onPause()
                Lifecycle.Event.ON_STOP -> scope.launch { if (dirty) save() }
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            glView.onPause()
        }
    }

    // A seleção e o arrasto continuam usando coordenadas do documento e EditSession.
    glView.oneFingerPan = panTool
    glView.rectangleSelectionEnabled = rectangleSelect
    glView.onWorldDown = { x, y ->
        val hit = HitTest.point(editSession.state.parts, x, y)
        val previous = selectedIds
        selectedIds = when {
            hit == null && !multiSelect -> emptySet()
            hit == null -> previous
            multiSelect && previous.contains(hit) -> previous - hit
            multiSelect -> previous + hit
            else -> setOf(hit)
        }
    }
    glView.onWorldDrag = { dx, dy ->
        val ids = selectedIds
        if (!panTool && ids.isNotEmpty()) {
            applyEdit("Mover parte", moveMergeKey) { state ->
                state.copy(parts = PartTree.translateWorld(state.parts, ids, dx, dy))
            }
        }
    }
    glView.onWorldUp = { editSession.endGesture() }
    glView.onWorldRectangle = { x1, y1, x2, y2 ->
        selectedIds = HitTest.rectangle(editSession.state.parts, x1, y1, x2, y2).toSet()
    }

    val current = project
    LaunchedEffect(current?.parts, current?.assets, current?.meta?.width, current?.meta?.height, showWire, selectedIds, editRevision) {
        val p = current ?: return@LaunchedEffect
        val assets = p.assets.associateBy { it.id }
        val renderParts = PartTree.renderList(p.parts).map { resolved ->
            val part = resolved.part
            val asset = part.textureId?.let { assets[it] }
            RenderPart(
                id = part.id,
                mesh = part.mesh!!,
                world = resolved.world,
                visible = resolved.visible,
                opacity = resolved.opacity,
                textureId = part.textureId,
                textureBytes = asset?.bytes,
                selected = part.id in selectedIds
            )
        }
        glView.update {
            setScene(RenderScene(renderParts, p.meta.width.toFloat(), p.meta.height.toFloat(), showWire))
        }
    }

    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                importing = true
                status = "Lendo arquivo…"
                try {
                    val fileName = queryDisplayName(context, uri) ?: "importacao"
                    val bytes = withContext(Dispatchers.IO) { readLimited(context, uri, MAX_IMPORT_BYTES) }
                    val document = withContext(Dispatchers.Default) { DocumentImporter.import(fileName, bytes) }
                    pendingImport = PendingImport(fileName, document)
                    status = "Arquivo analisado"
                } catch (e: Exception) {
                    status = "Falha na importação: ${e.message ?: "arquivo inválido"}"
                } finally {
                    importing = false
                }
            }
        }
    }

    val selectedPart = current?.parts?.firstOrNull { it.id == selectedIds.singleOrNull() }
    val nameMergeKey = remember(selectedPart?.id) { Any() }
    val canUndo = editSession.canUndo
    val canRedo = editSession.canRedo

    Column(Modifier.fillMaxSize().background(UiBg).systemBarsPadding()) {
        EditorCommandBar(
            projectName = current?.meta?.name ?: "Abrindo projeto…",
            showLeftPanel = showLeftPanel,
            showInspector = showInspector,
            canUndo = canUndo,
            canRedo = canRedo,
            onBack = { closeAfterSave() },
            onToggleLeft = { showLeftPanel = !showLeftPanel },
            onToggleInspector = { showInspector = !showInspector },
            selectToolActive = !panTool && !rectangleSelect,
            panToolActive = panTool,
            rectangleToolActive = rectangleSelect,
            onSelectTool = { panTool = false; rectangleSelect = false },
            onPanTool = { panTool = !panTool; rectangleSelect = false },
            onRectangleTool = { rectangleSelect = !rectangleSelect; panTool = false },
            onMultiSelect = { multiSelect = !multiSelect },
            multiSelect = multiSelect,
            showWire = showWire,
            onWire = { showWire = !showWire },
            onImport = { importLauncher.launch(arrayOf("*/*")) },
            onFit = { glView.fitToCanvas() },
            onUndo = { if (editSession.undo()) { syncEditedState(); selectedIds = selectedIds.intersect(editSession.state.parts.map { it.id }.toSet()) } },
            onRedo = { if (editSession.redo()) syncEditedState() },
            onSave = { scope.launch { save() } },
            importing = importing
        )
        ModeStrip()

        Row(Modifier.weight(1f).fillMaxWidth().background(UiBg)) {
            if (showLeftPanel && current != null) {
                LayersDock(
                    parts = current.parts,
                    projectName = current.meta.name,
                    projectWidth = current.meta.width,
                    projectHeight = current.meta.height,
                    projectFps = current.meta.fps,
                    selectedIds = selectedIds,
                    modifier = Modifier.width(214.dp).fillMaxHeight(),
                    onSelect = { id -> selectedIds = setOf(id); panTool = false; rectangleSelect = false },
                    onVisibleChange = { id, visible ->
                        applyEdit("Visibilidade") { state -> state.copy(parts = state.parts.map { if (it.id == id) it.copy(visible = visible) else it }) }
                    },
                    onLockChange = { id, locked ->
                        applyEdit("Bloquear peça") { state -> state.copy(parts = state.parts.map { if (it.id == id) it.copy(locked = locked) else it }) }
                    },
                    onDelete = { id ->
                        applyEdit("Excluir peça") { state ->
                            val remaining = PartTree.removeAll(state.parts, listOf(id))
                            val usedAssets = remaining.mapNotNull { it.textureId }.toSet()
                            state.copy(parts = remaining, assets = state.assets.filter { it.id in usedAssets })
                        }
                        selectedIds = selectedIds.intersect(editSession.state.parts.map { it.id }.toSet())
                    },
                    onGroup = {
                        if (selectedIds.isNotEmpty()) {
                            try {
                                val groupId = UUID.randomUUID().toString()
                                applyEdit("Agrupar peças") { state ->
                                    state.copy(parts = PartTree.group(state.parts, selectedIds, groupId, "Novo grupo"))
                                }
                                selectedIds = setOf(groupId)
                            } catch (e: Exception) { status = e.message ?: "Não foi possível agrupar" }
                        }
                    },
                    onUngroup = { id ->
                        try { applyEdit("Desagrupar") { state -> state.copy(parts = PartTree.ungroup(state.parts, id)) }; selectedIds = emptySet() }
                        catch (e: Exception) { status = e.message ?: "Não foi possível desagrupar" }
                    },
                    onMove = { id, delta ->
                        applyEdit("Reordenar peça") { state -> state.copy(parts = PartTree.reorder(state.parts, id, delta)) }
                    }
                )
            }

            Box(Modifier.weight(1f).fillMaxHeight().padding(1.dp).background(Color(0xFF202020))) {
                AndroidView(factory = { glView }, modifier = Modifier.fillMaxSize())
                if (importing) {
                    Surface(Modifier.align(Alignment.Center), color = UiPanel, shape = RoundedCornerShape(6.dp)) {
                        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            CircularProgressIndicator(Modifier.size(22.dp), color = UiOrange, strokeWidth = 2.dp)
                            Text("Processando documento…", color = UiText, fontSize = 12.sp)
                        }
                    }
                }
                current?.let { p ->
                    val vertices = p.parts.sumOf { it.mesh?.vertexCount ?: 0 }
                    val triangles = p.parts.sumOf { it.mesh?.triangleCount ?: 0 }
                    Row(
                        Modifier.align(Alignment.BottomStart).padding(6.dp)
                            .background(Color(0xCC292929), RoundedCornerShape(3.dp)).padding(horizontal = 8.dp, vertical = 5.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        TinyStatus("${p.meta.width} × ${p.meta.height}")
                        TinyStatus("${p.meta.fps} FPS")
                        TinyStatus("${p.parts.size} peças")
                        TinyStatus("$vertices vértices / $triangles triângulos")
                    }
                }
                loadError?.let { message ->
                    Surface(Modifier.align(Alignment.Center).padding(24.dp), color = Color(0xFF5A3035), shape = RoundedCornerShape(6.dp)) {
                        Column(Modifier.padding(16.dp)) {
                            Text(message, color = UiText)
                            TextButton(onClick = onClose) { Text("Voltar à lista", color = UiOrange) }
                        }
                    }
                }
            }

            if (showInspector && current != null) {
                InspectorDock(
                    selectedPart = selectedPart,
                    selectedCount = selectedIds.size,
                    modifier = Modifier.width(222.dp).fillMaxHeight(),
                    onNameChange = { id, value ->
                        applyEdit("Renomear peça", nameMergeKey) { state ->
                            state.copy(parts = PartTree.update(state.parts, id) { it.copy(name = value) })
                        }
                    },
                    onTransformChange = { id, transform ->
                        applyEdit("Transformar peça") { state -> state.copy(parts = PartTree.update(state.parts, id) { it.copy(transform = transform) }) }
                    },
                    onOpacityChange = { id, opacity ->
                        applyEdit("Opacidade") { state -> state.copy(parts = PartTree.update(state.parts, id) { it.copy(opacity = opacity.coerceIn(0f, 1f)) }) }
                    },
                    onVisibleChange = { id, visible ->
                        applyEdit("Visibilidade") { state -> state.copy(parts = PartTree.update(state.parts, id) { it.copy(visible = visible) }) }
                    },
                    onLockChange = { id, locked ->
                        applyEdit("Bloquear peça") { state -> state.copy(parts = PartTree.update(state.parts, id) { it.copy(locked = locked) }) }
                    },
                    onDelete = { id ->
                        applyEdit("Excluir peça") { state ->
                            val remaining = PartTree.removeAll(state.parts, listOf(id))
                            val used = remaining.mapNotNull { it.textureId }.toSet()
                            state.copy(parts = remaining, assets = state.assets.filter { it.id in used })
                        }
                        selectedIds = emptySet()
                    },
                    onMove = { id, delta -> applyEdit("Ordem de desenho") { state -> state.copy(parts = PartTree.reorder(state.parts, id, delta)) } }
                )
            }
        }

        EditorStatusBar(status = status, dirty = dirty, selectedCount = selectedIds.size)
    }

    pendingImport?.let { pending ->
        val imageLayers = pending.document.imageLayerCount()
        AlertDialog(
            onDismissRequest = { pendingImport = null },
            title = { Text("Importação analisada") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(pending.fileName)
                    Text("${pending.document.width} × ${pending.document.height} px • ${pending.document.layers.size} itens • $imageLayers camadas de imagem")
                    if (pending.document.warnings.isNotEmpty()) {
                        Text("Avisos:", style = MaterialTheme.typography.titleSmall)
                        pending.document.warnings.take(5).forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
                        if (pending.document.warnings.size > 5) Text("e mais ${pending.document.warnings.size - 5} aviso(s)…", style = MaterialTheme.typography.bodySmall)
                    }
                }
            },
            confirmButton = {
                Column(horizontalAlignment = Alignment.End) {
                    TextButton(onClick = {
                        val source = pending
                        pendingImport = null
                        scope.launch {
                            try {
                                if (dirty && !save()) return@launch
                                val name = source.fileName.substringAfterLast('/').substringBeforeLast('.').ifBlank { "Ilustração importada" }
                                val (created, warnings) = withContext(Dispatchers.IO) {
                                    repository.createFromImport(name, source.document, current?.meta?.fps ?: 30)
                                }
                                status = if (warnings.isEmpty()) "Projeto criado" else "Projeto criado com ${warnings.size} aviso(s)"
                                onOpenProject(created.meta.id)
                            } catch (e: Exception) { status = "Não foi possível criar o projeto: ${e.message}" }
                        }
                    }) { Text("Criar projeto novo") }
                    TextButton(onClick = {
                        val source = pending
                        pendingImport = null
                        try {
                            val converted = LayerImport.toParts(source.document)
                            applyEdit("Importar camadas") { state ->
                                var updated = state.parts
                                for (part in converted.parts) updated = PartTree.add(updated, part, part.parentId)
                                state.copy(parts = updated, assets = state.assets + converted.assets)
                            }
                            status = if (converted.warnings.isEmpty()) "Camadas adicionadas" else "Importado com ${converted.warnings.size} aviso(s)"
                        } catch (e: Exception) { status = "Falha ao adicionar camadas: ${e.message}" }
                    }, enabled = current != null) { Text("Adicionar ao projeto aberto") }
                }
            },
            dismissButton = { TextButton(onClick = { pendingImport = null }) { Text("Cancelar") } }
        )
    }
}

@Composable
private fun EditorCommandBar(
    projectName: String,
    showLeftPanel: Boolean,
    showInspector: Boolean,
    selectToolActive: Boolean,
    panToolActive: Boolean,
    rectangleToolActive: Boolean,
    canUndo: Boolean,
    canRedo: Boolean,
    onBack: () -> Unit,
    onToggleLeft: () -> Unit,
    onToggleInspector: () -> Unit,
    onSelectTool: () -> Unit,
    onPanTool: () -> Unit,
    onRectangleTool: () -> Unit,
    onMultiSelect: () -> Unit,
    multiSelect: Boolean,
    showWire: Boolean,
    onWire: () -> Unit,
    onImport: () -> Unit,
    onFit: () -> Unit,
    onUndo: () -> Unit,
    onRedo: () -> Unit,
    onSave: () -> Unit,
    importing: Boolean
) {
    Row(
        Modifier.fillMaxWidth().height(48.dp).background(Color(0xFF303030)).padding(horizontal = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        ToolButton("‹", "Voltar", false, onBack, width = 40.dp)
        Column(Modifier.width(112.dp), verticalArrangement = Arrangement.Center) {
            Text("MOBILE 2D STUDIO", color = UiMuted, fontSize = 8.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            Text(projectName, color = UiText, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        CommandDivider()
        ToolButton("▣", "Selecionar", selectToolActive, onSelectTool)
        ToolButton("✋", "Mover canvas", panToolActive, onPanTool)
        ToolButton("▱", "Seleção retangular", rectangleToolActive, onRectangleTool)
        ToolButton("＋", "Seleção múltipla", multiSelect, onMultiSelect)
        ToolButton("◇", "Exibir malha", showWire, onWire)
        CommandDivider()
        ToolButton("▤", "Painel de peças", showLeftPanel, onToggleLeft)
        ToolButton("☷", "Inspetor", showInspector, onToggleInspector)
        Spacer(Modifier.weight(1f))
        ToolButton("↶", "Desfazer", false, onUndo, enabled = canUndo)
        ToolButton("↷", "Refazer", false, onRedo, enabled = canRedo)
        ToolButton("⌗", "Ajustar canvas", false, onFit)
        ToolButton("⇧", "Importar", false, onImport, enabled = !importing)
        ToolButton("▣", "Salvar", true, onSave)
    }
}

@Composable
private fun ModeStrip() {
    Row(
        Modifier.fillMaxWidth().height(34.dp).background(Color(0xFF272727)).padding(start = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        ModeChip("MODELAGEM", active = true, enabled = true)
        ModeChip("ANIMAÇÃO · FASE 6", active = false, enabled = false)
        ModeChip("FÍSICA · FASE 5", active = false, enabled = false)
        Spacer(Modifier.weight(1f))
        Text("ESPAÇO DE TRABALHO", color = UiMuted, fontSize = 8.sp, modifier = Modifier.padding(end = 10.dp))
    }
}

@Composable
private fun ModeChip(label: String, active: Boolean, enabled: Boolean) {
    Box(
        Modifier.padding(end = 4.dp).height(27.dp)
            .background(if (active) Color(0xFF45403A) else Color.Transparent, RoundedCornerShape(topStart = 3.dp, topEnd = 3.dp))
            .border(width = if (active) 1.dp else 0.dp, color = if (active) UiOrange else Color.Transparent, shape = RoundedCornerShape(topStart = 3.dp, topEnd = 3.dp))
            .padding(horizontal = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = if (active) UiOrange else if (enabled) UiText else UiMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun LayersDock(
    parts: List<Part>,
    projectName: String,
    projectWidth: Int,
    projectHeight: Int,
    projectFps: Int,
    selectedIds: Set<String>,
    modifier: Modifier,
    onSelect: (String) -> Unit,
    onVisibleChange: (String, Boolean) -> Unit,
    onLockChange: (String, Boolean) -> Unit,
    onDelete: (String) -> Unit,
    onGroup: () -> Unit,
    onUngroup: (String) -> Unit,
    onMove: (String, Int) -> Unit
) {
    var activeTab by remember { mutableStateOf("PEÇAS") }
    var expandedGroups by remember { mutableStateOf(parts.filter { it.kind == PartKind.GROUP }.map { it.id }.toSet()) }
    LaunchedEffect(parts.map { it.id }) {
        val groups = parts.filter { it.kind == PartKind.GROUP }.map { it.id }.toSet()
        expandedGroups = expandedGroups.intersect(groups) + groups
    }
    Surface(modifier, color = UiPanel, shape = RoundedCornerShape(2.dp)) {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().height(34.dp).background(Color(0xFF292929)), verticalAlignment = Alignment.CenterVertically) {
                DockTab("PEÇAS", activeTab == "PEÇAS") { activeTab = "PEÇAS" }
                DockTab("PROJETO", activeTab == "PROJETO") { activeTab = "PROJETO" }
                Spacer(Modifier.weight(1f))
                Text("≡", color = UiMuted, fontSize = 15.sp, modifier = Modifier.padding(horizontal = 8.dp))
            }
            if (activeTab == "PEÇAS") {
                Row(Modifier.fillMaxWidth().height(32.dp).background(UiPanelAlt).padding(horizontal = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("HIERARQUIA  ·  ${parts.size}", color = UiMuted, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.weight(1f))
                    MiniAction("＋ GRUPO", enabled = selectedIds.isNotEmpty(), onClick = onGroup)
                }
                Row(Modifier.fillMaxWidth().height(25.dp).background(Color(0xFF292929)), verticalAlignment = Alignment.CenterVertically) {
                    Text("VIS", color = UiMuted, fontSize = 8.sp, modifier = Modifier.width(34.dp).padding(start = 7.dp))
                    Text("NOME / TIPO", color = UiMuted, fontSize = 8.sp, modifier = Modifier.weight(1f))
                    Text("LOCK", color = UiMuted, fontSize = 8.sp, modifier = Modifier.width(35.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                }
                val rows = remember(parts, expandedGroups) { buildLayerRows(parts, expandedGroups) }
                LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
                    items(rows, key = { it.part.id }) { row ->
                        LayerTreeRow(
                            row = row,
                            selected = row.part.id in selectedIds,
                            expanded = row.part.id in expandedGroups,
                            onSelect = { onSelect(row.part.id) },
                            onToggleExpand = { expandedGroups = if (row.part.id in expandedGroups) expandedGroups - row.part.id else expandedGroups + row.part.id },
                            onVisible = { onVisibleChange(row.part.id, !row.part.visible) },
                            onLock = { onLockChange(row.part.id, !row.part.locked) }
                        )
                    }
                }
                Row(Modifier.fillMaxWidth().height(36.dp).background(Color(0xFF292929)).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    MiniAction("▲ FRENTE", selectedIds.size == 1, { selectedIds.singleOrNull()?.let { onMove(it, 1) } })
                    MiniAction("▼ FUNDO", selectedIds.size == 1, { selectedIds.singleOrNull()?.let { onMove(it, -1) } })
                    Spacer(Modifier.weight(1f))
                    MiniAction(
                        "DESAGRUPAR",
                        selectedIds.size == 1 && parts.firstOrNull { it.id == selectedIds.first() }?.kind == PartKind.GROUP,
                        { selectedIds.singleOrNull()?.let(onUngroup) }
                    )
                    MiniAction("✕", selectedIds.size == 1, { selectedIds.singleOrNull()?.let(onDelete) })
                }
            } else {
                Column(Modifier.weight(1f).fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Text("PROJETO ATUAL", color = UiOrange, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                    Text(projectName, color = UiText, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Text("DOCUMENTO", color = UiMuted, fontSize = 8.sp)
                    Text("${projectWidth} × ${projectHeight} px", color = UiText, fontSize = 10.sp)
                    Text("TAXA DE QUADROS", color = UiMuted, fontSize = 8.sp)
                    Text("$projectFps FPS", color = UiText, fontSize = 10.sp)
                    Text("FORMATO", color = UiMuted, fontSize = 8.sp)
                    Text("Mobile 2D Studio · .v2d", color = UiText, fontSize = 10.sp)
                }
            }
            Box(Modifier.fillMaxWidth().height(1.dp).background(UiLine))
            Column(Modifier.fillMaxWidth().background(Color(0xFF2A2A2A)).padding(7.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("DEFORMADORES", color = UiText, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.weight(1f))
                    Text("FASE 4", color = UiMuted, fontSize = 7.sp)
                }
                Text("Ainda não há deformadores neste projeto.", color = UiMuted, fontSize = 8.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text("Warp", color = Color(0xFF777777), fontSize = 8.sp, modifier = Modifier.weight(1f).background(Color(0xFF333333), RoundedCornerShape(2.dp)).padding(5.dp))
                    Text("Rotation", color = Color(0xFF777777), fontSize = 8.sp, modifier = Modifier.weight(1f).background(Color(0xFF333333), RoundedCornerShape(2.dp)).padding(5.dp))
                }
            }
        }
    }
}

private data class LayerRow(val part: Part, val depth: Int)

private fun buildLayerRows(parts: List<Part>, expandedGroups: Set<String>): List<LayerRow> {
    val canonical = PartTree.canonicalOrder(parts)
    val children = canonical.groupBy { it.parentId }
    val rows = ArrayList<LayerRow>(canonical.size)
    fun append(parentId: String?, depth: Int) {
        for (part in children[parentId].orEmpty().asReversed()) {
            rows.add(LayerRow(part, depth))
            if (part.kind == PartKind.GROUP && part.id in expandedGroups) append(part.id, depth + 1)
        }
    }
    append(null, 0)
    return rows
}

@Composable
private fun LayerTreeRow(
    row: LayerRow,
    selected: Boolean,
    expanded: Boolean,
    onSelect: () -> Unit,
    onToggleExpand: () -> Unit,
    onVisible: () -> Unit,
    onLock: () -> Unit
) {
    val part = row.part
    Row(
        Modifier.fillMaxWidth().height(38.dp)
            .background(if (selected) Color(0xFF59402B) else if (part.visible) Color(0xFF353535) else Color(0xFF303030)),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.width(38.dp).fillMaxHeight().clickable(onClick = onVisible), contentAlignment = Alignment.Center) {
            Text(if (part.visible) "◉" else "○", color = if (part.visible) UiOrange else UiMuted, fontSize = 14.sp)
        }
        Row(
            Modifier.weight(1f).fillMaxHeight().clickable(onClick = onSelect).padding(start = (row.depth * 12).dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.width(17.dp).fillMaxHeight().clickable(enabled = part.kind == PartKind.GROUP, onClick = onToggleExpand), contentAlignment = Alignment.Center) {
                Text(if (part.kind == PartKind.GROUP) if (expanded) "▾" else "▸" else "·", color = if (part.kind == PartKind.GROUP) UiOrange else UiMuted, fontSize = 12.sp)
            }
            Text(if (part.kind == PartKind.GROUP) "▰" else "▧", color = if (part.kind == PartKind.GROUP) UiOrange else UiMuted, fontSize = 11.sp)
            Text(part.name, color = if (selected) Color.White else UiText, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(start = 5.dp))
        }
        Box(Modifier.width(38.dp).fillMaxHeight().clickable(onClick = onLock), contentAlignment = Alignment.Center) {
            Text(if (part.locked) "▣" else "□", color = if (part.locked) UiOrange else UiMuted, fontSize = 12.sp)
        }
    }
    Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0xFF292929)))
}

@Composable
private fun InspectorDock(
    selectedPart: Part?,
    selectedCount: Int,
    modifier: Modifier,
    onNameChange: (String, String) -> Unit,
    onTransformChange: (String, Transform2D) -> Unit,
    onOpacityChange: (String, Float) -> Unit,
    onVisibleChange: (String, Boolean) -> Unit,
    onLockChange: (String, Boolean) -> Unit,
    onDelete: (String) -> Unit,
    onMove: (String, Int) -> Unit
) {
    Surface(modifier, color = UiPanel, shape = RoundedCornerShape(2.dp)) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            DockHeader("DETALHES DA FERRAMENTA")
            Column(Modifier.fillMaxWidth().background(Color(0xFF2B2B2B)).padding(horizontal = 9.dp, vertical = 6.dp)) {
                Text("Seleção / transformação", color = UiText, fontSize = 9.sp)
                Text("Toque numa peça para selecionar; arraste no canvas para mover.", color = UiMuted, fontSize = 8.sp)
            }
            DockHeader("INSPETOR")
            if (selectedPart == null) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(if (selectedCount > 1) "$selectedCount partes selecionadas" else "Nenhuma peça selecionada", color = UiText, fontSize = 11.sp)
                    Text("Selecione uma camada na árvore ou diretamente no canvas.", color = UiMuted, fontSize = 9.sp)
                }
            } else {
                val part = selectedPart
                Column(Modifier.fillMaxWidth().padding(horizontal = 9.dp, vertical = 7.dp)) {
                    Text("PROPRIEDADES", color = UiOrange, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(5.dp))
                    Text("Nome", color = UiMuted, fontSize = 9.sp)
                    BasicTextField(
                        value = part.name,
                        onValueChange = { onNameChange(part.id, it) },
                        singleLine = true,
                        textStyle = androidx.compose.ui.text.TextStyle(color = UiText, fontSize = 11.sp),
                        modifier = Modifier.fillMaxWidth().background(Color(0xFF262626), RoundedCornerShape(2.dp)).border(1.dp, Color(0xFF484848), RoundedCornerShape(2.dp)).padding(horizontal = 7.dp, vertical = 7.dp)
                    )
                    Spacer(Modifier.height(7.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        InspectorToggle("Visível", part.visible) { onVisibleChange(part.id, !part.visible) }
                        Spacer(Modifier.weight(1f))
                        InspectorToggle("Bloqueado", part.locked) { onLockChange(part.id, !part.locked) }
                    }
                    InspectorDivider()
                    Text("TRANSFORMAÇÃO LOCAL", color = UiOrange, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                    NumericControl("Posição X", part.transform.x, 10f, "%.1f") { onTransformChange(part.id, part.transform.copy(x = it)) }
                    NumericControl("Posição Y", part.transform.y, 10f, "%.1f") { onTransformChange(part.id, part.transform.copy(y = it)) }
                    NumericControl("Rotação", part.transform.rotationDeg, 5f, "%.1f°") { onTransformChange(part.id, part.transform.copy(rotationDeg = it)) }
                    NumericControl("Escala X", part.transform.scaleX, 0.05f, "%.2f") { onTransformChange(part.id, part.transform.copy(scaleX = it.coerceAtLeast(0.01f))) }
                    NumericControl("Escala Y", part.transform.scaleY, 0.05f, "%.2f") { onTransformChange(part.id, part.transform.copy(scaleY = it.coerceAtLeast(0.01f))) }
                    NumericControl("Opacidade", part.opacity, 0.05f, "%.2f") { onOpacityChange(part.id, it) }
                    InspectorDivider()
                    Text("ORDEM DE DESENHO", color = UiOrange, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        MiniAction("▲ Trazer à frente", true, { onMove(part.id, 1) })
                        MiniAction("▼ Enviar ao fundo", true, { onMove(part.id, -1) })
                    }
                    Spacer(Modifier.height(7.dp))
                    Text("TIPO  ·  ${if (part.kind == PartKind.GROUP) "GRUPO" else "MALHA"}", color = UiMuted, fontSize = 8.sp)
                    Text("ID  ·  ${part.id.take(12)}…", color = UiMuted, fontSize = 8.sp, maxLines = 1)
                    MiniAction("EXCLUIR PEÇA", true, { onDelete(part.id) }, destructive = true)
                }
            }
            InspectorDivider()
            Column(Modifier.fillMaxWidth().padding(9.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text("PARÂMETROS", color = UiText, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                Text("Controles de parâmetros e keyforms serão ativados na Fase 4.", color = UiMuted, fontSize = 9.sp)
                DisabledRow("Ângulo X / Y")
                DisabledRow("Parâmetros de expressão")
            }
        }
    }
}

@Composable
private fun NumericControl(label: String, value: Float, step: Float, format: String, onChange: (Float) -> Unit) {
    Row(Modifier.fillMaxWidth().height(30.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = UiText, fontSize = 9.sp, modifier = Modifier.weight(1f), maxLines = 1)
        TextButton(onClick = { onChange(value - step) }, modifier = Modifier.size(width = 28.dp, height = 27.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)) {
            Text("−", color = UiMuted, fontSize = 15.sp)
        }
        Text(String.format(java.util.Locale.US, format, value), color = UiText, fontSize = 9.sp, modifier = Modifier.width(48.dp), maxLines = 1)
        TextButton(onClick = { onChange(value + step) }, modifier = Modifier.size(width = 28.dp, height = 27.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)) {
            Text("+", color = UiOrange, fontSize = 14.sp)
        }
    }
}

@Composable
private fun InspectorToggle(label: String, checked: Boolean, onClick: () -> Unit) {
    Row(Modifier.clickable(onClick = onClick).padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(if (checked) "☑" else "□", color = if (checked) UiOrange else UiMuted, fontSize = 12.sp)
        Text(label, color = UiText, fontSize = 9.sp, modifier = Modifier.padding(start = 4.dp))
    }
}

@Composable
private fun EditorStatusBar(status: String, dirty: Boolean, selectedCount: Int) {
    Row(
        Modifier.fillMaxWidth().height(29.dp).background(Color(0xFF292929)).navigationBarsPadding().padding(horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        TinyStatus("MODELAGEM")
        StatusDivider()
        TinyStatus(if (selectedCount == 0) "Nenhuma seleção" else "$selectedCount selecionada(s)")
        Spacer(Modifier.weight(1f))
        if (dirty) TinyStatus("● NÃO SALVO", UiOrange)
        if (status.isNotBlank()) TinyStatus(status, UiMuted)
    }
}

@Composable
private fun DockTab(label: String, active: Boolean, onClick: () -> Unit) {
    Box(Modifier.fillMaxHeight().clickable(onClick = onClick).background(if (active) UiPanel else Color(0xFF292929)).padding(horizontal = 10.dp), contentAlignment = Alignment.Center) {
        Text(label, color = if (active) UiOrange else UiMuted, fontSize = 8.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun DockHeader(label: String) {
    Row(Modifier.fillMaxWidth().height(34.dp).background(Color(0xFF292929)).padding(horizontal = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = UiText, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.weight(1f))
        Text("···", color = UiMuted, fontSize = 13.sp)
    }
}

@Composable
private fun MiniAction(label: String, enabled: Boolean, onClick: () -> Unit, destructive: Boolean = false) {
    Text(
        label,
        color = if (!enabled) Color(0xFF666666) else if (destructive) Color(0xFFE08080) else UiText,
        fontSize = 8.sp,
        modifier = Modifier
            .background(if (enabled) Color(0xFF414141) else Color(0xFF303030), RoundedCornerShape(2.dp))
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 6.dp, vertical = 5.dp)
    )
}

@Composable
private fun DisabledRow(label: String) {
    Row(Modifier.fillMaxWidth().background(Color(0xFF2B2B2B), RoundedCornerShape(2.dp)).padding(horizontal = 7.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("○", color = Color(0xFF666666), fontSize = 10.sp)
        Text(label, color = Color(0xFF777777), fontSize = 9.sp, modifier = Modifier.padding(start = 6.dp))
        Spacer(Modifier.weight(1f))
        Text("FASE 4", color = Color(0xFF696969), fontSize = 7.sp)
    }
}

@Composable
private fun ToolButton(label: String, description: String, active: Boolean, onClick: () -> Unit, enabled: Boolean = true, width: androidx.compose.ui.unit.Dp = 40.dp) {
    Column(
        Modifier.width(width).height(40.dp)
            .background(if (active && enabled) Color(0xFF57412C) else Color.Transparent, RoundedCornerShape(3.dp))
            .clickable(enabled = enabled, onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(label, color = if (!enabled) Color(0xFF666666) else if (active) UiOrange else UiText, fontSize = 17.sp, lineHeight = 17.sp)
        Text(description.take(7), color = if (enabled) UiMuted else Color(0xFF666666), fontSize = 6.sp, maxLines = 1)
    }
}

@Composable
private fun CommandDivider() {
    Box(Modifier.width(1.dp).height(26.dp).background(UiLine).padding(horizontal = 3.dp))
}

@Composable
private fun TinyStatus(text: String, color: Color = UiMuted) {
    Text(text, color = color, fontSize = 8.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
}

@Composable
private fun InspectorDivider() {
    Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0xFF242424)).padding(vertical = 3.dp))
}

@Composable
private fun StatusDivider() {
    Box(Modifier.width(1.dp).height(12.dp).background(UiLine).padding(horizontal = 4.dp))
}

private fun queryDisplayName(context: Context, uri: Uri): String? = try {
    context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
        if (cursor.moveToFirst()) cursor.getString(0) else null
    }
} catch (_: Exception) { null }

private fun readLimited(context: Context, uri: Uri, limit: Long): ByteArray {
    context.contentResolver.openFileDescriptor(uri, "r")?.use { descriptor ->
        if (descriptor.statSize > limit) throw IllegalArgumentException("Arquivo excede o limite de 512 MB.")
    }
    val input = context.contentResolver.openInputStream(uri)
        ?: throw IllegalArgumentException("Não foi possível abrir o arquivo selecionado.")
    input.use { stream ->
        val output = ByteArrayOutputStream()
        val buffer = ByteArray(64 * 1024)
        var total = 0L
        while (true) {
            val read = stream.read(buffer)
            if (read < 0) break
            total += read
            if (total > limit) throw IllegalArgumentException("Arquivo excede o limite de 512 MB.")
            output.write(buffer, 0, read)
        }
        return output.toByteArray()
    }
}
