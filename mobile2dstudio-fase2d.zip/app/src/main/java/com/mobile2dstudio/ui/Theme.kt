package com.mobile2dstudio.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val StudioColors = darkColorScheme(
    primary = Color(0xFFE8A33D),
    onPrimary = Color(0xFF21180D),
    secondary = Color(0xFFC94A5A),
    onSecondary = Color(0xFFFFFFFF),
    background = Color(0xFF252525),
    onBackground = Color(0xFFD0D0D0),
    surface = Color(0xFF323232),
    onSurface = Color(0xFFD0D0D0),
    surfaceVariant = Color(0xFF3B3B3B),
    onSurfaceVariant = Color(0xFFAAAAAA),
    outline = Color(0xFF555555),
    error = Color(0xFFE08080)
)

@Composable
fun Mobile2DTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = StudioColors, content = content)
}
