package com.mobile2dstudio.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mobile2dstudio.project.ProjectInfo
import com.mobile2dstudio.project.ProjectMeta
import com.mobile2dstudio.project.ProjectRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.DateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProjectListScreen(repository: ProjectRepository, onOpen: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }
    var projects by remember { mutableStateOf<List<ProjectInfo>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var showCreate by remember { mutableStateOf(false) }
    var renameTarget by remember { mutableStateOf<ProjectMeta?>(null) }
    var deleteTarget by remember { mutableStateOf<ProjectMeta?>(null) }

    suspend fun refresh() {
        loading = true
        projects = withContext(Dispatchers.IO) { repository.list() }
        loading = false
    }

    fun runOp(op: () -> Unit) {
        scope.launch {
            try { withContext(Dispatchers.IO) { op() } }
            catch (e: Exception) { snackbar.showSnackbar(e.message ?: "Erro desconhecido") }
            refresh()
        }
    }

    LaunchedEffect(Unit) { refresh() }

    Scaffold(
        containerColor = Color(0xFF252525),
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("MOBILE 2D STUDIO", fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                        Text("EDITOR DE ILUSTRAÇÃO E ANIMAÇÃO 2D", fontSize = 8.sp, color = Color(0xFF999999))
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF303030),
                    titleContentColor = Color(0xFFD0D0D0)
                )
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showCreate = true },
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text("NOVO PROJETO", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                containerColor = Color(0xFFE8A33D),
                contentColor = Color(0xFF21180D),
                shape = RoundedCornerShape(4.dp)
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize().background(Color(0xFF252525))) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 16.dp)) {
                Text("PROJETOS", color = Color(0xFFE8A33D), fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Text("Abra um trabalho recente ou crie uma nova tela.", color = Color(0xFFAAAAAA), fontSize = 11.sp)
            }
            Box(Modifier.weight(1f).fillMaxWidth()) {
                when {
                    loading && projects.isEmpty() -> CircularProgressIndicator(Modifier.align(Alignment.Center), color = Color(0xFFE8A33D))
                    projects.isEmpty() -> Column(
                        Modifier.align(Alignment.Center).padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text("▧", color = Color(0xFFE8A33D), fontSize = 36.sp)
                        Text("Nenhum projeto ainda", color = Color(0xFFD0D0D0), fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        Text("Crie um projeto ou importe uma ilustração em camadas no editor.", color = Color(0xFF999999), fontSize = 10.sp)
                    }
                    else -> LazyColumn(
                        contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 2.dp, bottom = 92.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(projects, key = { it.meta.id }) { info ->
                            ProjectCard(
                                info = info,
                                onOpen = { onOpen(info.meta.id) },
                                onRename = { renameTarget = info.meta },
                                onDuplicate = { runOp { repository.duplicate(info.meta.id) } },
                                onDelete = { deleteTarget = info.meta }
                            )
                        }
                    }
                }
            }
        }
    }

    if (showCreate) {
        CreateProjectDialog(
            onDismiss = { showCreate = false },
            onCreate = { name, w, h, fps ->
                showCreate = false
                scope.launch {
                    try {
                        val created = withContext(Dispatchers.IO) { repository.create(name, w, h, fps) }
                        onOpen(created.meta.id)
                    } catch (e: Exception) { snackbar.showSnackbar(e.message ?: "Erro ao criar projeto") }
                }
            }
        )
    }

    renameTarget?.let { target ->
        TextInputDialog(
            title = "Renomear projeto", initial = target.name,
            onDismiss = { renameTarget = null },
            onConfirm = { newName -> renameTarget = null; runOp { repository.rename(target.id, newName) } }
        )
    }

    deleteTarget?.let { target ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text("Excluir projeto?") },
            text = { Text("“${target.name}” será removido permanentemente.") },
            confirmButton = {
                TextButton(onClick = { deleteTarget = null; runOp { repository.delete(target.id) } }) { Text("Excluir") }
            },
            dismissButton = { TextButton(onClick = { deleteTarget = null }) { Text("Cancelar") } }
        )
    }
}

@Composable
private fun ProjectCard(
    info: ProjectInfo,
    onOpen: () -> Unit,
    onRename: () -> Unit,
    onDuplicate: () -> Unit,
    onDelete: () -> Unit
) {
    var menuOpen by remember { mutableStateOf(false) }
    val meta = info.meta
    Row(
        Modifier.fillMaxWidth()
            .background(Color(0xFF323232), RoundedCornerShape(3.dp))
            .border(1.dp, Color(0xFF414141), RoundedCornerShape(3.dp))
            .clickable(onClick = onOpen)
            .padding(start = 10.dp, top = 8.dp, bottom = 8.dp, end = 3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(38.dp).background(Color(0xFF45403A), RoundedCornerShape(2.dp)),
            contentAlignment = Alignment.Center
        ) { Text("▧", color = Color(0xFFE8A33D), fontSize = 21.sp) }
        Column(Modifier.weight(1f).padding(horizontal = 10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(meta.name, color = Color(0xFFD0D0D0), fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                "${meta.width} × ${meta.height} px   ·   ${meta.fps} FPS   ·   ${formatSize(info.sizeBytes)}",
                color = Color(0xFFAAAAAA), fontSize = 9.sp, maxLines = 1
            )
            Text(
                "Modificado: " + DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(meta.modifiedAt)),
                color = Color(0xFF888888), fontSize = 8.sp
            )
        }
        Box {
            IconButton(onClick = { menuOpen = true }) { Icon(Icons.Default.MoreVert, contentDescription = "Mais opções", tint = Color(0xFFAAAAAA)) }
            DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                DropdownMenuItem(text = { Text("Renomear") }, onClick = { menuOpen = false; onRename() })
                DropdownMenuItem(text = { Text("Duplicar") }, onClick = { menuOpen = false; onDuplicate() })
                DropdownMenuItem(text = { Text("Excluir") }, onClick = { menuOpen = false; onDelete() })
            }
        }
    }
}

private fun formatSize(bytes: Long): String =
    if (bytes < 1024) "$bytes B" else String.format(Locale.getDefault(), "%.1f KB", bytes / 1024.0)

@Composable
private fun CreateProjectDialog(
    onDismiss: () -> Unit,
    onCreate: (name: String, width: Int, height: Int, fps: Int) -> Unit
) {
    var name by remember { mutableStateOf("Novo projeto") }
    var width by remember { mutableStateOf("1080") }
    var height by remember { mutableStateOf("1920") }
    var fps by remember { mutableStateOf("30") }
    var error by remember { mutableStateOf<String?>(null) }
    val number = KeyboardOptions(keyboardType = KeyboardType.Number)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Novo projeto") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Nome") }, singleLine = true)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        width, { width = it }, Modifier.weight(1f),
                        label = { Text("Largura") }, singleLine = true, keyboardOptions = number
                    )
                    OutlinedTextField(
                        height, { height = it }, Modifier.weight(1f),
                        label = { Text("Altura") }, singleLine = true, keyboardOptions = number
                    )
                }
                OutlinedTextField(
                    fps, { fps = it }, label = { Text("FPS") }, singleLine = true, keyboardOptions = number
                )
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val w = width.toIntOrNull()
                val h = height.toIntOrNull()
                val f = fps.toIntOrNull()
                if (w == null || h == null || f == null) {
                    error = "Largura, altura e FPS devem ser números inteiros."
                } else {
                    onCreate(name, w, h, f)
                }
            }) { Text("Criar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
private fun TextInputDialog(
    title: String,
    initial: String,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { OutlinedTextField(text, { text = it }, singleLine = true) },
        confirmButton = { TextButton(onClick = { onConfirm(text) }) { Text("OK") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}
