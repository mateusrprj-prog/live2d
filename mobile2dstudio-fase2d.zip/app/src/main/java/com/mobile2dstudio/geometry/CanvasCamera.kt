package com.mobile2dstudio.geometry

import kotlin.math.max
import kotlin.math.min

data class Vec2(val x: Float, val y: Float)

/**
 * Câmera 2D do canvas. Lógica pura (sem Android) para poder ser testada na JVM.
 *
 * Sistemas de coordenadas:
 *  - Mundo: unidades de canvas, origem no centro do canvas, eixo Y para CIMA.
 *  - Tela: pixels, origem no canto superior esquerdo, eixo Y para BAIXO.
 */
class CanvasCamera {
    var centerX = 0f
    var centerY = 0f
    var zoom = 1f

    var viewportWidth = 1
        private set
    var viewportHeight = 1
        private set

    fun setViewport(width: Int, height: Int) {
        viewportWidth = max(1, width)
        viewportHeight = max(1, height)
    }

    fun worldToScreen(wx: Float, wy: Float): Vec2 = Vec2(
        (wx - centerX) * zoom + viewportWidth / 2f,
        viewportHeight / 2f - (wy - centerY) * zoom
    )

    fun screenToWorld(sx: Float, sy: Float): Vec2 = Vec2(
        (sx - viewportWidth / 2f) / zoom + centerX,
        (viewportHeight / 2f - sy) / zoom + centerY
    )

    /** Move o conteúdo junto com o dedo (dx, dy em pixels de tela). */
    fun panByScreen(dx: Float, dy: Float) {
        centerX -= dx / zoom
        centerY += dy / zoom
    }

    /** Aplica [factor] ao zoom mantendo fixo o ponto do mundo sob (sx, sy). */
    fun zoomAt(factor: Float, sx: Float, sy: Float) {
        val before = screenToWorld(sx, sy)
        zoom = (zoom * factor).coerceIn(MIN_ZOOM, MAX_ZOOM)
        val after = screenToWorld(sx, sy)
        centerX += before.x - after.x
        centerY += before.y - after.y
    }

    /** Enquadra uma área de mundo centrada em (cx, cy) ocupando [fill] da viewport. */
    fun fit(worldWidth: Float, worldHeight: Float, fill: Float = 0.9f, cx: Float = 0f, cy: Float = 0f) {
        val z = min(viewportWidth / worldWidth, viewportHeight / worldHeight) * fill
        zoom = z.coerceIn(MIN_ZOOM, MAX_ZOOM)
        centerX = cx
        centerY = cy
    }

    /** Matriz ortográfica mundo -> clip, em ordem column-major (formato OpenGL). */
    fun projectionMatrix(out: FloatArray) {
        require(out.size >= 16) { "out precisa ter 16 floats" }
        out.fill(0f, 0, 16)
        val sx = 2f * zoom / viewportWidth
        val sy = 2f * zoom / viewportHeight
        out[0] = sx
        out[5] = sy
        out[10] = 1f
        out[12] = -centerX * sx
        out[13] = -centerY * sy
        out[15] = 1f
    }

    companion object {
        const val MIN_ZOOM = 0.02f
        const val MAX_ZOOM = 64f
    }
}
