package com.mobile2dstudio.geometry

import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

/**
 * Transformação afim 2D (lógica pura, testável na JVM):
 *   x' = a*x + c*y + tx
 *   y' = b*x + d*y + ty
 */
class Affine(
    val a: Float,
    val b: Float,
    val c: Float,
    val d: Float,
    val tx: Float,
    val ty: Float
) {
    fun apply(x: Float, y: Float): Vec2 = Vec2(a * x + c * y + tx, b * x + d * y + ty)

    /** Aplica só a parte linear (sem translação): serve para deslocamentos/direções. */
    fun applyVector(x: Float, y: Float): Vec2 = Vec2(a * x + c * y, b * x + d * y)

    /** this * o: aplica [o] primeiro e depois this. */
    operator fun times(o: Affine): Affine = Affine(
        a = a * o.a + c * o.b,
        b = b * o.a + d * o.b,
        c = a * o.c + c * o.d,
        d = b * o.c + d * o.d,
        tx = a * o.tx + c * o.ty + tx,
        ty = b * o.tx + d * o.ty + ty
    )

    fun determinant(): Float = a * d - b * c

    /** Inversa, ou null se a matriz for singular. */
    fun inverse(): Affine? {
        val det = determinant()
        if (abs(det) < 1e-12f) return null
        val ia = d / det
        val ic = -c / det
        val ib = -b / det
        val id = a / det
        return Affine(ia, ib, ic, id, -(ia * tx + ic * ty), -(ib * tx + id * ty))
    }

    /** Matriz 4x4 column-major (formato OpenGL) com Z identidade. */
    fun toMatrix4(out: FloatArray) {
        require(out.size >= 16) { "out precisa ter 16 floats" }
        out.fill(0f, 0, 16)
        out[0] = a
        out[1] = b
        out[4] = c
        out[5] = d
        out[10] = 1f
        out[12] = tx
        out[13] = ty
        out[15] = 1f
    }

    fun isNearly(o: Affine, eps: Float = 1e-5f): Boolean =
        abs(a - o.a) <= eps && abs(b - o.b) <= eps && abs(c - o.c) <= eps &&
            abs(d - o.d) <= eps && abs(tx - o.tx) <= eps && abs(ty - o.ty) <= eps

    companion object {
        val IDENTITY = Affine(1f, 0f, 0f, 1f, 0f, 0f)
    }
}

/**
 * Transformação local de uma parte, no espaço do pai: escala, depois rotação (graus,
 * anti-horária, Y para cima) e por fim translação. (x, y) é a posição da origem local
 * da parte dentro do pai.
 */
data class Transform2D(
    val x: Float = 0f,
    val y: Float = 0f,
    val rotationDeg: Float = 0f,
    val scaleX: Float = 1f,
    val scaleY: Float = 1f
) {
    fun toAffine(): Affine {
        val r = Math.toRadians(rotationDeg.toDouble())
        val cs = cos(r).toFloat()
        val sn = sin(r).toFloat()
        return Affine(cs * scaleX, sn * scaleX, -sn * scaleY, cs * scaleY, x, y)
    }

    fun isFinite(): Boolean =
        x.isFinite() && y.isFinite() && rotationDeg.isFinite() && scaleX.isFinite() && scaleY.isFinite()

    companion object {
        val IDENTITY = Transform2D()

        /** Decompõe uma afim em T/R/S (assume ausência de cisalhamento). */
        fun fromAffine(m: Affine): Transform2D {
            val sx = hypot(m.a, m.b)
            var sy = hypot(m.c, m.d)
            if (m.determinant() < 0f) sy = -sy
            val rot = atan2(m.b, m.a)
            return Transform2D(m.tx, m.ty, Math.toDegrees(rot.toDouble()).toFloat(), sx, sy)
        }
    }
}
