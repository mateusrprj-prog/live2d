package com.mobile2dstudio.imports

import com.mobile2dstudio.geometry.Transform2D
import com.mobile2dstudio.mesh.MeshGenerator
import com.mobile2dstudio.project.ImageAsset
import com.mobile2dstudio.project.Part
import com.mobile2dstudio.project.PartKind
import java.util.UUID

class LayerImportResult(
    val parts: List<Part>,
    val assets: List<ImageAsset>,
    val warnings: List<String>
)

/** Converte um [ImportedDocument] em partes/texturas do projeto. */
object LayerImport {

    /**
     * Cada camada de imagem vira uma parte MESH com malha-quadro 1x1 centrada na origem local e
     * `transform` = centro da camada no mundo (origem no centro do documento, Y para cima).
     * Cada grupo vira uma parte GROUP com transformação identidade. Lista em pré-ordem
     * (pai antes dos filhos), irmãos de trás para frente = ordem de desenho.
     */
    fun toParts(doc: ImportedDocument, newId: () -> String = { UUID.randomUUID().toString() }): LayerImportResult {
        val parts = ArrayList<Part>()
        val assets = ArrayList<ImageAsset>()
        val warnings = ArrayList<String>(doc.warnings)
        val docW = doc.width
        val docH = doc.height

        fun visit(layer: ImportedLayer, parentId: String?) {
            val id = newId()
            val opacity = if (layer.opacity.isNaN()) 1f else layer.opacity.coerceIn(0f, 1f)
            if (layer.isGroup) {
                parts += Part(
                    id = id, name = layer.name, parentId = parentId, visible = layer.visible, locked = false,
                    mesh = null, kind = PartKind.GROUP, opacity = opacity, transform = Transform2D.IDENTITY
                )
                for (c in layer.children) visit(c, id)
                return
            }
            val png = layer.png!!
            val info = try {
                ImageInfoReader.read(png)
            } catch (e: ImportException) {
                warnings += "Camada \"${layer.name}\" ignorada: ${e.message}"
                return
            }
            val w = info.width.toFloat()
            val h = info.height.toFloat()
            val assetId = newId()
            assets += ImageAsset(assetId, layer.name, info.width, info.height, info.format, png)
            parts += Part(
                id = id, name = layer.name, parentId = parentId, visible = layer.visible, locked = false,
                mesh = MeshGenerator.grid(w, h, 1, 1, -w / 2f, -h / 2f),
                kind = PartKind.MESH, opacity = opacity,
                transform = Transform2D(
                    x = layer.left + w / 2f - docW / 2f,
                    y = docH / 2f - (layer.top + h / 2f)
                ),
                textureId = assetId
            )
        }
        for (l in doc.layers) visit(l, null)
        return LayerImportResult(parts, assets, warnings)
    }
}

/** Detecta o formato pelos primeiros bytes e importa. */
object DocumentImporter {

    fun import(fileName: String, bytes: ByteArray): ImportedDocument {
        if (bytes.isEmpty()) throw ImportException("O arquivo está vazio.")
        return when {
            bytes.size >= 4 && bytes[0] == '8'.code.toByte() && bytes[1] == 'B'.code.toByte() &&
                bytes[2] == 'P'.code.toByte() && bytes[3] == 'S'.code.toByte() -> PsdImporter.read(bytes)
            ImageInfoReader.isPng(bytes) || ImageInfoReader.isJpeg(bytes) -> singleImage(fileName, bytes)
            bytes.size >= 4 && bytes[0] == 'P'.code.toByte() && bytes[1] == 'K'.code.toByte() -> OraImporter.read(bytes)
            else -> throw ImportException("Formato não suportado. Use PSD, ORA (OpenRaster), PNG ou JPEG.")
        }
    }

    fun singleImage(fileName: String, bytes: ByteArray): ImportedDocument {
        val info = ImageInfoReader.read(bytes)
        if (info.width > ImportLimits.MAX_DOCUMENT_SIDE || info.height > ImportLimits.MAX_DOCUMENT_SIDE)
            throw ImportException("Imagem grande demais (${info.width} x ${info.height}). Limite: ${ImportLimits.MAX_DOCUMENT_SIDE} px por lado.")
        val file = fileName.substringAfterLast('/').substringAfterLast('\\')
        val base = file.substringBeforeLast('.', file).trim().ifEmpty { "Imagem" }
        val layer = ImportedLayer(base, true, 1f, 0, 0, info.width, info.height, bytes)
        return ImportedDocument(info.width, info.height, listOf(layer), emptyList())
    }
}
