package com.mobile2dstudio.imports

import com.mobile2dstudio.project.ImageFormat
import java.io.ByteArrayOutputStream
import java.util.zip.CRC32
import java.util.zip.Deflater

/** Dimensões e formato de uma imagem PNG/JPEG, lidos do cabeçalho (sem decodificar pixels). */
class ImageInfo(val width: Int, val height: Int, val format: ImageFormat)

object ImageInfoReader {
    private val PNG_SIG = byteArrayOf(0x89.toByte(), 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A)

    fun isPng(b: ByteArray) = b.size >= 8 && PNG_SIG.indices.all { b[it] == PNG_SIG[it] }
    fun isJpeg(b: ByteArray) = b.size >= 3 && b[0] == 0xFF.toByte() && b[1] == 0xD8.toByte() && b[2] == 0xFF.toByte()

    /** Lê largura/altura de PNG (IHDR) ou JPEG (marcador SOF). Lança [ImportException] se inválido. */
    fun read(bytes: ByteArray): ImageInfo = when {
        isPng(bytes) -> readPng(bytes)
        isJpeg(bytes) -> readJpeg(bytes)
        else -> throw ImportException("Imagem não reconhecida (esperado PNG ou JPEG).")
    }

    private fun u32(b: ByteArray, o: Int): Long =
        ((b[o].toLong() and 0xFF) shl 24) or ((b[o + 1].toLong() and 0xFF) shl 16) or
            ((b[o + 2].toLong() and 0xFF) shl 8) or (b[o + 3].toLong() and 0xFF)

    private fun u16(b: ByteArray, o: Int): Int = ((b[o].toInt() and 0xFF) shl 8) or (b[o + 1].toInt() and 0xFF)

    private fun readPng(b: ByteArray): ImageInfo {
        // assinatura(8) + comprimento(4) + "IHDR"(4) + largura(4) + altura(4)
        if (b.size < 24 || b[12] != 'I'.code.toByte() || b[13] != 'H'.code.toByte() ||
            b[14] != 'D'.code.toByte() || b[15] != 'R'.code.toByte()
        ) throw ImportException("PNG inválido (cabeçalho IHDR ausente).")
        val w = u32(b, 16)
        val h = u32(b, 20)
        return checked(w, h, ImageFormat.PNG)
    }

    private fun readJpeg(b: ByteArray): ImageInfo {
        var i = 2
        while (i + 3 < b.size) {
            if (b[i] != 0xFF.toByte()) { i++; continue }
            var marker = b[i + 1].toInt() and 0xFF
            if (marker == 0xFF) { i++; continue } // bytes de preenchimento
            if (marker == 0x00 || marker == 0x01 || marker in 0xD0..0xD8) { i += 2; continue } // sem payload
            if (marker == 0xD9 || marker == 0xDA) break // fim / início dos dados antes de achar SOF
            if (i + 4 > b.size) break
            val len = u16(b, i + 2)
            val isSof = marker in 0xC0..0xCF && marker != 0xC4 && marker != 0xC8 && marker != 0xCC
            if (isSof) {
                if (len < 8 || i + 9 > b.size) break
                val h = u16(b, i + 5).toLong()
                val w = u16(b, i + 7).toLong()
                return checked(w, h, ImageFormat.JPEG)
            }
            if (len < 2) break
            i += 2 + len
        }
        throw ImportException("JPEG inválido ou truncado (dimensões não encontradas).")
    }

    private fun checked(w: Long, h: Long, f: ImageFormat): ImageInfo {
        if (w <= 0 || h <= 0) throw ImportException("Imagem com tamanho inválido ($w x $h).")
        if (w > ImportLimits.MAX_LAYER_SIDE || h > ImportLimits.MAX_LAYER_SIDE || w * h > ImportLimits.MAX_LAYER_PIXELS)
            throw ImportException("Imagem grande demais ($w x $h px). Limite: ${ImportLimits.MAX_LAYER_SIDE} px por lado.")
        return ImageInfo(w.toInt(), h.toInt(), f)
    }
}

/** Codificador PNG mínimo (RGBA 8 bits, sem filtro) usando só java.util.zip. */
object PngEncoder {
    private val SIG = byteArrayOf(0x89.toByte(), 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A)

    /** [rgba] = w*h*4 bytes, alfa direto (não pré-multiplicado), linhas de cima para baixo. */
    fun encodeRgba(width: Int, height: Int, rgba: ByteArray): ByteArray {
        require(width > 0 && height > 0) { "tamanho inválido" }
        require(rgba.size.toLong() == width.toLong() * height * 4) { "rgba deve ter w*h*4 bytes" }

        val out = ByteArrayOutputStream(rgba.size / 3 + 1024)
        out.write(SIG)

        val ihdr = ByteArray(13)
        putInt(ihdr, 0, width)
        putInt(ihdr, 4, height)
        ihdr[8] = 8 // profundidade
        ihdr[9] = 6 // RGBA
        chunk(out, "IHDR", ihdr, 0, ihdr.size)

        val deflater = Deflater(6)
        val idat = ByteArrayOutputStream(rgba.size / 3 + 1024)
        try {
            val rowBytes = width * 4
            val row = ByteArray(1 + rowBytes) // filtro 0 (None) + linha
            val buf = ByteArray(32 * 1024)
            for (y in 0 until height) {
                row[0] = 0
                System.arraycopy(rgba, y * rowBytes, row, 1, rowBytes)
                deflater.setInput(row)
                while (!deflater.needsInput()) {
                    val n = deflater.deflate(buf)
                    if (n > 0) idat.write(buf, 0, n)
                }
            }
            deflater.finish()
            while (!deflater.finished()) {
                val n = deflater.deflate(buf)
                if (n > 0) idat.write(buf, 0, n)
            }
        } finally {
            deflater.end()
        }
        val data = idat.toByteArray()
        chunk(out, "IDAT", data, 0, data.size)
        chunk(out, "IEND", ByteArray(0), 0, 0)
        return out.toByteArray()
    }

    private fun chunk(out: ByteArrayOutputStream, type: String, data: ByteArray, off: Int, len: Int) {
        val head = ByteArray(4)
        putInt(head, 0, len)
        out.write(head)
        val typeBytes = type.toByteArray(Charsets.US_ASCII)
        out.write(typeBytes)
        out.write(data, off, len)
        val crc = CRC32()
        crc.update(typeBytes)
        crc.update(data, off, len)
        putInt(head, 0, crc.value.toInt())
        out.write(head)
    }

    private fun putInt(b: ByteArray, o: Int, v: Int) {
        b[o] = (v ushr 24).toByte()
        b[o + 1] = (v ushr 16).toByte()
        b[o + 2] = (v ushr 8).toByte()
        b[o + 3] = v.toByte()
    }
}
