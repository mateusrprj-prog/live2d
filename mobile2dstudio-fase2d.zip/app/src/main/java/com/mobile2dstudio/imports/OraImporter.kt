package com.mobile2dstudio.imports

import org.w3c.dom.Element
import org.w3c.dom.Node
import java.io.ByteArrayInputStream
import java.io.InputStream
import java.util.zip.ZipInputStream
import javax.xml.parsers.DocumentBuilderFactory

/**
 * Importador OpenRaster (.ora): ZIP com `stack.xml` + PNGs. Pilhas aninhadas viram grupos.
 * Segurança: DOCTYPE/entidades recusados, caminhos normalizados (sem `..`), limites de tamanho.
 */
object OraImporter {

    fun read(bytes: ByteArray): ImportedDocument {
        val warnings = Warnings()
        val stackXml = readStackXml(bytes)
        val xml = String(stackXml, Charsets.UTF_8)
        if (xml.contains("<!DOCTYPE", ignoreCase = true) || xml.contains("<!ENTITY", ignoreCase = true))
            throw ImportException("O stack.xml do ORA contém DOCTYPE/entidades, que não são aceitos por segurança.")

        val doc = try {
            val f = DocumentBuilderFactory.newInstance()
            // Alguns recursos não existem em todas as implementações (ex.: Android): ignorar se recusado.
            fun tryFeature(name: String, value: Boolean) {
                try { f.setFeature(name, value) } catch (_: Exception) { /* sem suporte */ }
            }
            tryFeature("http://apache.org/xml/features/disallow-doctype-decl", true)
            tryFeature("http://xml.org/sax/features/external-general-entities", false)
            tryFeature("http://xml.org/sax/features/external-parameter-entities", false)
            tryFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false)
            try { f.isXIncludeAware = false } catch (_: Exception) { }
            try { f.isExpandEntityReferences = false } catch (_: Exception) { }
            f.newDocumentBuilder().parse(ByteArrayInputStream(stackXml))
        } catch (e: Exception) {
            throw ImportException("stack.xml do ORA ilegível: ${e.message}", e)
        }

        val root = doc.documentElement
        if (root == null || root.nodeName != "image") throw ImportException("stack.xml inválido: elemento <image> ausente.")
        val w = root.getAttribute("w").trim().toIntOrNull()
        val h = root.getAttribute("h").trim().toIntOrNull()
        if (w == null || h == null || w <= 0 || h <= 0)
            throw ImportException("stack.xml sem largura/altura válidas (atributos w e h).")
        if (w > ImportLimits.MAX_DOCUMENT_SIDE || h > ImportLimits.MAX_DOCUMENT_SIDE)
            throw ImportException("Documento grande demais ($w x $h). Limite: ${ImportLimits.MAX_DOCUMENT_SIDE} px por lado.")

        val rootStack = elementChildren(root).firstOrNull { it.nodeName == "stack" }
            ?: throw ImportException("stack.xml sem <stack>: nenhuma camada encontrada.")

        // 1º passo: descobrir quais PNGs são necessários.
        val needed = LinkedHashSet<String>()
        collectSources(rootStack, needed, warnings)
        val images = readEntries(bytes, needed)

        val ctx = Ctx(images, warnings)
        val layers = buildStack(rootStack, ctx, 0)
        if (ctx.count == 0) throw ImportException("O arquivo ORA não tem nenhuma camada de imagem.")
        if (ctx.blendCount > 0)
            warnings.add("${ctx.blendCount} camada(s) usam modos de mesclagem não suportados; importadas como normais.")
        return ImportedDocument(w, h, layers, warnings.toList())
    }

    private class Ctx(val images: Map<String, ByteArray>, val warnings: Warnings) {
        var count = 0
        var blendCount = 0
    }

    private fun elementChildren(e: Element): List<Element> {
        val out = ArrayList<Element>()
        var n: Node? = e.firstChild
        while (n != null) {
            if (n.nodeType == Node.ELEMENT_NODE) out += n as Element
            n = n.nextSibling
        }
        return out
    }

    private fun collectSources(stack: Element, out: MutableSet<String>, warnings: Warnings) {
        for (c in elementChildren(stack)) {
            when (c.nodeName) {
                "stack" -> collectSources(c, out, warnings)
                "layer" -> {
                    val p = normalizePath(c.getAttribute("src"))
                    if (p != null) out += p
                }
            }
        }
    }

    /** Normaliza caminho de entrada ZIP; null se inseguro/vazio (absoluto, `..`, unidade). */
    fun normalizePath(raw: String): String? {
        val s = raw.trim().replace('\\', '/')
        if (s.isEmpty() || s.startsWith("/") || (s.length >= 2 && s[1] == ':')) return null
        val parts = ArrayList<String>()
        for (seg in s.split('/')) {
            when (seg) {
                "", "." -> {}
                ".." -> return null
                else -> parts += seg
            }
        }
        return if (parts.isEmpty()) null else parts.joinToString("/")
    }

    private fun buildStack(stack: Element, ctx: Ctx, depth: Int): List<ImportedLayer> {
        if (depth > ImportLimits.MAX_GROUP_DEPTH) throw ImportException("Grupos aninhados demais (limite ${ImportLimits.MAX_GROUP_DEPTH}).")
        val out = ArrayList<ImportedLayer>()
        // No XML o PRIMEIRO elemento é o TOPO; o modelo guarda de trás para frente.
        for (c in elementChildren(stack).asReversed()) {
            when (c.nodeName) {
                "stack" -> {
                    val children = buildStack(c, ctx, depth + 1)
                    countBlend(c, ctx)
                    out += ImportedLayer(
                        name = nameOf(c, "Grupo"), visible = visibleOf(c), opacity = opacityOf(c),
                        left = 0, top = 0, width = 0, height = 0, png = null, children = children
                    )
                }
                "layer" -> {
                    val src = normalizePath(c.getAttribute("src"))
                    if (src == null) {
                        ctx.warnings.add("Camada \"${nameOf(c, "?")}\" ignorada: caminho de imagem ausente ou inseguro.")
                        continue
                    }
                    val data = ctx.images[src]
                    if (data == null) {
                        ctx.warnings.add("Camada \"${nameOf(c, "?")}\" ignorada: imagem $src não encontrada no arquivo.")
                        continue
                    }
                    val info = try {
                        ImageInfoReader.read(data)
                    } catch (e: ImportException) {
                        ctx.warnings.add("Camada \"${nameOf(c, "?")}\" ignorada: ${e.message}")
                        continue
                    }
                    if (ctx.count >= ImportLimits.MAX_LAYERS) throw ImportException("Camadas demais (limite ${ImportLimits.MAX_LAYERS}).")
                    ctx.count++
                    countBlend(c, ctx)
                    out += ImportedLayer(
                        name = nameOf(c, "Camada ${ctx.count}"), visible = visibleOf(c), opacity = opacityOf(c),
                        left = c.getAttribute("x").trim().toIntOrNull() ?: 0,
                        top = c.getAttribute("y").trim().toIntOrNull() ?: 0,
                        width = info.width, height = info.height, png = data
                    )
                }
                else -> ctx.warnings.add("Elemento <${c.nodeName}> do stack.xml ignorado.")
            }
        }
        return out
    }

    private fun countBlend(e: Element, ctx: Ctx) {
        val op = e.getAttribute("composite-op").trim()
        if (op.isNotEmpty() && op != "svg:src-over") ctx.blendCount++
    }

    private fun nameOf(e: Element, fallback: String): String = e.getAttribute("name").trim().ifEmpty { fallback }
    private fun visibleOf(e: Element): Boolean = !e.getAttribute("visibility").trim().equals("hidden", ignoreCase = true)
    private fun opacityOf(e: Element): Float {
        val v = e.getAttribute("opacity").trim().toFloatOrNull() ?: return 1f
        return if (v.isNaN()) 1f else v.coerceIn(0f, 1f)
    }

    // ---- ZIP ----

    private fun openZip(bytes: ByteArray) = ZipInputStream(ByteArrayInputStream(bytes))

    private fun readStackXml(bytes: ByteArray): ByteArray {
        try {
            openZip(bytes).use { zis ->
                var entries = 0
                while (true) {
                    val e = zis.nextEntry ?: break
                    if (++entries > ImportLimits.MAX_ZIP_ENTRIES) throw ImportException("ORA com entradas demais.")
                    if (!e.isDirectory && normalizePath(e.name) == "stack.xml")
                        return readLimited(zis, ImportLimits.MAX_XML_BYTES, "stack.xml")
                }
            }
        } catch (e: java.io.IOException) {
            throw ImportException("Arquivo ORA corrompido ou não é um ZIP: ${e.message}", e)
        }
        throw ImportException("Arquivo ZIP sem stack.xml: não é um ORA (OpenRaster) válido.")
    }

    private fun readEntries(bytes: ByteArray, wanted: Set<String>): Map<String, ByteArray> {
        val out = HashMap<String, ByteArray>()
        if (wanted.isEmpty()) return out
        var total = 0L
        try {
            openZip(bytes).use { zis ->
                var entries = 0
                while (true) {
                    val e = zis.nextEntry ?: break
                    if (++entries > ImportLimits.MAX_ZIP_ENTRIES) throw ImportException("ORA com entradas demais.")
                    if (e.isDirectory) continue
                    val name = normalizePath(e.name) ?: continue
                    if (name !in wanted || out.containsKey(name)) continue
                    val data = readLimited(zis, minOf(ImportLimits.MAX_ENTRY_BYTES, ImportLimits.MAX_TOTAL_BYTES - total), name)
                    total += data.size
                    out[name] = data
                }
            }
        } catch (e: java.io.IOException) {
            throw ImportException("Arquivo ORA corrompido: ${e.message}", e)
        }
        return out
    }

    private fun readLimited(input: InputStream, max: Long, what: String): ByteArray {
        val out = java.io.ByteArrayOutputStream()
        val buf = ByteArray(64 * 1024)
        var total = 0L
        while (true) {
            val n = input.read(buf)
            if (n < 0) break
            total += n
            if (total > max) throw ImportException("\"$what\" é grande demais após descompactar (possível arquivo malicioso).")
            out.write(buf, 0, n)
        }
        return out.toByteArray()
    }
}
