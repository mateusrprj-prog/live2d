package com.mobile2dstudio.imports

/** Erro de importação com mensagem pronta para mostrar ao usuário (português). */
class ImportException(message: String, cause: Throwable? = null) : Exception(message, cause)

/** Limites de segurança/compatibilidade da importação. */
object ImportLimits {
    /** Mesmo teto de resolução aceito por `ProjectRepository.create`. */
    const val MAX_DOCUMENT_SIDE = 8192
    /** Lado máximo de uma camada (camadas podem passar do canvas). */
    const val MAX_LAYER_SIDE = 16384
    /** Pixels máximos por camada (RGBA 8 bits = 4 bytes/pixel na memória). */
    const val MAX_LAYER_PIXELS = 40_000_000L
    const val MAX_LAYERS = 2000
    /** Anti zip-bomb (ORA). */
    const val MAX_ZIP_ENTRIES = 4096
    const val MAX_ENTRY_BYTES = 128L * 1024 * 1024
    const val MAX_TOTAL_BYTES = 512L * 1024 * 1024
    const val MAX_XML_BYTES = 8L * 1024 * 1024
    const val MAX_GROUP_DEPTH = 64
}

/**
 * Camada importada. Grupo: [png] == null e [children] preenchido, **de trás para frente**.
 * Camada de imagem: [png] guarda um arquivo PNG (ou JPEG) completo; [left]/[top] em pixels
 * a partir do canto superior esquerdo do documento (Y para baixo); [width]/[height] = tamanho da imagem.
 */
class ImportedLayer(
    val name: String,
    val visible: Boolean,
    val opacity: Float,
    val left: Int,
    val top: Int,
    val width: Int,
    val height: Int,
    val png: ByteArray?,
    val children: List<ImportedLayer> = emptyList()
) {
    val isGroup: Boolean get() = png == null
}

/** [layers] de trás para frente (índice 0 = fundo). */
class ImportedDocument(
    val width: Int,
    val height: Int,
    val layers: List<ImportedLayer>,
    val warnings: List<String>
) {
    /** Quantidade de camadas de imagem (folhas), contando dentro de grupos. */
    fun imageLayerCount(): Int {
        fun count(l: ImportedLayer): Int = if (l.isGroup) l.children.sumOf { count(it) } else 1
        return layers.sumOf { count(it) }
    }
}

/** Coletor de avisos sem repetição, com contador para mensagens agregadas. */
internal class Warnings {
    private val list = ArrayList<String>()
    private val seen = HashSet<String>()
    fun add(msg: String) {
        if (seen.add(msg)) list += msg
    }
    fun toList(): List<String> = list.toList()
}
