package com.mobile2dstudio.imports

import java.util.zip.DataFormatException
import java.util.zip.Inflater

/**
 * Parser PSD próprio (Adobe Photoshop, versão 1). Suporta RGB e tons de cinza, 8 e 16 bits
 * (16 bits convertido pelo byte alto), compressões 0 raw / 1 RLE / 2 ZIP / 3 ZIP+predição,
 * grupos aninhados, visibilidade e opacidade. Não achata o documento em silêncio:
 * PSD sem camadas, CMYK, Lab, PSB etc. geram erro claro.
 */
object PsdImporter {

    fun read(bytes: ByteArray): ImportedDocument {
        val warnings = Warnings()
        val r = ByteReader(bytes)

        // ---- cabeçalho ----
        if (bytes.size < 26 || r.ascii(4) != "8BPS") throw ImportException("Arquivo PSD inválido (assinatura 8BPS ausente).")
        val version = r.u16()
        if (version == 2) throw ImportException("PSB (documento grande do Photoshop) não é suportado. Salve como PSD.")
        if (version != 1) throw ImportException("Versão de PSD desconhecida ($version).")
        r.skip(6)
        r.u16() // canais do documento (não usado)
        val docH = r.u32()
        val docW = r.u32()
        val depth = r.u16()
        val mode = r.u16()

        if (docW < 1 || docH < 1 || docW > ImportLimits.MAX_DOCUMENT_SIDE || docH > ImportLimits.MAX_DOCUMENT_SIDE)
            throw ImportException("Documento PSD com tamanho não suportado ($docW x $docH). Limite: ${ImportLimits.MAX_DOCUMENT_SIDE} px por lado.")
        if (mode != 3 && mode != 1) throw ImportException(unsupportedMode(mode))
        if (depth != 8 && depth != 16)
            throw ImportException("PSD com $depth bits por canal não é suportado. Converta para 8 ou 16 bits (RGB).")
        if (depth == 16) warnings.add("PSD de 16 bits: cores convertidas para 8 bits por canal.")

        // ---- seções que não usamos ----
        r.skip(r.u32())            // color mode data
        r.skip(r.u32())            // image resources

        // ---- layer and mask information ----
        val lmLen = r.u32()
        if (lmLen == 0L) throw noLayers()
        val lmEnd = r.pos + lmLen
        if (lmEnd > bytes.size) throw truncated()

        val layerInfoLen = r.u32()
        var parsed: ParsedLayers? = null
        if (layerInfoLen > 0) {
            val end = r.pos + layerInfoLen
            if (end > lmEnd) throw truncated()
            parsed = parseLayerInfo(r, end, mode, depth, docW, docH, warnings)
            r.pos = end
        }
        if (parsed == null) {
            // PSD de 16/32 bits guarda as camadas num bloco "Lr16"/"Lr32" na seção global.
            parsed = findAlternateLayerBlock(r, lmEnd, mode, depth, docW, docH, warnings)
        }
        if (parsed == null || parsed.roots.isEmpty()) throw noLayers()
        if (parsed.emptyCount > 0) warnings.add("${parsed.emptyCount} camada(s) sem pixels (vazias/ajuste) foram ignoradas.")
        if (parsed.maskCount > 0) warnings.add("${parsed.maskCount} camada(s) têm máscara; as máscaras foram ignoradas (a imagem é importada sem a máscara).")
        if (parsed.blendCount > 0) warnings.add("${parsed.blendCount} camada(s) usam modos de mesclagem ou recorte não suportados; importadas como normais.")
        if (parsed.imageCount == 0) throw ImportException("O PSD não tem nenhuma camada com pixels.")
        return ImportedDocument(docW.toInt(), docH.toInt(), parsed.roots, warnings.toList())
    }

    private fun noLayers() = ImportException(
        "Este PSD não tem camadas (só a imagem final achatada). Salve o arquivo com as camadas separadas e tente de novo."
    )

    private fun truncated() = ImportException("Arquivo PSD truncado ou corrompido.")

    private fun unsupportedMode(mode: Int): String {
        val n = when (mode) {
            0 -> "Bitmap"; 2 -> "cores indexadas"; 4 -> "CMYK"; 7 -> "Multicanal"; 8 -> "Duotone"; 9 -> "Lab"
            else -> "desconhecido ($mode)"
        }
        return "O PSD está no modo de cor $n, que não é suportado. Converta para RGB (8 bits) e salve de novo."
    }

    private class ParsedLayers(
        val roots: List<ImportedLayer>,
        val imageCount: Int,
        val emptyCount: Int,
        val maskCount: Int,
        val blendCount: Int
    )

    private class Channel(val id: Int, val length: Long)

    private class Record(
        val top: Int, val left: Int, val bottom: Int, val right: Int,
        val channels: List<Channel>,
        val blendKey: String, val opacity: Int, val clipping: Int, val flags: Int,
        var name: String, var sectionType: Int, val hasMask: Boolean
    ) {
        val width: Int get() = right - left
        val height: Int get() = bottom - top
        val visible: Boolean get() = (flags and 2) == 0
    }

    private fun findAlternateLayerBlock(
        r: ByteReader, lmEnd: Long, mode: Int, depth: Int, docW: Long, docH: Long, warnings: Warnings
    ): ParsedLayers? {
        if (r.pos + 4 > lmEnd) return null
        val globalMask = r.u32()
        r.pos = minOf(r.pos + globalMask, lmEnd)
        while (r.pos + 12 <= lmEnd) {
            val sig = r.ascii(4)
            if (sig != "8BIM" && sig != "8B64") break
            val key = r.ascii(4)
            val len = r.u32()
            val start = r.pos
            if (start + len > lmEnd) break
            if (key == "Lr16" || key == "Lr32") {
                val res = parseLayerInfo(r, start + len, mode, depth, docW, docH, warnings)
                r.pos = start + len
                return res
            }
            r.pos = alignToNextBlock(r, start + len, lmEnd)
        }
        return null
    }

    /** Depois de um bloco, o próximo pode vir com preenchimento (par/múltiplo de 4); acha a assinatura certa. */
    private fun alignToNextBlock(r: ByteReader, p: Long, end: Long): Long {
        val candidates = longArrayOf(p, (p + 1) and 1L.inv(), (p + 3) and 3L.inv())
        for (c in candidates) {
            if (c + 12 <= end && r.isBlockSig(c)) return c
        }
        return p
    }

    private fun parseLayerInfo(
        r: ByteReader, end: Long, mode: Int, depth: Int, docW: Long, docH: Long, warnings: Warnings
    ): ParsedLayers? {
        var count = r.i16()
        if (count < 0) count = -count
        if (count == 0) return null
        if (count > ImportLimits.MAX_LAYERS) throw ImportException("Camadas demais no PSD ($count; limite ${ImportLimits.MAX_LAYERS}).")

        val records = ArrayList<Record>(count)
        for (i in 0 until count) records += readRecord(r, end)

        // ---- dados de pixels (na mesma ordem dos registros) ----
        val pngs = arrayOfNulls<ByteArray>(records.size)
        val bps = if (depth == 16) 2 else 1
        var emptyCount = 0
        var maskCount = 0
        var blendCount = 0
        for ((idx, rec) in records.withIndex()) {
            if (rec.hasMask || rec.channels.any { it.id == -2 || it.id == -3 }) maskCount++
            if (rec.sectionType == 0 && (rec.blendKey != "norm" || rec.clipping != 0)) blendCount++
            val isGroupRecord = rec.sectionType in 1..3
            val w = rec.width
            val h = rec.height
            val empty = w <= 0 || h <= 0
            val tooBig = !empty && (w > ImportLimits.MAX_LAYER_SIDE || h > ImportLimits.MAX_LAYER_SIDE ||
                w.toLong() * h > ImportLimits.MAX_LAYER_PIXELS)
            val wanted = !isGroupRecord && !empty && !tooBig
            var planes: HashMap<Int, ByteArray>? = if (wanted) HashMap() else null
            for (ch in rec.channels) {
                val start = r.pos
                val next = start + ch.length
                if (next > r.size) throw truncated()
                if (planes != null && ch.length >= 2 && (ch.id in 0..2 || ch.id == -1)) {
                    val comp = r.u16()
                    val payloadLen = (ch.length - 2).toInt()
                    planes[ch.id] = decodeChannel(r, comp, payloadLen, w, h, bps)
                }
                r.pos = next
            }
            if (!isGroupRecord) {
                if (empty) emptyCount++
                else if (tooBig) warnings.add("Camada \"${rec.name}\" ignorada: grande demais (${w}x$h px).")
            }
            if (planes != null) pngs[idx] = buildPng(rec, planes, mode, w, h)
        }

        // ---- reconstrução da árvore (registros vêm de trás para frente) ----
        val stack = ArrayList<MutableList<ImportedLayer>>()
        var current: MutableList<ImportedLayer> = ArrayList()
        val roots = current
        var imageCount = 0
        for ((idx, rec) in records.withIndex()) {
            when (rec.sectionType) {
                3 -> { // divisor: abre grupo
                    if (stack.size >= ImportLimits.MAX_GROUP_DEPTH) throw ImportException("Grupos aninhados demais (limite ${ImportLimits.MAX_GROUP_DEPTH}).")
                    stack += current
                    current = ArrayList()
                }
                1, 2 -> { // cabeçalho: fecha e nomeia
                    val children = current
                    if (stack.isEmpty()) {
                        warnings.add("Estrutura de grupos inconsistente no PSD; grupo \"${rec.name}\" criado vazio.")
                        current.add(groupOf(rec, emptyList()))
                    } else {
                        current = stack.removeAt(stack.size - 1)
                        current.add(groupOf(rec, children))
                    }
                }
                else -> {
                    val png = pngs[idx] ?: continue
                    imageCount++
                    current.add(
                        ImportedLayer(
                            name = rec.name, visible = rec.visible, opacity = rec.opacity / 255f,
                            left = rec.left, top = rec.top, width = rec.width, height = rec.height, png = png
                        )
                    )
                }
            }
        }
        if (stack.isNotEmpty()) {
            warnings.add("Grupos do PSD sem fechamento; conteúdo mantido na raiz.")
            while (stack.isNotEmpty()) {
                val parent = stack.removeAt(stack.size - 1)
                parent.addAll(current)
                current = parent
            }
        }
        return ParsedLayers(roots, imageCount, emptyCount, maskCount, blendCount)
    }

    private fun groupOf(rec: Record, children: List<ImportedLayer>) = ImportedLayer(
        name = rec.name, visible = rec.visible, opacity = rec.opacity / 255f,
        left = 0, top = 0, width = 0, height = 0, png = null, children = children
    )

    private fun readRecord(r: ByteReader, sectionEnd: Long): Record {
        val top = r.i32(); val left = r.i32(); val bottom = r.i32(); val right = r.i32()
        val nCh = r.u16()
        if (nCh > 56) throw ImportException("PSD corrompido (número de canais inválido: $nCh).")
        val channels = ArrayList<Channel>(nCh)
        for (i in 0 until nCh) channels += Channel(r.i16(), r.u32())
        if (r.ascii(4) != "8BIM") throw ImportException("PSD corrompido (assinatura de camada inválida).")
        val blendKey = r.ascii(4)
        val opacity = r.u8()
        val clipping = r.u8()
        val flags = r.u8()
        r.u8()
        val extraLen = r.u32()
        val extraStart = r.pos
        val extraEnd = extraStart + extraLen
        if (extraEnd > sectionEnd) throw truncated()

        val maskLen = r.u32()
        val hasMask = maskLen > 0
        r.skip(maskLen)
        val rangesLen = r.u32()
        r.skip(rangesLen)

        // nome Pascal, preenchido para múltiplo de 4 (contando o byte de tamanho)
        val nameLen = r.u8()
        val nameBytes = r.bytes(nameLen)
        val pad = (4 - (1 + nameLen) % 4) % 4
        r.skip(pad.toLong())
        var name = String(nameBytes, Charsets.ISO_8859_1)
        var section = 0

        // blocos adicionais
        while (r.pos + 12 <= extraEnd && r.isBlockSig(r.pos)) {
            r.skip(4)
            val key = r.ascii(4)
            val len = r.u32()
            val start = r.pos
            if (start + len > extraEnd) break
            when (key) {
                "luni" -> {
                    val n = r.u32().toInt()
                    if (n >= 0 && 4L + n * 2L <= len) {
                        val s = String(r.bytes(n * 2), Charsets.UTF_16BE).trimEnd('\u0000')
                        if (s.isNotBlank()) name = s
                    }
                }
                "lsct", "lsdk" -> if (len >= 4) section = r.u32().toInt().let { if (it in 0..3) it else 0 }
            }
            r.pos = alignToNextBlock(r, start + len, extraEnd)
        }
        r.pos = extraEnd
        return Record(top, left, bottom, right, channels, blendKey, opacity, clipping, flags, name.ifBlank { "Camada" }, section, hasMask)
    }

    // ---- decodificação de canais ----

    /** Devolve w*h amostras de 8 bits (16 bits viram o byte alto). */
    private fun decodeChannel(r: ByteReader, comp: Int, payloadLen: Int, w: Int, h: Int, bps: Int): ByteArray {
        val rowBytes = w * bps
        val total = rowBytes.toLong() * h
        if (total > Int.MAX_VALUE) throw ImportException("Camada grande demais.")
        val raw: ByteArray = when (comp) {
            0 -> {
                if (payloadLen < total) throw truncated()
                r.bytes(total.toInt())
            }
            1 -> decodeRle(r, payloadLen, w, h, rowBytes)
            2, 3 -> {
                val z = r.bytes(payloadLen)
                val data = inflate(z, total.toInt())
                if (comp == 3) undoPrediction(data, w, h, bps)
                data
            }
            else -> throw ImportException("Compressão de canal PSD desconhecida ($comp).")
        }
        if (bps == 1) return raw
        val out = ByteArray(w * h)
        for (i in out.indices) out[i] = raw[i * 2]
        return out
    }

    private fun decodeRle(r: ByteReader, payloadLen: Int, w: Int, h: Int, rowBytes: Int): ByteArray {
        if (payloadLen < h * 2) throw truncated()
        val counts = IntArray(h) { r.u16() }
        var sum = 0L
        for (c in counts) sum += c
        if (h * 2L + sum > payloadLen) throw truncated()
        val out = ByteArray(rowBytes * h)
        for (y in 0 until h) {
            val rowStart = r.pos
            val rowEnd = rowStart + counts[y]
            var o = y * rowBytes
            val oEnd = o + rowBytes
            while (o < oEnd && r.pos < rowEnd) {
                val n = r.u8().toByte().toInt()
                if (n >= 0) { // copia n+1 bytes
                    val len = n + 1
                    if (r.pos + len > rowEnd || o + len > oEnd) throw ImportException("Dados RLE do PSD corrompidos.")
                    r.copyTo(out, o, len)
                    o += len
                } else if (n != -128) { // repete 1 - n vezes
                    val len = 1 - n
                    if (r.pos + 1 > rowEnd || o + len > oEnd) throw ImportException("Dados RLE do PSD corrompidos.")
                    val v = r.u8().toByte()
                    java.util.Arrays.fill(out, o, o + len, v)
                    o += len
                }
            }
            if (o != oEnd) throw ImportException("Dados RLE do PSD corrompidos (linha incompleta).")
            r.pos = rowEnd
        }
        return out
    }

    private fun inflate(z: ByteArray, expected: Int): ByteArray {
        val inf = Inflater()
        try {
            inf.setInput(z)
            val out = ByteArray(expected)
            var n = 0
            while (n < expected) {
                val k = inf.inflate(out, n, expected - n)
                if (k == 0) {
                    if (inf.finished() || inf.needsInput() || inf.needsDictionary())
                        throw ImportException("Dados ZIP do PSD truncados.")
                }
                n += k
            }
            return out
        } catch (e: DataFormatException) {
            throw ImportException("Dados ZIP do PSD corrompidos.", e)
        } finally {
            inf.end()
        }
    }

    private fun undoPrediction(data: ByteArray, w: Int, h: Int, bps: Int) {
        if (bps == 1) {
            for (y in 0 until h) {
                val base = y * w
                for (x in 1 until w) data[base + x] = (data[base + x] + data[base + x - 1]).toByte()
            }
        } else {
            for (y in 0 until h) {
                val base = y * w * 2
                for (x in 1 until w) {
                    val i = base + x * 2
                    val prev = ((data[i - 2].toInt() and 0xFF) shl 8) or (data[i - 1].toInt() and 0xFF)
                    val cur = ((data[i].toInt() and 0xFF) shl 8) or (data[i + 1].toInt() and 0xFF)
                    val v = (prev + cur) and 0xFFFF
                    data[i] = (v ushr 8).toByte()
                    data[i + 1] = v.toByte()
                }
            }
        }
    }

    private fun buildPng(rec: Record, planes: Map<Int, ByteArray>, mode: Int, w: Int, h: Int): ByteArray {
        val n = w * h
        val rgba = ByteArray(n * 4)
        val alpha = planes[-1]
        if (mode == 1) {
            val g = planes[0] ?: throw ImportException("Camada \"${rec.name}\" sem canal de cinza.")
            for (i in 0 until n) {
                val v = g[i]
                val o = i * 4
                rgba[o] = v; rgba[o + 1] = v; rgba[o + 2] = v
            }
        } else {
            val rp = planes[0]; val gp = planes[1]; val bp = planes[2]
            if (rp == null || gp == null || bp == null) throw ImportException("Camada \"${rec.name}\" sem canais RGB completos.")
            for (i in 0 until n) {
                val o = i * 4
                rgba[o] = rp[i]; rgba[o + 1] = gp[i]; rgba[o + 2] = bp[i]
            }
        }
        if (alpha != null) for (i in 0 until n) rgba[i * 4 + 3] = alpha[i]
        else for (i in 0 until n) rgba[i * 4 + 3] = 0xFF.toByte()
        return PngEncoder.encodeRgba(w, h, rgba)
    }
}

/** Leitor big-endian com verificação de limites (arquivo truncado vira [ImportException]). */
internal class ByteReader(private val data: ByteArray) {
    var pos: Long = 0
    val size: Long get() = data.size.toLong()

    private fun need(n: Long) {
        if (n < 0 || pos + n > data.size) throw ImportException("Arquivo PSD truncado ou corrompido.")
    }

    fun u8(): Int { need(1); return data[(pos++).toInt()].toInt() and 0xFF }
    fun u16(): Int = (u8() shl 8) or u8()
    fun i16(): Int = u16().toShort().toInt()
    fun u32(): Long = (u16().toLong() shl 16) or u16().toLong()
    fun i32(): Int = u32().toInt()
    fun skip(n: Long) { need(n); pos += n }
    fun bytes(n: Int): ByteArray { need(n.toLong()); val o = data.copyOfRange(pos.toInt(), pos.toInt() + n); pos += n; return o }
    fun copyTo(dst: ByteArray, off: Int, n: Int) { need(n.toLong()); System.arraycopy(data, pos.toInt(), dst, off, n); pos += n }
    fun ascii(n: Int): String { need(n.toLong()); val s = String(data, pos.toInt(), n, Charsets.ISO_8859_1); pos += n; return s }
    fun isBlockSig(at: Long): Boolean {
        if (at < 0 || at + 4 > data.size) return false
        val i = at.toInt()
        val b = data
        val is8 = b[i] == '8'.code.toByte()
        return is8 && ((b[i + 1] == 'B'.code.toByte() && b[i + 2] == 'I'.code.toByte() && b[i + 3] == 'M'.code.toByte()) ||
            (b[i + 1] == 'B'.code.toByte() && b[i + 2] == '6'.code.toByte() && b[i + 3] == '4'.code.toByte()))
    }
}
