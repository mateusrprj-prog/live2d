package com.mobile2dstudio.mesh

object MeshGenerator {
    /**
     * Malha em grade retangular com [cols] x [rows] células (2 triângulos cada).
     * (originX, originY) é o canto inferior esquerdo no espaço do canvas (Y para cima).
     * A linha de baixo recebe v=1 e a de cima v=0 (topo da textura).
     */
    fun grid(
        width: Float,
        height: Float,
        cols: Int,
        rows: Int,
        originX: Float,
        originY: Float
    ): ArtMesh {
        require(cols >= 1 && rows >= 1) { "cols e rows devem ser >= 1" }
        require(width > 0f && height > 0f) { "width e height devem ser > 0" }

        val stride = cols + 1
        val vertexCount = stride * (rows + 1)
        val positions = FloatArray(vertexCount * 2)
        val uvs = FloatArray(vertexCount * 2)
        for (j in 0..rows) {
            for (i in 0..cols) {
                val k = (j * stride + i) * 2
                positions[k] = originX + width * i / cols
                positions[k + 1] = originY + height * j / rows
                uvs[k] = i.toFloat() / cols
                uvs[k + 1] = 1f - j.toFloat() / rows
            }
        }
        val indices = IntArray(cols * rows * 6)
        var p = 0
        for (j in 0 until rows) {
            for (i in 0 until cols) {
                val a = j * stride + i
                val b = a + 1
                val c = a + stride
                val d = c + 1
                indices[p++] = a
                indices[p++] = b
                indices[p++] = d
                indices[p++] = a
                indices[p++] = d
                indices[p++] = c
            }
        }
        return ArtMesh(positions, uvs, indices)
    }
}
