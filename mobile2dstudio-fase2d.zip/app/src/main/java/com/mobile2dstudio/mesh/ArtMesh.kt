package com.mobile2dstudio.mesh

import kotlin.math.abs

/**
 * Malha triangular de uma parte do personagem.
 *
 * positions: x,y por vértice (espaço do canvas). uvs: u,v por vértice (v=0 no topo da textura).
 * indices: 3 índices por triângulo.
 *
 * Convenção: uma edição de malha deve produzir uma NOVA instância de [ArtMesh]
 * (o renderer detecta mudança por identidade de instância).
 */
class ArtMesh(
    val positions: FloatArray,
    val uvs: FloatArray,
    val indices: IntArray
) {
    val vertexCount: Int get() = positions.size / 2
    val triangleCount: Int get() = indices.size / 3

    /** Lista de problemas encontrados; vazia significa malha válida. */
    fun validate(): List<String> {
        val problems = ArrayList<String>()
        if (positions.size % 2 != 0) problems += "positions deve ter tamanho par"
        if (uvs.size != positions.size) problems += "uvs deve ter o mesmo tamanho de positions"
        if (indices.size % 3 != 0) problems += "indices deve ser múltiplo de 3"
        if (problems.isNotEmpty()) return problems

        for (v in positions) {
            if (!v.isFinite()) {
                problems += "há coordenada não finita em positions"
                break
            }
        }
        val n = vertexCount
        var outOfRange = 0
        var degenerate = 0
        for (t in 0 until triangleCount) {
            val a = indices[t * 3]
            val b = indices[t * 3 + 1]
            val c = indices[t * 3 + 2]
            if (a < 0 || a >= n || b < 0 || b >= n || c < 0 || c >= n) {
                outOfRange++
                continue
            }
            val area2 = (positions[b * 2] - positions[a * 2]) * (positions[c * 2 + 1] - positions[a * 2 + 1]) -
                (positions[c * 2] - positions[a * 2]) * (positions[b * 2 + 1] - positions[a * 2 + 1])
            if (abs(area2) < 1e-9f) degenerate++
        }
        if (outOfRange > 0) problems += "$outOfRange triângulo(s) com índice fora do intervalo"
        if (degenerate > 0) problems += "$degenerate triângulo(s) degenerado(s)"
        return problems
    }

    /** Arestas únicas (pares de índices) para visualizar a topologia. */
    fun edgeIndices(): IntArray {
        val seen = LinkedHashSet<Long>()
        fun add(i: Int, j: Int) {
            val lo = if (i < j) i else j
            val hi = if (i < j) j else i
            seen.add((lo.toLong() shl 32) or hi.toLong())
        }
        for (t in 0 until triangleCount) {
            val a = indices[t * 3]
            val b = indices[t * 3 + 1]
            val c = indices[t * 3 + 2]
            add(a, b)
            add(b, c)
            add(c, a)
        }
        val out = IntArray(seen.size * 2)
        var p = 0
        for (key in seen) {
            out[p++] = (key shr 32).toInt()
            out[p++] = (key and 0xFFFFFFFFL).toInt()
        }
        return out
    }
}
