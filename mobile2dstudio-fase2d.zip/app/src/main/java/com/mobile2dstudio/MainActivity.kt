package com.mobile2dstudio

import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.mobile2dstudio.project.ProjectRepository
import com.mobile2dstudio.ui.AppRoot
import com.mobile2dstudio.ui.Mobile2DTheme
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val repository = ProjectRepository(
            dir = File(filesDir, "projects"),
            logger = { Log.w("Mobile2DStudio", it) }
        )
        setContent {
            Mobile2DTheme {
                Surface(Modifier.fillMaxSize()) {
                    AppRoot(repository)
                }
            }
        }
    }
}
