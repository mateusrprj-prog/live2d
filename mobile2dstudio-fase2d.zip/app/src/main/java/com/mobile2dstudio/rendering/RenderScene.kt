package com.mobile2dstudio.rendering

import com.mobile2dstudio.geometry.Affine
import com.mobile2dstudio.mesh.ArtMesh

/** Parte preparada para renderização. A ordem da lista é a ordem de desenho (primeiro = fundo). */
class RenderPart(
    val id: String,
    val mesh: ArtMesh,
    val world: Affine = Affine.IDENTITY,
    val visible: Boolean = true,
    val opacity: Float = 1f,
    val textureId: String? = null,
    /** Bytes PNG/JPEG originais; null/vazio faz o renderer exibir o marcador de recurso ausente. */
    val textureBytes: ByteArray? = null,
    val selected: Boolean = false
)

class RenderScene(
    val parts: List<RenderPart>,
    val canvasWidth: Float,
    val canvasHeight: Float,
    val showWireframe: Boolean
)
