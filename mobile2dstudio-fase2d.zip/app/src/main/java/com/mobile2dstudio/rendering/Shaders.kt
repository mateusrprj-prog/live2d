package com.mobile2dstudio.rendering

import android.opengl.GLES20

internal object Shaders {
    const val TEXTURED_VERTEX = """#version 300 es
uniform mat4 uMvp;
layout(location = 0) in vec2 aPos;
layout(location = 1) in vec2 aUv;
out vec2 vUv;
void main() {
    vUv = aUv;
    gl_Position = uMvp * vec4(aPos, 0.0, 1.0);
}
"""

    // Textura em alfa pré-multiplicado (GLUtils.texImage2D entrega assim).
    const val TEXTURED_FRAGMENT = """#version 300 es
precision mediump float;
uniform sampler2D uTex;
uniform float uAlpha;
in vec2 vUv;
out vec4 oColor;
void main() {
    oColor = texture(uTex, vUv) * uAlpha;
}
"""

    const val SOLID_VERTEX = """#version 300 es
uniform mat4 uMvp;
layout(location = 0) in vec2 aPos;
void main() {
    gl_Position = uMvp * vec4(aPos, 0.0, 1.0);
}
"""

    const val SOLID_FRAGMENT = """#version 300 es
precision mediump float;
uniform vec4 uColor;
out vec4 oColor;
void main() {
    oColor = vec4(uColor.rgb * uColor.a, uColor.a);
}
"""
}

internal class ShaderProgram(vertexSource: String, fragmentSource: String) {
    val id: Int

    init {
        val vs = compile(GLES20.GL_VERTEX_SHADER, vertexSource)
        val fs = compile(GLES20.GL_FRAGMENT_SHADER, fragmentSource)
        val program = GLES20.glCreateProgram()
        GLES20.glAttachShader(program, vs)
        GLES20.glAttachShader(program, fs)
        GLES20.glLinkProgram(program)
        val status = IntArray(1)
        GLES20.glGetProgramiv(program, GLES20.GL_LINK_STATUS, status, 0)
        if (status[0] == 0) {
            val log = GLES20.glGetProgramInfoLog(program)
            GLES20.glDeleteProgram(program)
            throw IllegalStateException("Falha ao ligar o shader program: $log")
        }
        GLES20.glDeleteShader(vs)
        GLES20.glDeleteShader(fs)
        id = program
    }

    fun use() = GLES20.glUseProgram(id)

    fun uniform(name: String): Int = GLES20.glGetUniformLocation(id, name)

    private fun compile(type: Int, source: String): Int {
        val shader = GLES20.glCreateShader(type)
        GLES20.glShaderSource(shader, source)
        GLES20.glCompileShader(shader)
        val status = IntArray(1)
        GLES20.glGetShaderiv(shader, GLES20.GL_COMPILE_STATUS, status, 0)
        if (status[0] == 0) {
            val log = GLES20.glGetShaderInfoLog(shader)
            GLES20.glDeleteShader(shader)
            throw IllegalStateException("Falha ao compilar shader: $log")
        }
        return shader
    }
}
