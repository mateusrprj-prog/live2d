package com.mobile2dstudio.rendering

import android.content.Context
import android.opengl.GLSurfaceView
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import com.mobile2dstudio.geometry.Vec2

/** Canvas GPU. Pinça sempre faz pan/zoom; um dedo seleciona/arrasta ou move a câmera. */
class GLCanvasView(context: Context) : GLSurfaceView(context) {
    private val meshRenderer = MeshRenderer()
    private var lastX = 0f
    private var lastY = 0f
    private var lastFocusX = 0f
    private var lastFocusY = 0f

    @Volatile var oneFingerPan: Boolean = false
    @Volatile var rectangleSelectionEnabled: Boolean = false
    @Volatile var onWorldDown: ((Float, Float) -> Unit)? = null
    @Volatile var onWorldDrag: ((Float, Float) -> Unit)? = null
    @Volatile var onWorldUp: (() -> Unit)? = null
    @Volatile var onWorldRectangle: ((Float, Float, Float, Float) -> Unit)? = null

    // Usados exclusivamente na thread OpenGL.
    private var lastWorld: Vec2? = null
    private var rectangleStart: Vec2? = null

    private val scaleDetector = ScaleGestureDetector(
        context,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScaleBegin(detector: ScaleGestureDetector): Boolean {
                lastFocusX = detector.focusX
                lastFocusY = detector.focusY
                return true
            }

            override fun onScale(detector: ScaleGestureDetector): Boolean {
                val fx = detector.focusX
                val fy = detector.focusY
                val dx = fx - lastFocusX
                val dy = fy - lastFocusY
                lastFocusX = fx
                lastFocusY = fy
                val factor = detector.scaleFactor
                update {
                    camera.panByScreen(dx, dy)
                    camera.zoomAt(factor, fx, fy)
                }
                return true
            }
        }
    )

    init {
        setEGLContextClientVersion(3)
        preserveEGLContextOnPause = true
        setRenderer(meshRenderer)
        renderMode = RENDERMODE_WHEN_DIRTY
    }

    /** Executa [block] na thread do GL e redesenha. */
    fun update(block: MeshRenderer.() -> Unit) {
        queueEvent {
            meshRenderer.block()
            requestRender()
        }
    }

    fun fitToCanvas() { update { requestFit() } }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(event)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = event.x
                lastY = event.y
                val x = event.x
                val y = event.y
                queueEvent {
                    val world = meshRenderer.camera.screenToWorld(x, y)
                    lastWorld = world
                    rectangleStart = world
                    if (!rectangleSelectionEnabled && !oneFingerPan) post { onWorldDown?.invoke(world.x, world.y) }
                }
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                // Ao começar o gesto de pinça, não deixar o próximo movimento parecer arrasto de peça.
                queueEvent { lastWorld = null }
            }
            MotionEvent.ACTION_POINTER_UP -> {
                val remaining = if (event.actionIndex == 0) 1 else 0
                lastX = event.getX(remaining)
                lastY = event.getY(remaining)
                val x = lastX
                val y = lastY
                queueEvent { lastWorld = meshRenderer.camera.screenToWorld(x, y) }
            }
            MotionEvent.ACTION_MOVE -> {
                if (event.pointerCount == 1 && !scaleDetector.isInProgress) {
                    val x = event.x
                    val y = event.y
                    val dxScreen = x - lastX
                    val dyScreen = y - lastY
                    lastX = x
                    lastY = y
                    if (dxScreen != 0f || dyScreen != 0f) {
                        queueEvent {
                            if (oneFingerPan) {
                                meshRenderer.camera.panByScreen(dxScreen, dyScreen)
                                requestRender()
                            } else if (!rectangleSelectionEnabled) {
                                val now = meshRenderer.camera.screenToWorld(x, y)
                                val previous = lastWorld
                                lastWorld = now
                                if (previous != null) {
                                    val dx = now.x - previous.x
                                    val dy = now.y - previous.y
                                    if (dx != 0f || dy != 0f) post { onWorldDrag?.invoke(dx, dy) }
                                }
                            }
                        }
                    }
                }
            }
            MotionEvent.ACTION_UP -> {
                val x = event.x
                val y = event.y
                queueEvent {
                    val end = meshRenderer.camera.screenToWorld(x, y)
                    if (rectangleSelectionEnabled) {
                        val start = rectangleStart
                        if (start != null) {
                            post { onWorldRectangle?.invoke(start.x, start.y, end.x, end.y) }
                        }
                    }
                    lastWorld = null
                    rectangleStart = null
                    post { onWorldUp?.invoke() }
                }
            }
            MotionEvent.ACTION_CANCEL -> {
                queueEvent {
                    lastWorld = null
                    rectangleStart = null
                    post { onWorldUp?.invoke() }
                }
            }
        }
        return true
    }
}
