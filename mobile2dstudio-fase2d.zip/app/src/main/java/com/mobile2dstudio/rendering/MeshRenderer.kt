package com.mobile2dstudio.rendering

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.opengl.GLES20
import android.opengl.GLES30
import android.opengl.GLSurfaceView
import android.opengl.GLUtils
import com.mobile2dstudio.geometry.Affine
import com.mobile2dstudio.geometry.CanvasCamera
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

/** Renderer OpenGL ES 3.0. Todos os métodos de cena são chamados pela thread GL. */
class MeshRenderer : GLSurfaceView.Renderer {
    val camera = CanvasCamera()

    private var scene = RenderScene(emptyList(), 1080f, 1920f, false)
    private var fitPending = true
    private var surfaceReady = false

    private var textured: ShaderProgram? = null
    private var solid: ShaderProgram? = null
    private var texMvp = 0
    private var texSampler = 0
    private var texAlpha = 0
    private var solidMvp = 0
    private var solidColor = 0

    private val meshes = HashMap<String, GpuMesh>()
    private val textures = HashMap<String, TextureEntry>()
    private var missingTexture = 0
    private var checkerTexture = 0
    private var maxTextureSize = 4096

    private var frameVao = 0
    private var framePositionVbo = 0
    private var frameUvVbo = 0
    private var frameW = 0f
    private var frameH = 0f

    private val projection = FloatArray(16)
    private val worldMatrix = FloatArray(16)
    private val combined = FloatArray(16)

    private data class TextureEntry(val name: Int, val source: ByteArray?, val fallback: Boolean)

    fun setScene(newScene: RenderScene) {
        if (newScene.canvasWidth != scene.canvasWidth || newScene.canvasHeight != scene.canvasHeight) {
            fitPending = true
        }
        scene = newScene
    }

    fun requestFit() { fitPending = true }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        // Nomes GL pertencem ao contexto anterior e não podem ser reutilizados.
        meshes.clear()
        textures.clear()
        missingTexture = 0
        checkerTexture = 0
        frameVao = 0
        framePositionVbo = 0
        frameUvVbo = 0
        frameW = 0f
        frameH = 0f

        val t = ShaderProgram(Shaders.TEXTURED_VERTEX, Shaders.TEXTURED_FRAGMENT)
        texMvp = t.uniform("uMvp")
        texSampler = t.uniform("uTex")
        texAlpha = t.uniform("uAlpha")
        textured = t

        val s = ShaderProgram(Shaders.SOLID_VERTEX, Shaders.SOLID_FRAGMENT)
        solidMvp = s.uniform("uMvp")
        solidColor = s.uniform("uColor")
        solid = s

        val max = IntArray(1)
        GLES20.glGetIntegerv(GLES20.GL_MAX_TEXTURE_SIZE, max, 0)
        if (max[0] > 0) maxTextureSize = max[0]

        val missingBitmap = createMissingBitmap()
        missingTexture = uploadBitmap(missingBitmap)
        missingBitmap.recycle()
        val checkerBitmap = createCanvasCheckerBitmap()
        checkerTexture = uploadBitmap(checkerBitmap)
        checkerBitmap.recycle()

        GLES20.glClearColor(0.12f, 0.12f, 0.14f, 1f)
        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_ONE, GLES20.GL_ONE_MINUS_SRC_ALPHA)
        GLES20.glDisable(GLES20.GL_DEPTH_TEST)
        GLES20.glDisable(GLES20.GL_CULL_FACE)
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        GLES20.glViewport(0, 0, width, height)
        camera.setViewport(width, height)
        surfaceReady = width > 0 && height > 0
        fitPending = true
    }

    override fun onDrawFrame(gl: GL10?) {
        val texProgram = textured ?: return
        val solidProgram = solid ?: return

        if (fitPending && surfaceReady) {
            camera.fit(scene.canvasWidth, scene.canvasHeight, 0.9f)
            fitPending = false
        }

        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        camera.projectionMatrix(projection)
        syncResources()
        ensureFrame()

        // Fundo xadrez de transparência, limitado ao retângulo do documento.
        texProgram.use()
        GLES20.glUniformMatrix4fv(texMvp, 1, false, projection, 0)
        GLES20.glUniform1i(texSampler, 0)
        GLES20.glUniform1f(texAlpha, 1f)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, checkerTexture)
        GLES30.glBindVertexArray(frameVao)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_FAN, 0, 4)

        // Partes com textura, transformação hierárquica e opacidade herdada.
        for (part in scene.parts) {
            if (!part.visible || part.opacity <= 0f) continue
            val gpu = meshes[part.id] ?: continue
            part.world.toMatrix4(worldMatrix)
            multiply4(projection, worldMatrix, combined)
            texProgram.use()
            GLES20.glUniformMatrix4fv(texMvp, 1, false, combined, 0)
            GLES20.glUniform1i(texSampler, 0)
            GLES20.glUniform1f(texAlpha, part.opacity.coerceIn(0f, 1f))
            GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, textureFor(part))
            GLES30.glBindVertexArray(gpu.vaoTriangles)
            GLES20.glDrawElements(GLES20.GL_TRIANGLES, gpu.triangleIndexCount, GLES20.GL_UNSIGNED_INT, 0)
        }

        // Wireframe segue a mesma transformação de cada parte.
        if (scene.showWireframe) {
            solidProgram.use()
            for (part in scene.parts) {
                if (!part.visible || part.opacity <= 0f) continue
                val gpu = meshes[part.id] ?: continue
                part.world.toMatrix4(worldMatrix)
                multiply4(projection, worldMatrix, combined)
                GLES20.glUniformMatrix4fv(solidMvp, 1, false, combined, 0)
                GLES20.glUniform4f(solidColor, 1f, 1f, 1f, 0.55f * part.opacity.coerceIn(0f, 1f))
                GLES30.glBindVertexArray(gpu.vaoEdges)
                GLES20.glDrawElements(GLES20.GL_LINES, gpu.edgeIndexCount, GLES20.GL_UNSIGNED_INT, 0)
            }
        }

        // Contorno laranja da peça selecionada, mesmo quando a topologia geral está oculta.
        solidProgram.use()
        for (part in scene.parts) {
            if (!part.selected || !part.visible) continue
            val gpu = meshes[part.id] ?: continue
            part.world.toMatrix4(worldMatrix)
            multiply4(projection, worldMatrix, combined)
            GLES20.glUniformMatrix4fv(solidMvp, 1, false, combined, 0)
            GLES20.glUniform4f(solidColor, 0.91f, 0.55f, 0.16f, 1f)
            GLES30.glBindVertexArray(gpu.vaoEdges)
            GLES20.glDrawElements(GLES20.GL_LINES, gpu.edgeIndexCount, GLES20.GL_UNSIGNED_INT, 0)
        }

        // Contorno do documento.
        solidProgram.use()
        GLES20.glUniformMatrix4fv(solidMvp, 1, false, projection, 0)
        GLES20.glUniform4f(solidColor, 0.91f, 0.61f, 0.22f, 1f)
        GLES30.glBindVertexArray(frameVao)
        GLES20.glDrawArrays(GLES20.GL_LINE_LOOP, 0, 4)
        GLES30.glBindVertexArray(0)
    }

    private fun syncResources() {
        val keepParts = HashSet<String>()
        val keepAssets = HashSet<String>()
        for (part in scene.parts) {
            keepParts += part.id
            keepAssets += (part.textureId ?: "__missing_${part.id}")
            val existing = meshes[part.id]
            if (existing == null) {
                meshes[part.id] = GpuMesh.create(part.mesh)
            } else if (existing.source !== part.mesh) {
                if (existing.canUpdateFrom(part.mesh)) {
                    existing.updatePositions(part.mesh)
                } else {
                    existing.release()
                    meshes[part.id] = GpuMesh.create(part.mesh)
                }
            }
        }
        val meshIterator = meshes.entries.iterator()
        while (meshIterator.hasNext()) {
            val entry = meshIterator.next()
            if (entry.key !in keepParts) {
                entry.value.release()
                meshIterator.remove()
            }
        }
        val textureIterator = textures.entries.iterator()
        while (textureIterator.hasNext()) {
            val entry = textureIterator.next()
            if (entry.key !in keepAssets) {
                if (!entry.value.fallback) GLES20.glDeleteTextures(1, intArrayOf(entry.value.name), 0)
                textureIterator.remove()
            }
        }
    }

    private fun textureFor(part: RenderPart): Int {
        val key = part.textureId ?: "__missing_${part.id}"
        val bytes = part.textureBytes
        val old = textures[key]
        if (old != null && old.source === bytes) return old.name
        if (old != null && !old.fallback) GLES20.glDeleteTextures(1, intArrayOf(old.name), 0)

        if (part.textureId == null || bytes == null || bytes.isEmpty()) {
            textures[key] = TextureEntry(missingTexture, bytes, true)
            return missingTexture
        }

        val options = BitmapFactory.Options().apply {
            inPreferredConfig = Bitmap.Config.ARGB_8888
            inPremultiplied = true
            inScaled = false
        }
        val bitmap = try {
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options)
        } catch (_: Exception) {
            null
        }
        if (bitmap == null || bitmap.width > maxTextureSize || bitmap.height > maxTextureSize) {
            bitmap?.recycle()
            textures[key] = TextureEntry(missingTexture, bytes, true)
            return missingTexture
        }
        val id = try {
            uploadBitmap(bitmap)
        } catch (_: Exception) {
            0
        } finally {
            if (!bitmap.isRecycled) bitmap.recycle()
        }
        if (id == 0) {
            textures[key] = TextureEntry(missingTexture, bytes, true)
            return missingTexture
        }
        textures[key] = TextureEntry(id, bytes, false)
        return id
    }

    private fun uploadBitmap(bitmap: Bitmap): Int {
        val ids = IntArray(1)
        GLES20.glGenTextures(1, ids, 0)
        if (ids[0] == 0) return 0
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, ids[0])
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bitmap, 0)
        val error = GLES20.glGetError()
        if (error != GLES20.GL_NO_ERROR) {
            GLES20.glDeleteTextures(1, ids, 0)
            return 0
        }
        return ids[0]
    }

    private fun ensureFrame() {
        if (frameVao != 0 && frameW == scene.canvasWidth && frameH == scene.canvasHeight) return
        if (frameVao != 0) {
            GLES30.glDeleteVertexArrays(1, intArrayOf(frameVao), 0)
            GLES20.glDeleteBuffers(2, intArrayOf(framePositionVbo, frameUvVbo), 0)
        }
        val vaos = IntArray(1)
        val buffers = IntArray(2)
        GLES30.glGenVertexArrays(1, vaos, 0)
        GLES20.glGenBuffers(2, buffers, 0)
        val hw = scene.canvasWidth / 2f
        val hh = scene.canvasHeight / 2f
        val positions = directFloatBuffer(8).apply {
            put(floatArrayOf(-hw, -hh, hw, -hh, hw, hh, -hw, hh))
            position(0)
        }
        // v=1 no bordo inferior e v=0 no superior, consistente com a importação.
        val uvs = directFloatBuffer(8).apply {
            put(floatArrayOf(0f, 1f, 1f, 1f, 1f, 0f, 0f, 0f))
            position(0)
        }
        GLES30.glBindVertexArray(vaos[0])
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, buffers[0])
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, 8 * 4, positions, GLES20.GL_STATIC_DRAW)
        GLES20.glEnableVertexAttribArray(0)
        GLES20.glVertexAttribPointer(0, 2, GLES20.GL_FLOAT, false, 0, 0)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, buffers[1])
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, 8 * 4, uvs, GLES20.GL_STATIC_DRAW)
        GLES20.glEnableVertexAttribArray(1)
        GLES20.glVertexAttribPointer(1, 2, GLES20.GL_FLOAT, false, 0, 0)
        GLES30.glBindVertexArray(0)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
        frameVao = vaos[0]
        framePositionVbo = buffers[0]
        frameUvVbo = buffers[1]
        frameW = scene.canvasWidth
        frameH = scene.canvasHeight
    }

    private fun createCanvasCheckerBitmap(): Bitmap = createCheckerBitmap(
        light = android.graphics.Color.rgb(112, 112, 116),
        dark = android.graphics.Color.rgb(82, 82, 86),
        size = 256,
        cells = 8
    )

    private fun createMissingBitmap(): Bitmap = createCheckerBitmap(
        light = android.graphics.Color.rgb(225, 62, 112),
        dark = android.graphics.Color.rgb(78, 35, 53),
        size = 128,
        cells = 8
    )

    private fun createCheckerBitmap(light: Int, dark: Int, size: Int, cells: Int): Bitmap {
        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val cell = size / cells
        for (y in 0 until cells) for (x in 0 until cells) {
            paint.color = if ((x + y) % 2 == 0) light else dark
            canvas.drawRect(
                (x * cell).toFloat(), (y * cell).toFloat(),
                ((x + 1) * cell).toFloat(), ((y + 1) * cell).toFloat(), paint
            )
        }
        return bitmap
    }

    private fun multiply4(a: FloatArray, b: FloatArray, out: FloatArray) {
        // Matrizes column-major: out = a * b.
        for (col in 0..3) {
            for (row in 0..3) {
                out[col * 4 + row] =
                    a[row] * b[col * 4] +
                    a[4 + row] * b[col * 4 + 1] +
                    a[8 + row] * b[col * 4 + 2] +
                    a[12 + row] * b[col * 4 + 3]
            }
        }
    }
}
