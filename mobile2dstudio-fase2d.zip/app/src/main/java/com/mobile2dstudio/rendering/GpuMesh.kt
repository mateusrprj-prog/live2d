package com.mobile2dstudio.rendering

import android.opengl.GLES20
import android.opengl.GLES30
import com.mobile2dstudio.mesh.ArtMesh
import java.nio.FloatBuffer

/**
 * Recursos de GPU de uma malha: um VAO para triângulos e outro para arestas (wireframe).
 * Só pode ser criado/usado/liberado na thread do GL.
 */
internal class GpuMesh private constructor(
    val vaoTriangles: Int,
    val vaoEdges: Int,
    private val buffers: IntArray, // 0 = posições, 1 = uvs, 2 = índices de triângulos, 3 = índices de arestas
    val triangleIndexCount: Int,
    val edgeIndexCount: Int,
    var source: ArtMesh,
    private val positionStaging: FloatBuffer
) {
    /** Se só as posições mudaram, dá para atualizar sem recriar os buffers. */
    fun canUpdateFrom(mesh: ArtMesh): Boolean =
        mesh.uvs === source.uvs &&
            mesh.indices === source.indices &&
            mesh.positions.size == source.positions.size

    fun updatePositions(mesh: ArtMesh) {
        positionStaging.clear()
        positionStaging.put(mesh.positions)
        positionStaging.flip()
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, buffers[0])
        GLES20.glBufferSubData(GLES20.GL_ARRAY_BUFFER, 0, mesh.positions.size * 4, positionStaging)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
        source = mesh
    }

    fun release() {
        GLES30.glDeleteVertexArrays(2, intArrayOf(vaoTriangles, vaoEdges), 0)
        GLES20.glDeleteBuffers(buffers.size, buffers, 0)
    }

    companion object {
        fun create(mesh: ArtMesh): GpuMesh {
            val bufs = IntArray(4)
            GLES20.glGenBuffers(4, bufs, 0)
            val vaos = IntArray(2)
            GLES30.glGenVertexArrays(2, vaos, 0)

            val staging = directFloatBuffer(mesh.positions.size)
            staging.put(mesh.positions)
            staging.position(0)

            val uvBuf = directFloatBuffer(mesh.uvs.size)
            uvBuf.put(mesh.uvs)
            uvBuf.position(0)

            val triBuf = directIntBuffer(mesh.indices.size)
            triBuf.put(mesh.indices)
            triBuf.position(0)

            val edges = mesh.edgeIndices()
            val edgeBuf = directIntBuffer(edges.size)
            edgeBuf.put(edges)
            edgeBuf.position(0)

            // VAO de triângulos: posição (loc 0), uv (loc 1), índices.
            GLES30.glBindVertexArray(vaos[0])
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, bufs[0])
            GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, mesh.positions.size * 4, staging, GLES20.GL_DYNAMIC_DRAW)
            GLES20.glEnableVertexAttribArray(0)
            GLES20.glVertexAttribPointer(0, 2, GLES20.GL_FLOAT, false, 0, 0)
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, bufs[1])
            GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, mesh.uvs.size * 4, uvBuf, GLES20.GL_STATIC_DRAW)
            GLES20.glEnableVertexAttribArray(1)
            GLES20.glVertexAttribPointer(1, 2, GLES20.GL_FLOAT, false, 0, 0)
            GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, bufs[2])
            GLES20.glBufferData(GLES20.GL_ELEMENT_ARRAY_BUFFER, mesh.indices.size * 4, triBuf, GLES20.GL_STATIC_DRAW)

            // VAO de arestas: mesmo buffer de posições, índices de arestas.
            GLES30.glBindVertexArray(vaos[1])
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, bufs[0])
            GLES20.glEnableVertexAttribArray(0)
            GLES20.glVertexAttribPointer(0, 2, GLES20.GL_FLOAT, false, 0, 0)
            GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, bufs[3])
            GLES20.glBufferData(GLES20.GL_ELEMENT_ARRAY_BUFFER, edges.size * 4, edgeBuf, GLES20.GL_STATIC_DRAW)

            GLES30.glBindVertexArray(0)
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)

            return GpuMesh(vaos[0], vaos[1], bufs, mesh.indices.size, edges.size, mesh, staging)
        }
    }
}
