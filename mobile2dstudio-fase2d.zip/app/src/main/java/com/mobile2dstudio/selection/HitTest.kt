package com.mobile2dstudio.selection

import com.mobile2dstudio.project.PartTree
import com.mobile2dstudio.project.Part
import kotlin.math.max
import kotlin.math.min

/** Seleção geométrica em coordenadas de mundo. Não depende de Android/OpenGL. */
object HitTest {
    /** Retorna a parte visível e desbloqueada mais à frente que contém o ponto. */
    fun point(parts: List<Part>, worldX: Float, worldY: Float): String? {
        if (!worldX.isFinite() || !worldY.isFinite()) return null
        val resolved = PartTree.renderList(parts)
        for (entry in resolved.asReversed()) {
            if (!entry.visible || entry.locked || entry.opacity <= 0f) continue
            val mesh = entry.part.mesh ?: continue
            val inverse = entry.world.inverse() ?: continue
            val local = inverse.apply(worldX, worldY)
            if (contains(mesh.positions, mesh.indices, local.x, local.y)) return entry.part.id
        }
        return null
    }

    /** Seleciona partes cujo limite transformado cruza o retângulo de seleção. */
    fun rectangle(
        parts: List<Part>,
        x1: Float,
        y1: Float,
        x2: Float,
        y2: Float
    ): List<String> {
        if (!x1.isFinite() || !y1.isFinite() || !x2.isFinite() || !y2.isFinite()) return emptyList()
        val left = min(x1, x2)
        val right = max(x1, x2)
        val bottom = min(y1, y2)
        val top = max(y1, y2)
        val selected = ArrayList<String>()
        for (entry in PartTree.renderList(parts)) {
            if (!entry.visible || entry.locked || entry.opacity <= 0f) continue
            val positions = entry.part.mesh?.positions ?: continue
            if (positions.isEmpty()) continue
            var minX = Float.POSITIVE_INFINITY
            var minY = Float.POSITIVE_INFINITY
            var maxX = Float.NEGATIVE_INFINITY
            var maxY = Float.NEGATIVE_INFINITY
            var i = 0
            while (i + 1 < positions.size) {
                val p = entry.world.apply(positions[i], positions[i + 1])
                minX = min(minX, p.x)
                minY = min(minY, p.y)
                maxX = max(maxX, p.x)
                maxY = max(maxY, p.y)
                i += 2
            }
            if (maxX >= left && minX <= right && maxY >= bottom && minY <= top) {
                selected += entry.part.id
            }
        }
        return selected
    }

    private fun contains(positions: FloatArray, indices: IntArray, x: Float, y: Float): Boolean {
        if (positions.size < 6 || indices.size < 3) return false
        var i = 0
        while (i + 2 < indices.size) {
            val ia = indices[i] * 2
            val ib = indices[i + 1] * 2
            val ic = indices[i + 2] * 2
            if (ia >= 0 && ib >= 0 && ic >= 0 &&
                ia + 1 < positions.size && ib + 1 < positions.size && ic + 1 < positions.size &&
                inTriangle(
                    x, y,
                    positions[ia], positions[ia + 1],
                    positions[ib], positions[ib + 1],
                    positions[ic], positions[ic + 1]
                )
            ) return true
            i += 3
        }
        return false
    }

    private fun inTriangle(
        px: Float, py: Float,
        ax: Float, ay: Float,
        bx: Float, by: Float,
        cx: Float, cy: Float
    ): Boolean {
        val d1 = cross(px - bx, py - by, ax - bx, ay - by)
        val d2 = cross(px - cx, py - cy, bx - cx, by - cy)
        val d3 = cross(px - ax, py - ay, cx - ax, cy - ay)
        val hasNegative = d1 < -1e-5f || d2 < -1e-5f || d3 < -1e-5f
        val hasPositive = d1 > 1e-5f || d2 > 1e-5f || d3 > 1e-5f
        return !(hasNegative && hasPositive)
    }

    private fun cross(ax: Float, ay: Float, bx: Float, by: Float): Float = ax * by - ay * bx
}
