package com.mobile2dstudio.imports

import java.io.ByteArrayOutputStream
import java.util.zip.Deflater

/** Gerador de PSD sintético para testes (8 bits RGB). */
class PsdBuilder(private val width: Int, private val height: Int, private val depth: Int = 8, private val mode: Int = 3) {

    enum class Comp { RAW, RLE, ZIP, ZIP_PRED }

    class L(
        val name: String,
        val left: Int = 0, val top: Int = 0, val w: Int = 0, val h: Int = 0,
        /** pixels RGBA 8 bits (w*h*4) */
        val rgba: ByteArray? = null,
        val opacity: Int = 255,
        val hidden: Boolean = false,
        val section: Int = 0,
        val comp: Comp = Comp.RAW,
        val withMaskChannel: Boolean = false,
        val unicodeName: String? = null,
        val blendKey: String = "norm"
    )

    private val layers = ArrayList<L>()
    fun add(l: L) = apply { layers += l }

    private fun ByteArrayOutputStream.u8(v: Int) = write(v and 0xFF)
    private fun ByteArrayOutputStream.u16(v: Int) { u8(v ushr 8); u8(v) }
    private fun ByteArrayOutputStream.u32(v: Long) { u16((v ushr 16).toInt()); u16(v.toInt()) }
    private fun ByteArrayOutputStream.i32(v: Int) = u32(v.toLong() and 0xFFFFFFFFL)
    private fun ByteArrayOutputStream.ascii(s: String) = write(s.toByteArray(Charsets.ISO_8859_1))

    fun build(): ByteArray {
        val out = ByteArrayOutputStream()
        out.ascii("8BPS"); out.u16(1); out.write(ByteArray(6)); out.u16(3)
        out.u32(height.toLong()); out.u32(width.toLong()); out.u16(depth); out.u16(mode)
        out.u32(0) // color mode data
        out.u32(0) // image resources

        val info = ByteArrayOutputStream()
        info.u16(layers.size)
        val chanData = ArrayList<List<ByteArray>>()
        for (l in layers) {
            val chans = channelsOf(l)
            chanData += chans.map { it.second }
            info.i32(l.top); info.i32(l.left); info.i32(l.top + l.h); info.i32(l.left + l.w)
            info.u16(chans.size)
            for ((id, data) in chans) { info.u16(id); info.u32(data.size.toLong()) }
            info.ascii("8BIM"); info.ascii(l.blendKey); info.u8(l.opacity); info.u8(0)
            info.u8(if (l.hidden) 2 else 0); info.u8(0)
            val extra = ByteArrayOutputStream()
            extra.u32(0) // mask
            extra.u32(0) // blending ranges
            val nb = l.name.toByteArray(Charsets.ISO_8859_1)
            extra.u8(nb.size); extra.write(nb)
            val padNeeded = (4 - (1 + nb.size) % 4) % 4
            extra.write(ByteArray(padNeeded))
            if (l.unicodeName != null) {
                val u = l.unicodeName.toByteArray(Charsets.UTF_16BE)
                extra.ascii("8BIM"); extra.ascii("luni"); extra.u32(4L + u.size)
                extra.u32((u.size / 2).toLong()); extra.write(u)
                if ((4 + u.size) % 2 != 0) extra.u8(0)
            }
            if (l.section != 0) {
                extra.ascii("8BIM"); extra.ascii("lsct"); extra.u32(4); extra.u32(l.section.toLong())
            }
            val eb = extra.toByteArray()
            info.u32(eb.size.toLong()); info.write(eb)
        }
        for (list in chanData) for (d in list) info.write(d)
        // (os dados de canal já incluem a palavra de compressão; o tamanho no registro também)
        var bytes = info.toByteArray()
        if (bytes.size % 2 != 0) bytes += 0

        val lm = ByteArrayOutputStream()
        lm.u32(bytes.size.toLong()); lm.write(bytes)
        lm.u32(0) // global layer mask info
        val lmBytes = lm.toByteArray()
        out.u32(lmBytes.size.toLong()); out.write(lmBytes)
        out.u16(0); out.write(ByteArray(width * height * 3)) // imagem achatada (não usada)
        return out.toByteArray()
    }

    /** Lista (id do canal, bytes incluindo palavra de compressão). */
    private fun channelsOf(l: L): List<Pair<Int, ByteArray>> {
        val res = ArrayList<Pair<Int, ByteArray>>()
        val ids = if (mode == 1) listOf(0, -1) else listOf(0, 1, 2, -1)
        for (id in ids) {
            if (l.rgba == null || l.w <= 0 || l.h <= 0) {
                res += id to byteArrayOf(0, 0) // só a compressão (raw), sem dados
                continue
            }
            val plane = ByteArray(l.w * l.h) { i ->
                val o = i * 4
                when (id) {
                    0 -> l.rgba[o]; 1 -> l.rgba[o + 1]; 2 -> l.rgba[o + 2]; else -> l.rgba[o + 3]
                }
            }
            res += id to encodePlane(plane, l.w, l.h, l.comp)
        }
        if (l.withMaskChannel) res += -2 to byteArrayOf(0, 0, 1, 2, 3)
        return res
    }

    private fun encodePlane(plane: ByteArray, w: Int, h: Int, comp: Comp): ByteArray {
        val o = ByteArrayOutputStream()
        val bytesPerSample = if (depth == 16) 2 else 1
        // amostras no formato do arquivo: 16 bits = byte alto = valor, byte baixo = 0xFF
        val samples = if (depth == 16) ByteArray(plane.size * 2) { i -> if (i % 2 == 0) plane[i / 2] else 0xFF.toByte() } else plane
        val rowBytes = w * bytesPerSample
        when (comp) {
            Comp.RAW -> { o.u16(0); o.write(samples) }
            Comp.RLE -> {
                o.u16(1)
                val rows = ArrayList<ByteArray>()
                for (y in 0 until h) rows += packBits(samples, y * rowBytes, rowBytes)
                for (r in rows) o.u16(r.size)
                for (r in rows) o.write(r)
            }
            Comp.ZIP -> { o.u16(2); o.write(deflate(samples)) }
            Comp.ZIP_PRED -> {
                o.u16(3)
                val p = samples.copyOf()
                if (depth == 8) {
                    for (y in 0 until h) for (x in w - 1 downTo 1) p[y * w + x] = (p[y * w + x] - p[y * w + x - 1]).toByte()
                } else {
                    for (y in 0 until h) for (x in w - 1 downTo 1) {
                        val i = (y * w + x) * 2
                        val cur = ((p[i].toInt() and 0xFF) shl 8) or (p[i + 1].toInt() and 0xFF)
                        val prev = ((p[i - 2].toInt() and 0xFF) shl 8) or (p[i - 1].toInt() and 0xFF)
                        val d = (cur - prev) and 0xFFFF
                        p[i] = (d ushr 8).toByte(); p[i + 1] = d.toByte()
                    }
                }
                o.write(deflate(p))
            }
        }
        return o.toByteArray()
    }

    private fun deflate(b: ByteArray): ByteArray {
        val d = Deflater(); d.setInput(b); d.finish()
        val o = ByteArrayOutputStream(); val buf = ByteArray(4096)
        while (!d.finished()) { val n = d.deflate(buf); o.write(buf, 0, n) }
        d.end(); return o.toByteArray()
    }

    /** PackBits com literais e repetições. */
    private fun packBits(src: ByteArray, off: Int, len: Int): ByteArray {
        val o = ByteArrayOutputStream()
        var i = 0
        while (i < len) {
            var run = 1
            while (i + run < len && run < 128 && src[off + i + run] == src[off + i]) run++
            if (run >= 3) {
                o.write(1 - run); o.write(src[off + i].toInt()); i += run
            } else {
                var lit = 0
                while (i + lit < len && lit < 128 &&
                    !(i + lit + 2 < len && src[off + i + lit] == src[off + i + lit + 1] && src[off + i + lit] == src[off + i + lit + 2])
                ) lit++
                if (lit == 0) lit = 1
                o.write(lit - 1); o.write(src, off + i, lit); i += lit
            }
        }
        return o.toByteArray()
    }
}
