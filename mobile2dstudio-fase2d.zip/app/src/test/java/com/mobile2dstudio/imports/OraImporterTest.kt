package com.mobile2dstudio.imports

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.io.ByteArrayOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class OraImporterTest {
    private fun png(w: Int, h: Int, v: Int = 100) = PngEncoder.encodeRgba(w, h, ByteArray(w * h * 4) { v.toByte() })

    private fun ora(stack: String, files: Map<String, ByteArray>): ByteArray {
        val o = ByteArrayOutputStream()
        ZipOutputStream(o).use { z ->
            z.putNextEntry(ZipEntry("mimetype")); z.write("image/openraster".toByteArray()); z.closeEntry()
            z.putNextEntry(ZipEntry("stack.xml")); z.write(stack.toByteArray()); z.closeEntry()
            for ((n, d) in files) { z.putNextEntry(ZipEntry(n)); z.write(d); z.closeEntry() }
        }
        return o.toByteArray()
    }

    @Test
    fun firstXmlElementIsTopAndGroupsNest() {
        val xml = """<?xml version="1.0"?>
            <image w="200" h="100"><stack>
              <layer name="topo" src="data/a.png" x="5" y="6" opacity="0.5"/>
              <stack name="Grupo" visibility="hidden" opacity="0.25">
                <layer name="meio" src="data/b.png" x="10" y="20"/>
                <layer name="base-grupo" src="data/c.png" visibility="hidden"/>
              </stack>
              <layer name="fundo" src="data/d.png"/>
            </stack></image>"""
        val doc = OraImporter.read(ora(xml, mapOf(
            "data/a.png" to png(4, 4), "data/b.png" to png(6, 2), "data/c.png" to png(3, 3), "data/d.png" to png(200, 100),
            "mergedimage.png" to png(200, 100), "Thumbnails/thumbnail.png" to png(16, 8)
        )))
        assertEquals(200, doc.width); assertEquals(100, doc.height)
        assertEquals(listOf("fundo", "Grupo", "topo"), doc.layers.map { it.name })
        val g = doc.layers[1]
        assertTrue(g.isGroup); assertFalse(g.visible); assertEquals(0.25f, g.opacity, 1e-4f)
        assertEquals(listOf("base-grupo", "meio"), g.children.map { it.name })
        assertFalse(g.children[0].visible)
        val top = doc.layers[2]
        assertEquals(5, top.left); assertEquals(6, top.top); assertEquals(0.5f, top.opacity, 1e-4f)
        assertEquals(4, top.width)
        assertEquals(6, g.children[1].width); assertEquals(2, g.children[1].height)
        assertEquals(4, doc.imageLayerCount())
    }

    @Test
    fun missingImageIsWarnedNotFatal() {
        val xml = """<image w="10" h="10"><stack><layer name="x" src="data/x.png"/><layer name="ok" src="data/o.png"/></stack></image>"""
        val doc = OraImporter.read(ora(xml, mapOf("data/o.png" to png(2, 2))))
        assertEquals(1, doc.layers.size)
        assertTrue(doc.warnings.any { it.contains("não encontrada") })
    }

    @Test
    fun pathTraversalIsNotFollowed() {
        val xml = """<image w="10" h="10"><stack><layer name="mal" src="../evil.png"/><layer name="ok" src="data/o.png"/></stack></image>"""
        val doc = OraImporter.read(ora(xml, mapOf("../evil.png" to png(2, 2), "data/o.png" to png(2, 2))))
        assertEquals(listOf("ok"), doc.layers.map { it.name })
        assertTrue(doc.warnings.any { it.contains("inseguro") })
        assertEquals(null, OraImporter.normalizePath("a/../../b"))
        assertEquals(null, OraImporter.normalizePath("/etc/passwd"))
        assertEquals(null, OraImporter.normalizePath("C:/x.png"))
        assertEquals("data/a.png", OraImporter.normalizePath("./data\\a.png"))
    }

    @Test
    fun doctypeAndEntitiesAreRefused() {
        val xml = """<?xml version="1.0"?><!DOCTYPE image [<!ENTITY xxe SYSTEM "file:///etc/passwd">]>
            <image w="10" h="10"><stack><layer name="&xxe;" src="data/o.png"/></stack></image>"""
        try { OraImporter.read(ora(xml, mapOf("data/o.png" to png(2, 2)))); fail() }
        catch (e: ImportException) { assertTrue(e.message!!, e.message!!.contains("DOCTYPE")) }
    }

    @Test
    fun zipBombIsRefused() {
        // PNG "enorme" cujo conteúdo descompactado passa do limite de entrada: usa entrada de stack.xml gigante
        val big = "<image w=\"10\" h=\"10\"><stack>" + " ".repeat((ImportLimits.MAX_XML_BYTES + 10).toInt()) + "</stack></image>"
        try { OraImporter.read(ora(big, emptyMap())); fail() }
        catch (e: ImportException) { assertTrue(e.message!!, e.message!!.contains("grande demais")) }
    }

    @Test
    fun clearErrors() {
        fun err(bytes: ByteArray, part: String) {
            try { OraImporter.read(bytes); fail("deveria falhar: $part") }
            catch (e: ImportException) { assertTrue(e.message!!, e.message!!.contains(part, ignoreCase = true)) }
        }
        err(ByteArray(50) { 1 }, "stack.xml")
        err(ora("<image w=\"10\" h=\"10\"><stack/></image>", emptyMap()), "nenhuma camada")
        err(ora("<image><stack/></image>", emptyMap()), "largura")
        err(ora("<image w=\"99999\" h=\"10\"><stack/></image>", emptyMap()), "grande demais")
        err(ora("<foo/>", emptyMap()), "<image>")
        err(ora("<image w=\"1\" h=\"1\"", emptyMap()), "ilegível")
        val good = ora("<image w=\"10\" h=\"10\"><stack><layer name=\"a\" src=\"a.png\"/></stack></image>", mapOf("a.png" to png(2, 2)))
        try { DocumentImporter.import("x.ora", good.copyOf(good.size / 2)); fail() } catch (_: ImportException) { }
    }

    @Test
    fun dispatchesByContent() {
        val good = ora("<image w=\"10\" h=\"10\"><stack><layer name=\"a\" src=\"a.png\"/></stack></image>", mapOf("a.png" to png(2, 2)))
        assertEquals(1, DocumentImporter.import("qualquer.bin", good).layers.size)
    }
}
