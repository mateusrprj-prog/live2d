package com.mobile2dstudio.imports

import com.mobile2dstudio.imports.PsdBuilder.Comp
import com.mobile2dstudio.imports.PsdBuilder.L
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.io.ByteArrayInputStream
import javax.imageio.ImageIO

class PsdImporterTest {
    private fun solid(w: Int, h: Int, r: Int, g: Int, b: Int, a: Int = 255) =
        ByteArray(w * h * 4) { i -> when (i % 4) { 0 -> r; 1 -> g; 2 -> b; else -> a }.toByte() }

    /** Padrão que exercita RLE (trechos repetidos) e literais. */
    private fun varied(w: Int, h: Int, seed: Int) = ByteArray(w * h * 4) { i ->
        val px = i / 4
        when (i % 4) {
            0 -> if ((px / 3) % 2 == 0) 200 else (px * 7 + seed) and 0xFF
            1 -> (px * 13 + seed) and 0xFF
            2 -> seed and 0xFF
            else -> if (px % 5 == 0) 128 else 255
        }.toByte()
    }

    private fun decode(png: ByteArray): ByteArray {
        val img = ImageIO.read(ByteArrayInputStream(png))
        val out = ByteArray(img.width * img.height * 4)
        val px = IntArray(4)
        for (y in 0 until img.height) for (x in 0 until img.width) {
            img.raster.getPixel(x, y, px)
            val o = (y * img.width + x) * 4
            for (k in 0..3) out[o + k] = px[k].toByte()
        }
        return out
    }

    @Test
    fun allCompressionsReproducePixels() {
        val w = 9; val h = 6
        val pix = varied(w, h, 5)
        val builder = PsdBuilder(32, 32)
        val comps = listOf(Comp.RAW, Comp.RLE, Comp.ZIP, Comp.ZIP_PRED)
        for ((i, c) in comps.withIndex())
            builder.add(L("L$i", left = i, top = 2 * i, w = w, h = h, rgba = pix, comp = c))
        val doc = PsdImporter.read(builder.build())
        assertEquals(32, doc.width); assertEquals(32, doc.height)
        assertEquals(4, doc.layers.size)
        for ((i, l) in doc.layers.withIndex()) {
            assertEquals("L$i", l.name)
            assertEquals(i, l.left); assertEquals(2 * i, l.top)
            assertEquals(w, l.width); assertEquals(h, l.height)
            assertArrayEquals("pixels de ${comps[i]}", pix, decode(l.png!!))
        }
    }

    @Test
    fun nestedGroupsOpacityAndHiddenAreRebuilt() {
        // Ordem do arquivo = de trás para frente.
        val b = PsdBuilder(64, 64)
        b.add(L("fundo", w = 4, h = 4, rgba = solid(4, 4, 1, 2, 3)))
        b.add(L("</Layer group>", section = 3))                     // abre grupo externo
        b.add(L("dentro1", w = 2, h = 2, rgba = solid(2, 2, 9, 9, 9), opacity = 128))
        b.add(L("</Layer group>", section = 3))                     // abre grupo interno
        b.add(L("fundo-interno", w = 2, h = 2, rgba = solid(2, 2, 7, 7, 7), hidden = true))
        b.add(L("Interno", section = 1))                           // fecha interno
        b.add(L("Externo", section = 2, opacity = 51))             // fecha externo (fechado)
        b.add(L("topo", w = 3, h = 3, rgba = solid(3, 3, 5, 5, 5)))
        val doc = PsdImporter.read(b.build())

        assertEquals(listOf("fundo", "Externo", "topo"), doc.layers.map { it.name })
        val ext = doc.layers[1]
        assertTrue(ext.isGroup)
        assertEquals(0.2f, ext.opacity, 0.01f)
        assertEquals(listOf("dentro1", "Interno"), ext.children.map { it.name })
        assertEquals(128 / 255f, ext.children[0].opacity, 0.001f)
        val inner = ext.children[1]
        assertTrue(inner.isGroup)
        assertEquals(1, inner.children.size)
        assertFalse(inner.children[0].visible)
        assertTrue(inner.visible)
        assertEquals(4, doc.imageLayerCount())
    }

    @Test
    fun unicodeNameIsPreferred() {
        val b = PsdBuilder(16, 16).add(L("olho", w = 2, h = 2, rgba = solid(2, 2, 1, 1, 1), unicodeName = "olho — 目"))
        assertEquals("olho — 目", PsdImporter.read(b.build()).layers[0].name)
    }

    @Test
    fun transparencyIsKeptAsStraightAlpha() {
        val pix = solid(3, 3, 10, 20, 30, 77)
        val doc = PsdImporter.read(PsdBuilder(8, 8).add(L("a", w = 3, h = 3, rgba = pix, comp = Comp.RLE)).build())
        assertArrayEquals(pix, decode(doc.layers[0].png!!))
    }

    @Test
    fun maskBlendAndEmptyLayersProduceWarnings() {
        val b = PsdBuilder(16, 16)
        b.add(L("com mascara", w = 2, h = 2, rgba = solid(2, 2, 1, 1, 1), withMaskChannel = true))
        b.add(L("multiplicar", w = 2, h = 2, rgba = solid(2, 2, 1, 1, 1), blendKey = "mul "))
        b.add(L("vazia"))
        val doc = PsdImporter.read(b.build())
        assertEquals(2, doc.layers.size)
        val all = doc.warnings.joinToString("\n")
        assertTrue(all, all.contains("máscara"))
        assertTrue(all, all.contains("mesclagem"))
        assertTrue(all, all.contains("vazias"))
    }

    @Test
    fun sixteenBitUsesHighByteAndWarns() {
        val pix = varied(5, 4, 3)
        for (comp in listOf(Comp.RAW, Comp.RLE, Comp.ZIP, Comp.ZIP_PRED)) {
            val doc = PsdImporter.read(PsdBuilder(8, 8, depth = 16).add(L("a", w = 5, h = 4, rgba = pix, comp = comp)).build())
            assertArrayEquals("16 bits $comp", pix, decode(doc.layers[0].png!!))
            assertTrue(doc.warnings.any { it.contains("16 bits") })
        }
    }

    @Test
    fun grayscaleBecomesRgb() {
        val pix = ByteArray(4 * 4) { i -> if (i % 4 == 3) 255.toByte() else (i * 9).toByte() }
        // em tons de cinza o canal 0 usa o valor R do pixel
        val doc = PsdImporter.read(PsdBuilder(8, 8, mode = 1).add(L("g", w = 2, h = 2, rgba = pix)).build())
        val out = decode(doc.layers[0].png!!)
        for (p in 0 until 4) {
            val v = pix[p * 4]
            assertEquals(v, out[p * 4]); assertEquals(v, out[p * 4 + 1]); assertEquals(v, out[p * 4 + 2])
        }
    }

    private fun expectError(bytes: ByteArray, part: String) {
        try { PsdImporter.read(bytes); fail("deveria falhar: $part") }
        catch (e: ImportException) { assertTrue("mensagem: ${e.message}", e.message!!.contains(part, ignoreCase = true)) }
    }

    @Test
    fun clearErrors() {
        val ok = PsdBuilder(16, 16).add(L("a", w = 2, h = 2, rgba = solid(2, 2, 1, 1, 1))).build()
        // assinatura errada
        expectError(ok.copyOf().also { it[0] = 'X'.code.toByte() }, "PSD")
        // PSB
        expectError(ok.copyOf().also { it[5] = 2 }, "PSB")
        // CMYK
        expectError(PsdBuilder(16, 16, mode = 4).add(L("a", w = 2, h = 2, rgba = solid(2, 2, 1, 1, 1))).build(), "CMYK")
        // Lab
        expectError(PsdBuilder(16, 16, mode = 9).add(L("a", w = 2, h = 2, rgba = solid(2, 2, 1, 1, 1))).build(), "Lab")
        // 32 bits
        expectError(PsdBuilder(16, 16, depth = 32).add(L("a", w = 2, h = 2, rgba = solid(2, 2, 1, 1, 1))).build(), "32 bits")
        // truncado em vários pontos (antes do fim da seção de camadas; a imagem achatada final não é lida)
        for (cut in listOf(10, 26, 40, 80, (ok.size - 770) / 2, ok.size - 770 - 5)) {
            if (cut in 1 until ok.size) {
                try { PsdImporter.read(ok.copyOf(cut)); fail("truncado em $cut deveria falhar") } catch (_: ImportException) { }
            }
        }
        // sem camadas
        val none = ByteArray(26 + 4 + 4 + 4 + 2 + 16 * 16 * 3)
        System.arraycopy(ok, 0, none, 0, 26)
        // layer and mask length = 0 já é o padrão (zeros) → "sem camadas"
        expectError(none, "não tem camadas")
        // documento grande demais
        expectError(PsdBuilder(9000, 4).add(L("a", w = 2, h = 2, rgba = solid(2, 2, 1, 1, 1))).build(), "tamanho")
    }

    @Test
    fun corruptedRleIsRejectedNotCrashing() {
        val good = PsdBuilder(16, 16).add(L("a", w = 8, h = 8, rgba = varied(8, 8, 1), comp = Comp.RLE)).build()
        var failures = 0
        // corrompe bytes um a um na região de dados; nunca pode lançar exceção que não seja ImportException
        for (i in 100 until good.size step 7) {
            val c = good.copyOf(); c[i] = (c[i] + 77).toByte()
            try { PsdImporter.read(c) } catch (_: ImportException) { failures++ }
        }
        assertTrue(failures > 0)
    }

    @Test
    fun layerImportPlacesPartsInWorldSpace() {
        val b = PsdBuilder(100, 60)
        b.add(L("fundo", left = 0, top = 0, w = 100, h = 60, rgba = solid(100, 60, 1, 1, 1)))
        b.add(L("</Layer group>", section = 3))
        b.add(L("olho", left = 10, top = 20, w = 20, h = 10, rgba = solid(20, 10, 9, 9, 9), opacity = 128, hidden = true))
        b.add(L("Cabeça", section = 1))
        val doc = PsdImporter.read(b.build())
        val res = LayerImport.toParts(doc)
        assertEquals(3, res.parts.size)
        assertEquals(listOf("fundo", "Cabeça", "olho"), res.parts.map { it.name })
        assertEquals(2, res.assets.size)

        val bg = res.parts[0]
        assertEquals(0f, bg.transform.x, 1e-4f); assertEquals(0f, bg.transform.y, 1e-4f)
        val head = res.parts[1]
        assertNull(head.mesh); assertNull(head.parentId)
        val eye = res.parts[2]
        assertEquals(head.id, eye.parentId)
        assertFalse(eye.visible)
        assertEquals(128 / 255f, eye.opacity, 0.001f)
        // centro da camada (20,25) no doc 100x60 → x = 20 - 50 = -30, y = 30 - 25 = 5
        assertEquals(-30f, eye.transform.x, 1e-4f); assertEquals(5f, eye.transform.y, 1e-4f)
        assertNotNull(eye.textureId)
        assertTrue(res.assets.any { it.id == eye.textureId && it.width == 20 && it.height == 10 })
        assertTrue(eye.mesh!!.validate().isEmpty())
        assertEquals(4, eye.mesh!!.vertexCount)
        // malha centrada na origem local
        assertEquals(-10f, eye.mesh!!.positions[0], 1e-4f); assertEquals(-5f, eye.mesh!!.positions[1], 1e-4f)
        // ids únicos
        assertEquals(res.parts.size, res.parts.map { it.id }.toSet().size)
    }
}
