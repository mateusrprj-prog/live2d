package com.mobile2dstudio.imports

import com.mobile2dstudio.project.ImageFormat
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.awt.image.BufferedImage
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import javax.imageio.ImageIO

class ImageCodecTest {
    private fun rgbaPattern(w: Int, h: Int) = ByteArray(w * h * 4) { i -> ((i * 37 + 11) and 0xFF).toByte() }

    @Test
    fun pngEncoderRoundTripsThroughImageIo() {
        val w = 13; val h = 7
        val rgba = rgbaPattern(w, h)
        val png = PngEncoder.encodeRgba(w, h, rgba)
        val img = ImageIO.read(ByteArrayInputStream(png))
        assertEquals(w, img.width); assertEquals(h, img.height)
        for (y in 0 until h) for (x in 0 until w) {
            val o = (y * w + x) * 4
            val argb = img.getRGB(x, y)
            assertEquals(rgba[o + 3].toInt() and 0xFF, (argb ushr 24) and 0xFF)
            // ImageIO pode pré-multiplicar internamente; só comparamos cor onde o alfa é 255 ou conferimos ida e volta pelo raster
            val raster = img.raster
            val px = IntArray(4)
            raster.getPixel(x, y, px)
            assertEquals(rgba[o].toInt() and 0xFF, px[0])
            assertEquals(rgba[o + 1].toInt() and 0xFF, px[1])
            assertEquals(rgba[o + 2].toInt() and 0xFF, px[2])
            assertEquals(rgba[o + 3].toInt() and 0xFF, px[3])
        }
    }

    @Test
    fun readsPngDimensions() {
        val png = PngEncoder.encodeRgba(31, 17, rgbaPattern(31, 17))
        val info = ImageInfoReader.read(png)
        assertEquals(31, info.width); assertEquals(17, info.height); assertEquals(ImageFormat.PNG, info.format)
    }

    @Test
    fun readsJpegDimensions() {
        val img = BufferedImage(45, 23, BufferedImage.TYPE_INT_RGB)
        val o = ByteArrayOutputStream()
        assertTrue(ImageIO.write(img, "jpg", o))
        val info = ImageInfoReader.read(o.toByteArray())
        assertEquals(45, info.width); assertEquals(23, info.height); assertEquals(ImageFormat.JPEG, info.format)
    }

    @Test
    fun rejectsGarbageAndTruncated() {
        for (bad in listOf(ByteArray(0), byteArrayOf(1, 2, 3), ByteArray(40) { 7 })) {
            try { ImageInfoReader.read(bad); fail("deveria falhar") } catch (_: ImportException) { }
        }
        val png = PngEncoder.encodeRgba(4, 4, rgbaPattern(4, 4))
        try { ImageInfoReader.read(png.copyOf(15)); fail("deveria falhar") } catch (_: ImportException) { }
        try { ImageInfoReader.read(byteArrayOf(0xFF.toByte(), 0xD8.toByte(), 0xFF.toByte(), 0xE0.toByte(), 0, 4, 0, 0)); fail("deveria falhar") } catch (_: ImportException) { }
    }

    @Test
    fun singleImageBecomesOneLayerNamedAfterFile() {
        val png = PngEncoder.encodeRgba(20, 10, rgbaPattern(20, 10))
        val doc = DocumentImporter.import("C:\\pasta/olho esquerdo.png", png)
        assertEquals(20, doc.width); assertEquals(10, doc.height)
        assertEquals(1, doc.layers.size)
        assertEquals("olho esquerdo", doc.layers[0].name)
        assertEquals(1, doc.imageLayerCount())
    }

    @Test
    fun unknownFormatAndEmptyFileGiveClearErrors() {
        try { DocumentImporter.import("a.bin", ByteArray(0)); fail() } catch (e: ImportException) { assertTrue(e.message!!.contains("vazio")) }
        try { DocumentImporter.import("a.bin", ByteArray(100) { 9 }); fail() } catch (e: ImportException) { assertTrue(e.message!!.contains("Formato")) }
    }
}
