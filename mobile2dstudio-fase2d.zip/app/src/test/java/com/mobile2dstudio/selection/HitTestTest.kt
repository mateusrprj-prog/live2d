package com.mobile2dstudio.selection

import com.mobile2dstudio.geometry.Transform2D
import com.mobile2dstudio.mesh.MeshGenerator
import com.mobile2dstudio.project.Part
import com.mobile2dstudio.project.PartTree
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class HitTestTest {
    private fun part(id: String, x: Float = 0f, visible: Boolean = true, locked: Boolean = false) = Part(
        id = id, name = id, parentId = null, visible = visible, locked = locked,
        mesh = MeshGenerator.grid(100f, 100f, 1, 1, -50f, -50f),
        transform = Transform2D(x = x)
    )

    @Test fun pointPicksFrontmostPart() {
        val back = part("back")
        val front = part("front")
        assertEquals("front", HitTest.point(listOf(back, front), 0f, 0f))
    }

    @Test fun pointIgnoresHiddenAndLockedParts() {
        assertEquals("back", HitTest.point(listOf(part("back"), part("hidden", visible = false)), 0f, 0f))
        assertEquals("back", HitTest.point(listOf(part("back"), part("locked", locked = true)), 0f, 0f))
        assertNull(HitTest.point(listOf(part("hidden", visible = false)), 0f, 0f))
    }

    @Test fun pointRespectsParentTransform() {
        val group = Part("g", "g", null, true, false, null)
        val child = part("child").copy(parentId = "g")
        val movedGroup = group.copy(transform = Transform2D(x = 200f))
        assertEquals("child", HitTest.point(listOf(movedGroup, child), 200f, 0f))
        assertNull(HitTest.point(listOf(movedGroup, child), 0f, 0f))
    }

    @Test fun rectangleReturnsIntersectingPartsInDrawOrder() {
        val parts = listOf(part("a", -100f), part("b", 100f), part("hidden", visible = false))
        assertEquals(listOf("a", "b"), HitTest.rectangle(parts, -160f, -60f, 160f, 60f))
        assertEquals(listOf("b"), HitTest.rectangle(parts, 60f, -60f, 160f, 60f))
    }

    @Test fun partTreeTranslateWorldStillReturnsHit() {
        val moved = PartTree.translateWorld(listOf(part("a")), listOf("a"), 25f, 0f)
        assertEquals("a", HitTest.point(moved, 25f, 0f))
    }
}
