package com.mobile2dstudio.mesh

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs

class MeshGeneratorTest {
    @Test
    fun gridHasExpectedCountsAndIsValid() {
        val m = MeshGenerator.grid(100f, 50f, 4, 2, -50f, -25f)
        assertEquals(15, m.vertexCount)
        assertEquals(16, m.triangleCount)
        assertTrue(m.validate().isEmpty())
    }

    @Test
    fun gridTrianglesCoverTheWholeRectangle() {
        val m = MeshGenerator.grid(100f, 50f, 4, 2, -50f, -25f)
        var area = 0f
        for (t in 0 until m.triangleCount) {
            val a = m.indices[t * 3]
            val b = m.indices[t * 3 + 1]
            val c = m.indices[t * 3 + 2]
            val cross = (m.positions[b * 2] - m.positions[a * 2]) * (m.positions[c * 2 + 1] - m.positions[a * 2 + 1]) -
                (m.positions[c * 2] - m.positions[a * 2]) * (m.positions[b * 2 + 1] - m.positions[a * 2 + 1])
            assertTrue("triângulo deve ser anti-horário", cross > 0f)
            area += abs(cross) / 2f
        }
        assertEquals(5000f, area, 0.05f)
    }

    @Test
    fun uvsMapBottomToOneAndTopToZero() {
        val m = MeshGenerator.grid(100f, 50f, 4, 2, -50f, -25f)
        assertEquals(-50f, m.positions[0], 0f)
        assertEquals(-25f, m.positions[1], 0f)
        assertEquals(0f, m.uvs[0], 0f)
        assertEquals(1f, m.uvs[1], 0f)
        val last = m.vertexCount - 1
        assertEquals(50f, m.positions[last * 2], 1e-4f)
        assertEquals(25f, m.positions[last * 2 + 1], 1e-4f)
        assertEquals(1f, m.uvs[last * 2], 0f)
        assertEquals(0f, m.uvs[last * 2 + 1], 0f)
    }

    @Test
    fun edgeIndicesAreUnique() {
        assertEquals(5, MeshGenerator.grid(1f, 1f, 1, 1, 0f, 0f).edgeIndices().size / 2)
        assertEquals(16, MeshGenerator.grid(2f, 2f, 2, 2, 0f, 0f).edgeIndices().size / 2)
    }

    @Test
    fun validateDetectsOutOfRangeIndex() {
        val m = ArtMesh(floatArrayOf(0f, 0f, 1f, 0f, 0f, 1f), floatArrayOf(0f, 0f, 1f, 0f, 0f, 1f), intArrayOf(0, 1, 7))
        assertTrue(m.validate().isNotEmpty())
    }

    @Test
    fun validateDetectsDegenerateTriangle() {
        val m = ArtMesh(floatArrayOf(0f, 0f, 1f, 0f, 2f, 0f), floatArrayOf(0f, 0f, 1f, 0f, 0f, 1f), intArrayOf(0, 1, 2))
        assertTrue(m.validate().isNotEmpty())
    }

    @Test
    fun validateDetectsMismatchedUvs() {
        val m = ArtMesh(floatArrayOf(0f, 0f, 1f, 0f, 0f, 1f), floatArrayOf(0f, 0f), intArrayOf(0, 1, 2))
        assertTrue(m.validate().isNotEmpty())
    }

    @Test(expected = IllegalArgumentException::class)
    fun gridRejectsZeroColumns() {
        MeshGenerator.grid(10f, 10f, 0, 1, 0f, 0f)
    }
}
