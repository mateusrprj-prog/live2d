package com.mobile2dstudio.history

import com.mobile2dstudio.project.EditState
import com.mobile2dstudio.project.Part
import com.mobile2dstudio.project.PartTree
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test

class EditSessionTest {
    private fun part(id: String) = Part(id, id, null, true, false, null)
    private fun session(vararg ids: String) = EditSession(EditState(ids.map { part(it) }, emptyList()))
    private fun EditSession.ids() = state.parts.map { it.id }

    @Test
    fun undoRedoRestoreExactStates() {
        val s = session("a")
        val initial = s.state
        assertTrue(s.apply("Adicionar b") { it.copy(parts = PartTree.add(it.parts, part("b"))) })
        assertTrue(s.apply("Adicionar c") { it.copy(parts = PartTree.add(it.parts, part("c"))) })
        assertEquals(listOf("a", "b", "c"), s.ids())

        assertTrue(s.undo())
        assertEquals(listOf("a", "b"), s.ids())
        assertTrue(s.undo())
        assertSame(initial, s.state)
        assertFalse(s.undo())

        assertTrue(s.redo())
        assertTrue(s.redo())
        assertEquals(listOf("a", "b", "c"), s.ids())
        assertFalse(s.redo())
    }

    @Test
    fun newEditClearsRedo() {
        val s = session("a")
        s.apply("b") { it.copy(parts = PartTree.add(it.parts, part("b"))) }
        s.undo()
        assertTrue(s.canRedo)
        s.apply("c") { it.copy(parts = PartTree.add(it.parts, part("c"))) }
        assertFalse(s.canRedo)
        assertEquals(listOf("a", "c"), s.ids())
    }

    @Test
    fun noOpDoesNotCreateHistory() {
        val s = session("a")
        assertFalse(s.apply("nada") { it })
        assertFalse(s.canUndo)
    }

    @Test
    fun dragIsMergedIntoSingleUndoUntilGestureEnds() {
        val s = session("a")
        for (i in 1..30) {
            s.apply("Mover", mergeKey = "drag:a") { st ->
                st.copy(parts = PartTree.translateWorld(st.parts, listOf("a"), 1f, 0f))
            }
        }
        assertEquals(30f, s.state.parts[0].transform.x, 1e-4f)
        s.endGesture()
        s.apply("Mover", mergeKey = "drag:a") { st ->
            st.copy(parts = PartTree.translateWorld(st.parts, listOf("a"), 5f, 0f))
        }
        assertEquals(35f, s.state.parts[0].transform.x, 1e-4f)

        s.undo() // só o segundo arrasto
        assertEquals(30f, s.state.parts[0].transform.x, 1e-4f)
        s.undo() // o primeiro arrasto inteiro
        assertEquals(0f, s.state.parts[0].transform.x, 1e-4f)
        assertFalse(s.canUndo)
    }

    @Test
    fun differentMergeKeysAreNotMerged() {
        val s = session("a", "b")
        s.apply("Mover a", "drag:a") { st -> st.copy(parts = PartTree.translateWorld(st.parts, listOf("a"), 1f, 0f)) }
        s.apply("Mover b", "drag:b") { st -> st.copy(parts = PartTree.translateWorld(st.parts, listOf("b"), 1f, 0f)) }
        s.undo()
        assertEquals(1f, s.state.parts[0].transform.x, 1e-4f)
        assertEquals(0f, s.state.parts[1].transform.x, 1e-4f)
    }

    @Test
    fun historyIsBounded() {
        val s = EditSession(EditState(listOf(part("a")), emptyList()), historyLimit = 3)
        for (i in 1..10) s.apply("n$i") { it.copy(parts = PartTree.add(it.parts, part("p$i"))) }
        var undone = 0
        while (s.undo()) undone++
        assertEquals(3, undone)
    }

    @Test
    fun labelsAndReset() {
        val s = session("a")
        assertNull(s.undoLabel)
        s.apply("Criar grupo") { it.copy(parts = PartTree.add(it.parts, part("b"))) }
        assertEquals("Criar grupo", s.undoLabel)
        s.undo()
        assertEquals("Criar grupo", s.redoLabel)
        s.reset(EditState(emptyList(), emptyList()))
        assertFalse(s.canUndo)
        assertFalse(s.canRedo)
        assertTrue(s.state.parts.isEmpty())
    }
}
