package com.mobile2dstudio.project

import com.mobile2dstudio.imports.DocumentImporter
import com.mobile2dstudio.imports.PngEncoder
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder

class ProjectImportTest {
    @get:Rule
    val tmp = TemporaryFolder()

    private fun png(w: Int, h: Int) = PngEncoder.encodeRgba(w, h, ByteArray(w * h * 4) { 90 })

    @Test
    fun createFromImportSavesAndReloadsLayersAndTextures() {
        val repo = ProjectRepository(tmp.newFolder())
        val doc = DocumentImporter.import("a.png", png(40, 30))
        val result = repo.createFromImport("Importado", doc)
        val project = result.first
        assertTrue(result.second.isEmpty())
        assertEquals(40, project.meta.width.coerceAtLeast(40))
        assertEquals(1, project.parts.size)
        assertEquals(1, project.assets.size)
        val back = repo.load(project.meta.id)
        assertEquals(1, back.parts.size)
        assertEquals(back.parts[0].textureId, back.assets[0].id)
        assertFalse(back.assets[0].isMissing)
    }

    @Test
    fun tinyDocumentGetsMinimumCanvas() {
        val repo = ProjectRepository(tmp.newFolder())
        val p = repo.createFromImport("Mini", DocumentImporter.import("m.png", png(4, 4))).first
        assertEquals(16, p.meta.width); assertEquals(16, p.meta.height)
    }
}
