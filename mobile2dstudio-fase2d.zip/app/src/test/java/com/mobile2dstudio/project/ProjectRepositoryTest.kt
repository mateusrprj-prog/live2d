package com.mobile2dstudio.project

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

class ProjectRepositoryTest {
    @get:Rule
    val tmp = TemporaryFolder()

    private var now = 1000L
    private lateinit var dir: File

    private fun repo(): ProjectRepository {
        dir = tmp.newFolder()
        return ProjectRepository(dir, clock = { now })
    }

    @Test
    fun createThenListAndLoad() {
        val r = repo()
        val created = r.create("  Meu projeto ", 1080, 1920, 30)
        assertEquals("Meu projeto", created.meta.name)
        assertEquals(1, created.parts.size)

        val list = r.list()
        assertEquals(1, list.size)
        assertEquals(created.meta.id, list[0].meta.id)
        assertTrue(list[0].sizeBytes > 0)

        val loaded = r.load(created.meta.id)
        assertEquals(created.meta, loaded.meta)
        assertEquals(created.parts.size, loaded.parts.size)
        assertEquals(created.parts[0].mesh!!.vertexCount, loaded.parts[0].mesh!!.vertexCount)
    }

    @Test
    fun saveUpdatesModifiedAt() {
        val r = repo()
        val created = r.create("A", 100, 100, 24)
        now = 5000L
        val saved = r.save(created)
        assertEquals(5000L, saved.meta.modifiedAt)
        assertEquals(5000L, r.load(created.meta.id).meta.modifiedAt)
    }

    @Test
    fun renameDuplicateDelete() {
        val r = repo()
        val a = r.create("A", 100, 100, 24)
        r.rename(a.meta.id, "B")
        assertEquals("B", r.load(a.meta.id).meta.name)

        val copy = r.duplicate(a.meta.id)
        assertNotEquals(a.meta.id, copy.meta.id)
        assertEquals("B (cópia)", copy.meta.name)
        assertEquals(2, r.list().size)

        assertTrue(r.delete(a.meta.id))
        val left = r.list()
        assertEquals(1, left.size)
        assertEquals(copy.meta.id, left[0].meta.id)
    }

    @Test
    fun corruptedMainFileRecoversFromBackup() {
        val r = repo()
        val created = r.create("A", 100, 100, 24)
        now = 2000L
        r.save(created) // gera .bak com a versão de t=1000
        File(dir, "${created.meta.id}.v2d").writeText("lixo")

        val recovered = r.load(created.meta.id)
        assertEquals(1000L, recovered.meta.modifiedAt)
    }

    @Test
    fun listSkipsCorruptFiles() {
        val r = repo()
        r.create("A", 100, 100, 24)
        File(dir, "quebrado.v2d").writeText("nao e zip")
        assertEquals(1, r.list().size)
    }

    @Test
    fun noTempFileLeftAfterSave() {
        val r = repo()
        val p = r.create("A", 100, 100, 24)
        r.save(p)
        assertFalse(dir.listFiles()!!.any { it.name.endsWith(".tmp") })
    }

    @Test(expected = IllegalArgumentException::class)
    fun rejectsBlankName() {
        repo().create("   ", 100, 100, 24)
    }

    @Test(expected = IllegalArgumentException::class)
    fun rejectsInvalidResolution() {
        repo().create("A", 4, 100, 24)
    }

    @Test(expected = IllegalArgumentException::class)
    fun rejectsPathTraversalId() {
        repo().load("../fora")
    }
}
