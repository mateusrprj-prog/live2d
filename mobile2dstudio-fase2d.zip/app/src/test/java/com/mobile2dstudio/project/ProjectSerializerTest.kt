package com.mobile2dstudio.project

import com.mobile2dstudio.mesh.MeshGenerator
import org.json.JSONObject
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class ProjectSerializerTest {
    private fun sample(): V2dProject {
        val meta = ProjectMeta("id-1", "Teste", 100L, 200L, 1080, 1920, 30)
        val mesh = MeshGenerator.grid(10.5f, 20.25f, 3, 2, -5.1f, -10.3f)
        return V2dProject(
            meta,
            listOf(
                Part("p1", "Cabeça", null, true, false, mesh),
                Part("p2", "Grupo", "p1", false, true, null)
            )
        )
    }

    @Test
    fun roundTripPreservesEverything() {
        val original = sample()
        val back = ProjectSerializer.fromJson(ProjectSerializer.toJson(original))
        assertEquals(original.meta, back.meta)
        assertEquals(2, back.parts.size)

        val a = back.parts[0]
        assertEquals("Cabeça", a.name)
        assertNull(a.parentId)
        assertEquals(true, a.visible)
        assertNotNull(a.mesh)
        assertArrayEquals(original.parts[0].mesh!!.positions, a.mesh!!.positions, 0f)
        assertArrayEquals(original.parts[0].mesh!!.uvs, a.mesh!!.uvs, 0f)
        assertArrayEquals(original.parts[0].mesh!!.indices, a.mesh!!.indices)

        val b = back.parts[1]
        assertEquals("p1", b.parentId)
        assertEquals(false, b.visible)
        assertEquals(true, b.locked)
        assertNull(b.mesh)
    }

    @Test(expected = ProjectFormatException::class)
    fun rejectsNewerSchema() {
        val json = JSONObject(ProjectSerializer.toJson(sample())).put("schemaVersion", CURRENT_SCHEMA + 1).toString()
        ProjectSerializer.fromJson(json)
    }

    @Test(expected = ProjectFormatException::class)
    fun rejectsMissingSchema() {
        val json = JSONObject(ProjectSerializer.toJson(sample())).apply { remove("schemaVersion") }.toString()
        ProjectSerializer.fromJson(json)
    }

    @Test(expected = ProjectFormatException::class)
    fun rejectsMalformedJson() {
        ProjectSerializer.fromJson("{isto não é json")
    }

    @Test(expected = ProjectFormatException::class)
    fun rejectsInvalidMeshOnLoad() {
        val root = JSONObject(ProjectSerializer.toJson(sample()))
        val mesh = root.getJSONArray("parts").getJSONObject(0).getJSONObject("mesh")
        mesh.getJSONArray("indices").put(0, 9999)
        ProjectSerializer.fromJson(root.toString())
    }

    @Test(expected = ProjectFormatException::class)
    fun refusesToSerializeInvalidMesh() {
        val bad = com.mobile2dstudio.mesh.ArtMesh(floatArrayOf(0f, 0f), floatArrayOf(0f, 0f), intArrayOf(0, 0, 0))
        val p = V2dProject(sample().meta, listOf(Part("x", "ruim", null, true, false, bad)))
        ProjectSerializer.toJson(p)
    }
}
