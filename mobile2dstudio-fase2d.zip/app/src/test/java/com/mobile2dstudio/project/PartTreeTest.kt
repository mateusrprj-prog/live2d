package com.mobile2dstudio.project

import com.mobile2dstudio.geometry.Transform2D
import com.mobile2dstudio.mesh.MeshGenerator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertSame
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Test

class PartTreeTest {
    private val eps = 1e-3f

    private fun group(id: String, parent: String? = null, t: Transform2D = Transform2D.IDENTITY) =
        Part(id, id, parent, true, false, null, PartKind.GROUP, 1f, t)

    private fun leaf(id: String, parent: String? = null, t: Transform2D = Transform2D.IDENTITY) =
        Part(id, id, parent, true, false, MeshGenerator.grid(10f, 10f, 1, 1, -5f, -5f), PartKind.MESH, 1f, t)

    private fun ids(parts: List<Part>) = parts.map { it.id }

    @Test
    fun canonicalOrderPutsChildrenRightAfterParent() {
        val parts = listOf(leaf("a"), group("g"), leaf("b", "g"), leaf("c"), leaf("d", "g"))
        assertEquals(listOf("a", "g", "b", "d", "c"), ids(PartTree.canonicalOrder(parts)))
    }

    @Test
    fun canonicalOrderFixesMissingParentAndCycles() {
        val parts = listOf(leaf("a", "nao-existe"), group("x", "y"), group("y", "x"), leaf("z", "x"))
        val canon = PartTree.canonicalOrder(parts)
        assertEquals(4, canon.size)
        assertEquals(null, canon.first { it.id == "a" }.parentId)
        // O ciclo x<->y é quebrado: exatamente uma das duas vira raiz.
        assertEquals(1, canon.count { (it.id == "x" || it.id == "y") && it.parentId == null })
    }

    @Test
    fun addRespectsParentRules() {
        val parts = listOf(group("g"), leaf("a"))
        val ok = PartTree.add(parts, leaf("n"), "g")
        assertEquals("g", ok.first { it.id == "n" }.parentId)
        assertThrows(IllegalArgumentException::class.java) { PartTree.add(parts, leaf("n"), "a") }
        assertThrows(IllegalArgumentException::class.java) { PartTree.add(parts, leaf("a")) }
        assertThrows(IllegalArgumentException::class.java) { PartTree.add(parts, leaf("n"), "x") }
    }

    @Test
    fun removeDeletesWholeSubtree() {
        val parts = listOf(group("g"), leaf("a", "g"), group("h", "g"), leaf("b", "h"), leaf("c"))
        assertEquals(listOf("c"), ids(PartTree.remove(parts, "g")))
    }

    @Test
    fun moveRejectsCycles() {
        val parts = listOf(group("g"), group("h", "g"))
        assertThrows(IllegalArgumentException::class.java) { PartTree.move(parts, "g", "h") }
        assertThrows(IllegalArgumentException::class.java) { PartTree.move(parts, "g", "g") }
    }

    @Test
    fun moveChangesParentAndPosition() {
        val parts = listOf(leaf("a"), leaf("b"), group("g"))
        val moved = PartTree.move(parts, "a", "g")
        assertEquals(listOf("b", "g", "a"), ids(moved))
        assertEquals("g", moved.first { it.id == "a" }.parentId)
    }

    @Test
    fun reparentKeepsWorldPosition() {
        // Grupo em (100,0) com escala 2; filha em (10,0) local => mundo (120,0).
        val parts = listOf(group("g", null, Transform2D(100f, 0f, 0f, 2f, 2f)), leaf("c", "g", Transform2D(10f, 0f)))
        val moved = PartTree.move(parts, "c", null)
        val c = moved.first { it.id == "c" }
        assertEquals(120f, c.transform.x, eps)
        assertEquals(0f, c.transform.y, eps)
        assertEquals(2f, c.transform.scaleX, eps)
        assertEquals(120f, PartTree.worldOf(moved, "c")!!.tx, eps)
    }

    @Test
    fun reorderWithinSameParentDoesNotTouchTransforms() {
        val a = leaf("a", null, Transform2D(5f, 6f, 33f, 1f, 1f))
        val parts = listOf(a, leaf("b"), leaf("c"))
        val out = PartTree.reorder(parts, "a", 1)
        assertEquals(listOf("b", "a", "c"), ids(out))
        assertSame(a, out.first { it.id == "a" })
        assertEquals(listOf("b", "c", "a"), ids(PartTree.reorder(out, "a", 10)))
        assertEquals(listOf("a", "b", "c"), ids(PartTree.reorder(out, "a", -10)))
    }

    @Test
    fun groupWrapsSelectionAtFirstSlotAndUngroupRestores() {
        val parts = listOf(leaf("a"), leaf("b"), leaf("c"), leaf("d"))
        val grouped = PartTree.group(parts, listOf("b", "c"), "G", "Grupo")
        assertEquals(listOf("a", "G", "b", "c", "d"), ids(grouped))
        assertEquals("G", grouped.first { it.id == "b" }.parentId)
        assertEquals(PartKind.GROUP, grouped.first { it.id == "G" }.kind)

        val back = PartTree.ungroup(grouped, "G")
        assertEquals(listOf("a", "b", "c", "d"), ids(back))
        assertTrue(back.all { it.parentId == null })
    }

    @Test
    fun groupIgnoresSelectedDescendantsOfSelectedGroups() {
        val parts = listOf(group("g"), leaf("a", "g"), leaf("b"))
        val grouped = PartTree.group(parts, listOf("g", "a", "b"), "G", "Tudo")
        assertEquals("G", grouped.first { it.id == "g" }.parentId)
        assertEquals("g", grouped.first { it.id == "a" }.parentId)
        assertEquals("G", grouped.first { it.id == "b" }.parentId)
    }

    @Test
    fun ungroupKeepsVisualPositionWhenGroupWasTransformed() {
        val parts = listOf(group("g", null, Transform2D(50f, 0f, 0f, 1f, 1f)), leaf("c", "g", Transform2D(5f, 0f)))
        val back = PartTree.ungroup(parts, "g")
        assertEquals(55f, back.first { it.id == "c" }.transform.x, eps)
    }

    @Test
    fun resolveInheritsVisibilityLockAndOpacity() {
        val parts = listOf(
            group("g").copy(visible = false, locked = true, opacity = 0.5f),
            leaf("a", "g").copy(opacity = 0.5f),
            leaf("b")
        )
        val r = PartTree.resolve(parts).associateBy { it.part.id }
        assertFalse(r["a"]!!.visible)
        assertTrue(r["a"]!!.locked)
        assertEquals(0.25f, r["a"]!!.opacity, eps)
        assertTrue(r["b"]!!.visible)
        assertEquals(listOf("b"), PartTree.renderList(parts).filter { it.visible }.map { it.part.id })
    }

    @Test
    fun translateWorldAccountsForParentScale() {
        val parts = listOf(group("g", null, Transform2D(0f, 0f, 0f, 2f, 2f)), leaf("c", "g", Transform2D(10f, 0f)))
        val out = PartTree.translateWorld(parts, listOf("c"), 10f, 4f)
        val c = out.first { it.id == "c" }
        assertEquals(15f, c.transform.x, eps)
        assertEquals(2f, c.transform.y, eps)
        assertEquals(30f, PartTree.worldOf(out, "c")!!.tx, eps)
    }

    @Test
    fun translateWorldSkipsLockedAndMovesGroupOnce() {
        val parts = listOf(group("g"), leaf("a", "g"), leaf("b").copy(locked = true))
        val out = PartTree.translateWorld(parts, listOf("g", "a", "b"), 3f, 0f)
        assertEquals(3f, out.first { it.id == "g" }.transform.x, eps)
        assertEquals(0f, out.first { it.id == "a" }.transform.x, eps) // anda junto com o grupo
        assertEquals(0f, out.first { it.id == "b" }.transform.x, eps) // bloqueada
        assertSame(parts[2], out[2])
    }

    @Test
    fun depthAndDescendants() {
        val parts = listOf(group("g"), group("h", "g"), leaf("a", "h"))
        assertEquals(2, PartTree.depthOf(parts, "a"))
        assertEquals(setOf("h", "a"), PartTree.descendantIds(parts, "g"))
    }
}
