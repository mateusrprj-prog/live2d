package com.mobile2dstudio.project

import com.mobile2dstudio.geometry.Transform2D
import com.mobile2dstudio.mesh.MeshGenerator
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

class ProjectV2FormatTest {
    @get:Rule
    val tmp = TemporaryFolder()

    private val meta = ProjectMeta("id-2", "V2", 1L, 2L, 800, 600, 30)

    private fun fakePng(seed: Int) = ByteArray(300) { ((it * 31 + seed) and 0xFF).toByte() }

    private fun sample(): V2dProject {
        val mesh = MeshGenerator.grid(20f, 10f, 1, 1, -10f, -5f)
        val parts = listOf(
            Part("g", "Cabeça", null, true, false, null, PartKind.GROUP, 0.8f, Transform2D(5f, 6f, 15f, 1.5f, -1f)),
            Part("m", "Olho", "g", false, true, mesh, PartKind.MESH, 0.5f, Transform2D(1f, 2f), "tex-1")
        )
        return V2dProject(meta, parts, listOf(ImageAsset("tex-1", "olho.png", 20, 10, ImageFormat.PNG, fakePng(1))))
    }

    @Test
    fun jsonRoundTripKeepsNewFields() {
        val p = sample()
        val back = ProjectSerializer.fromJson(ProjectSerializer.toJson(p)) { path ->
            if (path == "textures/tex-1.png") fakePng(1) else null
        }
        val g = back.parts[0]
        assertEquals(PartKind.GROUP, g.kind)
        assertEquals(0.8f, g.opacity, 1e-6f)
        assertEquals(Transform2D(5f, 6f, 15f, 1.5f, -1f), g.transform)
        val m = back.parts[1]
        assertEquals(PartKind.MESH, m.kind)
        assertEquals("tex-1", m.textureId)
        assertEquals(1, back.assets.size)
        assertEquals("olho.png", back.assets[0].name)
        assertEquals(20, back.assets[0].width)
        assertArrayEquals(fakePng(1), back.assets[0].bytes)
    }

    @Test
    fun missingAssetBytesMarkAssetAsMissingButProjectStillOpens() {
        val back = ProjectSerializer.fromJson(ProjectSerializer.toJson(sample()))
        assertTrue(back.assets[0].isMissing)
        assertEquals(2, back.parts.size)
    }

    @Test
    fun schemaV1FilesStillOpenWithDefaults() {
        val v1 = JSONObject()
        v1.put("schemaVersion", 1)
        v1.put("meta", JSONObject(mapOf("id" to "old", "name" to "Antigo", "createdAt" to 1, "modifiedAt" to 2, "width" to 100, "height" to 100, "fps" to 24)))
        val mesh = JSONObject()
        val grid = MeshGenerator.grid(4f, 4f, 1, 1, 0f, 0f)
        mesh.put("positions", JSONArray(grid.positions.map { it.toDouble() }))
        mesh.put("uvs", JSONArray(grid.uvs.map { it.toDouble() }))
        mesh.put("indices", JSONArray(grid.indices.toList()))
        val part = JSONObject(mapOf("id" to "p", "name" to "Parte", "visible" to true, "locked" to false))
        part.put("parentId", JSONObject.NULL)
        part.put("mesh", mesh)
        v1.put("parts", JSONArray().put(part))

        val loaded = ProjectSerializer.fromJson(v1.toString())
        val p = loaded.parts[0]
        assertEquals(PartKind.MESH, p.kind)
        assertEquals(1f, p.opacity, 0f)
        assertEquals(Transform2D.IDENTITY, p.transform)
        assertNull(p.textureId)
        assertTrue(loaded.assets.isEmpty())
    }

    @Test
    fun repositoryStoresTexturesInsideV2dAndReloadsThem() {
        val repo = ProjectRepository(tmp.newFolder())
        val created = repo.create("Com textura", 800, 600, 30)
        val withTex = created.copy(
            parts = created.parts + sample().parts,
            assets = sample().assets
        )
        repo.save(withTex)

        val loaded = repo.load(created.meta.id)
        assertEquals(1, loaded.assets.size)
        assertFalse(loaded.assets[0].isMissing)
        assertArrayEquals(fakePng(1), loaded.assets[0].bytes)
        assertEquals("tex-1", loaded.parts.last().textureId)

        val copy = repo.duplicate(created.meta.id)
        assertArrayEquals(fakePng(1), repo.load(copy.meta.id).assets[0].bytes)
        assertEquals(2, repo.list().size)
    }

    @Test
    fun missingTextureEntryDoesNotDestroyProject() {
        val dir = tmp.newFolder()
        val repo = ProjectRepository(dir)
        val created = repo.create("X", 800, 600, 30)
        repo.save(created.copy(assets = sample().assets, parts = created.parts + sample().parts))

        // Reescreve o ZIP sem a textura, simulando arquivo danificado.
        val file = File(dir, "${created.meta.id}.v2d")
        val json = java.util.zip.ZipInputStream(file.inputStream()).use { z ->
            z.nextEntry
            z.readBytes()
        }
        java.util.zip.ZipOutputStream(file.outputStream()).use { z ->
            z.putNextEntry(java.util.zip.ZipEntry("project.json"))
            z.write(json)
            z.closeEntry()
        }
        val loaded = repo.load(created.meta.id)
        assertTrue(loaded.assets[0].isMissing)
        assertEquals(created.parts.size + 2, loaded.parts.size)
    }

    @Test
    fun unusedAssetsAreDetected() {
        val p = sample()
        val extra = ImageAsset("orfa", "x", 1, 1, ImageFormat.PNG, fakePng(9))
        val withExtra = p.copy(assets = p.assets + extra)
        assertEquals(listOf("orfa"), PartTree.unusedAssets(withExtra).map { it.id })
    }
}
