package com.mobile2dstudio.geometry

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class AffineTest {
    private val eps = 1e-4f

    @Test
    fun identityDoesNothing() {
        val v = Affine.IDENTITY.apply(3f, -4f)
        assertEquals(3f, v.x, eps)
        assertEquals(-4f, v.y, eps)
    }

    @Test
    fun trsOrderIsScaleThenRotateThenTranslate() {
        // (1,0) -> escala 2 -> (2,0) -> gira 90° -> (0,2) -> move (10,5) -> (10,7)
        val m = Transform2D(10f, 5f, 90f, 2f, 2f).toAffine()
        val v = m.apply(1f, 0f)
        assertEquals(10f, v.x, eps)
        assertEquals(7f, v.y, eps)
    }

    @Test
    fun compositionAppliesChildFirst() {
        val parent = Transform2D(100f, 0f, 0f, 2f, 2f).toAffine()
        val child = Transform2D(10f, 0f).toAffine()
        val v = (parent * child).apply(0f, 0f)
        assertEquals(120f, v.x, eps)
        assertEquals(0f, v.y, eps)
    }

    @Test
    fun inverseUndoesTransform() {
        val m = Transform2D(7f, -3f, 35f, 1.5f, 0.5f).toAffine()
        val inv = m.inverse()
        assertNotNull(inv)
        val p = m.apply(4f, 9f)
        val back = inv!!.apply(p.x, p.y)
        assertEquals(4f, back.x, eps)
        assertEquals(9f, back.y, eps)
        assertTrue((m * inv).isNearly(Affine.IDENTITY, 1e-4f))
    }

    @Test
    fun singularMatrixHasNoInverse() {
        assertNull(Transform2D(0f, 0f, 0f, 0f, 1f).toAffine().inverse())
    }

    @Test
    fun decomposeRoundTrip() {
        val t = Transform2D(12f, -8f, 40f, 2f, 3f)
        val back = Transform2D.fromAffine(t.toAffine())
        assertEquals(t.x, back.x, eps)
        assertEquals(t.y, back.y, eps)
        assertEquals(t.rotationDeg, back.rotationDeg, 1e-3f)
        assertEquals(t.scaleX, back.scaleX, eps)
        assertEquals(t.scaleY, back.scaleY, eps)
    }

    @Test
    fun decomposeKeepsMirror() {
        val t = Transform2D(0f, 0f, 0f, 1f, -1f)
        val back = Transform2D.fromAffine(t.toAffine())
        assertEquals(1f, back.scaleX, eps)
        assertEquals(-1f, back.scaleY, eps)
    }

    @Test
    fun matrix4IsColumnMajor() {
        val out = FloatArray(16)
        Affine(1f, 2f, 3f, 4f, 5f, 6f).toMatrix4(out)
        assertEquals(1f, out[0], 0f)
        assertEquals(2f, out[1], 0f)
        assertEquals(3f, out[4], 0f)
        assertEquals(4f, out[5], 0f)
        assertEquals(5f, out[12], 0f)
        assertEquals(6f, out[13], 0f)
        assertEquals(1f, out[15], 0f)
    }
}
