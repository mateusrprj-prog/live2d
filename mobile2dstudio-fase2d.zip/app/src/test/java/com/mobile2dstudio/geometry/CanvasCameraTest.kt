package com.mobile2dstudio.geometry

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CanvasCameraTest {
    private fun camera() = CanvasCamera().apply {
        setViewport(1080, 2000)
        zoom = 2f
        centerX = 10f
        centerY = -5f
    }

    @Test
    fun worldScreenRoundTrip() {
        val c = camera()
        val s = c.worldToScreen(33f, 44f)
        val w = c.screenToWorld(s.x, s.y)
        assertEquals(33f, w.x, 1e-3f)
        assertEquals(44f, w.y, 1e-3f)
    }

    @Test
    fun cameraCenterMapsToViewportCenter() {
        val c = camera()
        val s = c.worldToScreen(c.centerX, c.centerY)
        assertEquals(540f, s.x, 1e-3f)
        assertEquals(1000f, s.y, 1e-3f)
    }

    @Test
    fun worldYAxisPointsUp() {
        val c = camera()
        assertTrue(c.worldToScreen(0f, 100f).y < c.worldToScreen(0f, 0f).y)
    }

    @Test
    fun panMovesContentWithFinger() {
        val c = camera()
        val before = c.worldToScreen(0f, 0f)
        c.panByScreen(100f, 50f)
        val after = c.worldToScreen(0f, 0f)
        assertEquals(before.x + 100f, after.x, 1e-3f)
        assertEquals(before.y + 50f, after.y, 1e-3f)
    }

    @Test
    fun zoomAtKeepsWorldPointUnderFingerFixed() {
        val c = camera()
        val before = c.screenToWorld(200f, 300f)
        c.zoomAt(1.5f, 200f, 300f)
        val after = c.screenToWorld(200f, 300f)
        assertEquals(before.x, after.x, 1e-3f)
        assertEquals(before.y, after.y, 1e-3f)
        assertEquals(3f, c.zoom, 1e-5f)
    }

    @Test
    fun zoomIsClamped() {
        val c = camera()
        c.zoomAt(1_000_000f, 0f, 0f)
        assertEquals(CanvasCamera.MAX_ZOOM, c.zoom, 0f)
        c.zoomAt(1e-9f, 0f, 0f)
        assertEquals(CanvasCamera.MIN_ZOOM, c.zoom, 0f)
    }

    @Test
    fun fitUsesLimitingAxisAndCentersOnOrigin() {
        val c = CanvasCamera()
        c.setViewport(1000, 2000)
        c.centerX = 99f
        c.fit(1000f, 1000f, 1f)
        assertEquals(1f, c.zoom, 1e-5f)
        assertEquals(0f, c.centerX, 0f)
        c.fit(1000f, 1000f, 0.9f)
        assertEquals(0.9f, c.zoom, 1e-5f)
    }

    @Test
    fun projectionMatrixAgreesWithWorldToScreen() {
        val c = camera()
        val m = FloatArray(16)
        c.projectionMatrix(m)
        val wx = 37f
        val wy = -12f
        val clipX = m[0] * wx + m[12]
        val clipY = m[5] * wy + m[13]
        val sx = (clipX + 1f) * c.viewportWidth / 2f
        val sy = (1f - clipY) * c.viewportHeight / 2f
        val expected = c.worldToScreen(wx, wy)
        assertEquals(expected.x, sx, 1e-2f)
        assertEquals(expected.y, sy, 1e-2f)
    }
}
