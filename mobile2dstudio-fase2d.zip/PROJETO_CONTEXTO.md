# MOBILE 2D STUDIO — CONTEXTO, ROTEIRO E REGISTRO DE ATUALIZAÇÕES

> **Versão deste arquivo: 0.2.0-D (Fase 2, Parte D)** — atualizado em 18/11/2026.
> Este arquivo é a memória do projeto. **A IA deve enviar uma versão ATUALIZADA deste .md junto com CADA atualização do código** (zip + este .md), nunca só o código.

---

## 0. COMO USAR ESTE ARQUIVO

**Para o usuário:** ao iniciar uma conversa nova com qualquer IA, anexe (1) este `PROJETO_CONTEXTO.md`, (2) o `master_prompt_mobile_2d_studio.md` (prompt completo original), (3) o zip do projeto mais recente, e (4) as imagens de referência da UI, se houver. Depois cole o "Prompt de continuação" da seção 11.

**Regras de trabalho para a IA (obrigatórias):**
1. **Trabalhar em PARTES pequenas.** Nunca tentar fazer uma fase inteira de uma vez (a conversa estoura o limite e o trabalho se perde). Uma parte = um bloco coerente, testável, que cabe em uma resposta.
2. **Toda resposta que altera código entrega:** zip do projeto atualizado + este `.md` atualizado (seções 3, 6, 7, 9 no mínimo) + resumo curto.
3. **Não declarar nada "pronto" sem prova.** Se não foi compilado/testado, escrever "não testado" (hoje o compilador só roda no GitHub Actions).
4. **Não remover funcionalidade existente** nem quebrar compatibilidade de arquivos `.v2d` antigos (migrar o esquema).
5. **Não usar código/recursos do Live2D.** Implementação independente. Não declarar compatibilidade com `.moc3`.
6. **Sem placeholders disfarçados:** botão só existe se faz algo real; recurso não pronto aparece desabilitado/identificado.
7. Responder o usuário em **português do Brasil**, direto, sem enrolação.

---

## 1. PRODUTO (resumo do master prompt)

Software de **produção 2D para Android** (Kotlin + Jetpack Compose + Material 3 + OpenGL ES 3.0), inspirado no fluxo do **Live2D Cubism Editor**, mas independente:

`ILUSTRAÇÃO → CAMADAS → MALHAS → DEFORMADORES → RIGGING → PARÂMETROS → FÍSICA → ANIMAÇÃO → EXPORTAÇÃO`

- Nome de trabalho: **Mobile 2D Studio**. Formato próprio: **`.v2d`** (ZIP com `project.json` + `textures/`).
- Dispositivo principal: **POCO X7 Pro, Android 16, ARM64**. Uso **sem PC**: o build é feito pelo **GitHub Actions**.
- Metas: 60 FPS (120 se suportado), autosave sem travar, undo/redo completo, malhas deformadas de verdade (nada de falsificar com escala/rotação da imagem).
- Módulos-alvo: Core, Rendering, Project Manager, Layer Manager, Mesh Editor, Deformation, Rigging, Parameters, Physics, Animation, Timeline, Audio, Import/Export, Interface.

**Roteiro de fases do master prompt:** F1 Fundação · **F2 Importação e canvas** · F3 Mesh Editor · F4 Rigging/Deformadores/Parâmetros/Keyforms · F5 Física · F6 Animação/Timeline/Áudio/Lip-sync · F7 Exportação · F8 Otimização.

---

## 2. AMBIENTE E FLUXO DE BUILD

- Código vai para um repositório GitHub. **Dois formatos aceitos pelo `.github/workflows/build.yml`:**
  1. projeto direto na raiz (`settings.gradle.kts` na raiz); ou
  2. **um único `.zip` do projeto** no repositório (raiz ou subpasta): o workflow descompacta e acha o `settings.gradle.kts`. *Deixe só um .zip* (ao trocar de versão, apague o zip antigo).
- Rodar: GitHub → **Actions → Build Android APK → Run workflow** → baixar artifact **`mobile2dstudio-debug-apk`**.
- O workflow roda **testes unitários** antes do APK. Se um teste falhar, não sai APK (e o artifact `unit-test-reports` mostra o motivo).
- O artifact `gradle-wrapper-files` traz `gradlew`/`gradle/wrapper/` (opcional commitar).
- Stack travada (não atualizar sem motivo): AGP 8.6.1, Kotlin 1.9.25, Compose compiler 1.5.15, Compose BOM 2024.09.03, Gradle 8.9, JDK 17, compileSdk/targetSdk 35, minSdk 26.
- **Ao falhar o build:** o usuário envia o log do Actions (ou print); a IA corrige. Erros de compilação são esperados enquanto o código é escrito sem compilador local.

---

## 3. ESTADO ATUAL DO CÓDIGO (v0.2.0-D)

Pacote raiz `com.mobile2dstudio`:

| Pacote | Conteúdo | Estado |
|---|---|---|
| `geometry` | `CanvasCamera` (pan/zoom, mundo↔tela), **`Affine`, `Transform2D`** (novo) | testado em JVM (não compilado ainda no Actions) |
| `mesh` | `ArtMesh` (positions/uvs/indices + validate + arestas), `MeshGenerator.grid` | ok |
| `project` | (2B: `ProjectRepository.createFromImport`) `V2dProject`, `Part`, `PartKind`, `ImageAsset`, `EditState`, **`PartTree`** (novo), `ProjectSerializer` (esquema 2), `ProjectRepository` | ok |
| `imports` | **`ImportModel`** (`ImportedLayer/Document`, `ImportException`, `ImportLimits`), **`ImageCodec`** (`ImageInfoReader` PNG/JPEG, `PngEncoder`), **`OraImporter`**, **`PsdImporter`** (+`ByteReader`), **`LayerImport`** (documento → partes/texturas), **`DocumentImporter`** (detecta formato pelo conteúdo) — novo, **sem Android** | compilado e testado na JVM com kotlinc 2.0.21 local (46 testes OK); Actions ainda não rodou |
| `history` | `History`, `Command`, `EditCommand`, `EditSession` | ligado à UI para edição, undo/redo e fusão de arrasto |
| `rendering` | `MeshRenderer`, `GpuMesh`, `Shaders`, `GLCanvasView`, `RenderScene` | **2C:** texturas PNG/JPEG reais com cache GL, matriz mundial, opacidade/visibilidade herdadas, fundo xadrez, marcador para textura ausente e contorno de seleção; falta validar no aparelho |
| `selection` | **`HitTest`** (novo) | ponto por triângulos e retângulo por limites transformados; compilado/testado em smoke JVM |
| `ui` | `AppRoot`, `ProjectListScreen`, `EditorScreen`, `Theme` | **2D:** tela inicial e workspace escuro em paisagem; painéis Peças/Deformadores e Inspetor/Parâmetros; árvore hierárquica, toolbar, comandos de edição e controles de transformação ligados ao `EditSession`; recursos F4/F6 aparecem desabilitados |

### 3.1 Convenções que NÃO devem mudar
- **Mundo:** origem no centro do canvas, **Y para cima**. **Tela:** origem no canto superior esquerdo, Y para baixo.
- **UV:** v=0 no topo da textura (linha de baixo da malha recebe v=1).
- **Ordem da lista `parts` = ordem de desenho** (índice 0 = fundo). Entre irmãs, a ordem é a ordem relativa na lista. O painel de partes exibe **invertido** (topo = frente), como no Photoshop/Cubism.
- **`PartTree.canonicalOrder`** = pré-ordem (pai antes dos filhos). Toda operação de `PartTree` devolve lista canônica e **nova** lista; partes não alteradas mantêm a **mesma instância** (o renderer detecta mudança por identidade).
- **Só partes `GROUP` têm filhas.** `MESH` tem `mesh` e (normalmente) `textureId`.
- **`Part.transform` é local** (espaço do pai), ordem: escala → rotação (graus, anti-horária) → translação. A **mesh fica em coordenadas locais** da parte; para camada importada, a origem local = **centro da camada** e `transform.x/y` = centro da camada no espaço do pai.
- **Reparentar preserva a posição visual** (`PartTree.move(..., preserveWorld = true)`).
- **Mutar uma malha = criar NOVA instância de `ArtMesh`.**
- **Toda edição do projeto passa por `EditSession.apply(label, mergeKey) { estado -> novoEstado }`** (senão o desfazer perde a alteração). Arrastar: mesma `mergeKey` durante o gesto, `endGesture()` ao soltar.
- Alfa das texturas: pré-multiplicado na GPU (blend `ONE, ONE_MINUS_SRC_ALPHA`).

### 3.1b Convenções da importação (2B)
- `ImportedDocument.layers` e `ImportedLayer.children` ficam **de trás para frente** (índice 0 = fundo), igual à ordem de desenho de `parts`.
- Camada de imagem guarda **um PNG/JPEG completo** em `png` (PSD é re-codificado para PNG RGBA com alfa **direto**, não pré-multiplicado); `left/top` em px a partir do canto superior esquerdo do documento (Y para baixo).
- `LayerImport`: malha-quadro 1×1 centrada na origem local, `transform` = centro da camada no mundo (`x = left + w/2 − docW/2`, `y = docH/2 − (top + h/2)`), grupo = `GROUP` com transform identidade; lista em pré-ordem (pai antes dos filhos).
- Limites (`ImportLimits`): documento ≤ 8192 px/lado (igual a `ProjectRepository.create`), camada ≤ 16384 px/lado e ≤ 40 Mpx, ≤ 2000 camadas, ORA: ≤ 4096 entradas, 128 MB/entrada, 512 MB total, XML ≤ 8 MB. Camada que estoura limite é **ignorada com aviso**; documento que estoura é **erro**.
- Erros de importação sempre `ImportException` com mensagem em português pronta para a UI; arquivo corrompido nunca deve lançar outra exceção. Perdas (máscaras, modos de mesclagem, 16→8 bits, camadas vazias, imagem ausente no ORA) vão para `ImportedDocument.warnings` — **a UI da 2C deve mostrar esses avisos**.
- Formatos: PSD v1 RGB/cinza 8 e 16 bits (compressões 0/1/2/3, grupos, `luni`, opacidade, visibilidade); ORA (DOCTYPE/entidades recusados, caminhos normalizados); PNG/JPEG simples. **Não suportado (erro claro):** PSB, CMYK, Lab, indexado, bitmap, 32 bits, PSD sem camadas.

### 3.2 Formato `.v2d` — esquema 2
ZIP contendo, **nesta ordem**: `project.json` (primeiro) e `textures/<assetId>.png|jpg` (armazenadas sem recompressão).
`project.json`: `schemaVersion` (=2), `meta{id,name,createdAt,modifiedAt,width,height,fps}`, `parts[]` (`id,name,parentId,visible,locked,kind,opacity,textureId,transform{x,y,rotationDeg,scaleX,scaleY},mesh{positions,uvs,indices}|null`), `assets[]` (`id,name,width,height,format,file`).
- Esquema 1 abre normalmente (campos novos com padrão). Esquema maior que o suportado → erro claro.
- Salvamento atômico: tmp → relê e confere (partes + tamanho das texturas) → `.bak` da versão anterior → troca.
- Textura ausente no ZIP **não impede abrir** o projeto (`ImageAsset.isMissing`; o renderer deve mostrar marcador).
- Próximas mudanças de esquema: incrementar `CURRENT_SCHEMA` e migrar em `ProjectSerializer.migrate`.

---

## 4. DIREÇÃO DA UI — "mais perto do Live2D Cubism" (análise das 2 referências do usuário)

O usuário **abriu o APK da Fase 1 e não gostou da UI** (cartões/menus genéricos de app Material). Quer o **mesmo visual/organização do Cubism Editor** para quem já sabe usar. Referências recebidas (vídeo `1000242980.mp4`, 2 imagens):

1. **Cubism Editor 5 (modo Modelagem):** tema **escuro cinza-grafite**, texto pequeno e denso. Coluna esquerda com abas **Peças/Projeto**: árvore de partes com colunas fixas de **olho (visível) e cadeado (bloqueio)** em cores (laranja/amarelo), indentação por nível, ícones por tipo; abaixo, painel **Deformadores** em árvore. Coluna do meio: **Detalhes da ferramenta**, **Inspetor** (Nome, ID, Parte, Grupo, Opacidade, Ordem de desenho…) e **Parâmetros** (sliders com ponto vermelho/rosa, controle 2D "Ângulo X/Y" em grade, grupos de parâmetros destacados em vermelho quando selecionados). Direita: **canvas grande** com fundo xadrez transparente, **barra de ferramentas de ícones** no topo, abas de documento acima do canvas.
2. **Cubism Controller / timeline (print do After Effects):** painel esquerdo de **parâmetros com sliders por grupo** (cabelo, corpo…), viewer central, **timeline embaixo** com camadas e réguas de tempo.

**Tradução para celular (implementada em código na Parte 2D; refinamentos continuam nas fases seguintes):**
- **Paisagem como padrão:** `MainActivity` usa `sensorLandscape`. Canvas ocupa a área central; painéis recolhíveis por comandos na toolbar (esquerda: abas *Peças/Projeto* com *Deformadores* abaixo; direita: *Detalhes da ferramenta*, *Inspetor* e *Parâmetros*). Nesta entrega a largura dos painéis é fixa; alça para redimensionar e modo flutuante ficam para refinamento.
- **Barra de ferramentas superior compacta** com seleção, pan, seleção retangular, multi-seleção, wireframe, alternância dos painéis, desfazer/refazer, ajustar, importar e salvar. As ações implementadas têm real ligação com o editor; ferramentas futuras não são apresentadas como ativas.
- **Abas de modo** Modelagem · Animação · Física no topo. Modelagem está ativa; Animação e Física são identificadas como futuras (F6/F5) e desabilitadas. A timeline inferior real entra na Fase 6.
- **Paleta:** fundo `#2B2B2B`–`#383838`, painéis `#323232`, divisores `#1E1E1E`, texto `#D0D0D0` 11–12sp, acento **laranja** `#E8A33D` (olho/seleção de lista), **vermelho/rosa** `#C94A5A` (parâmetro selecionado/ponto de slider), canvas xadrez cinza.
- Alvos de toque da toolbar e da árvore ficam em torno de 38–40dp; linhas de lista 36–40dp. Controles numéricos +/- do Inspetor são compactos (28dp) e precisam ser avaliados no aparelho.
- **Não copiar** logotipo, ícones literais nem identidade do Live2D: usar ícones próprios (Material Icons + desenhados).
- Guardar as imagens de referência junto do projeto (`docs/ui-referencias/`) para as próximas conversas.

**Estado 2D (v0.2.0-D):** a tela inicial usa tema grafite e lista de projetos compacta. O editor tem árvore invertida por ordem visual, expandir/recolher grupos, alternar visibilidade/bloqueio, agrupar/desagrupar, trazer à frente/enviar ao fundo, renomear e editar posição X/Y, rotação, escala X/Y e opacidade no Inspetor. As edições usam `EditSession` (incluindo undo/redo) e alimentam o renderer. O painel de parâmetros e a aba Deformadores mostram explicitamente que dependem da Fase 4; Animação/Física estão desabilitadas. A timeline real, redimensionamento por alça, menus contextuais e reparentação por arrasto ainda não foram implementados.

---

## 5. ARQUITETURA DE EDIÇÃO (como a UI deve ligar no motor)

```
UI (Compose)  ──gestos/botões──►  EditSession.apply(label, mergeKey){ PartTree.xxx(...) }
     ▲                                   │ state: EditState(parts, assets)
     │ recompõe                          ▼
EditorViewModel ◄── state ──── RenderScene (PartTree.renderList → Resolved(world, visible, opacity))
                                         │
                                         ▼
                                  MeshRenderer (GL thread): textura real por assetId + matriz `world` por parte
```
- O motor (`geometry/project/history/mesh`) **não depende de Android** (testável na JVM). Android só em `rendering` e `ui`.
- Salvar: `ProjectRepository.save(V2dProject(meta, state.parts, state.assets))` em IO; autosave a cada 20 s se mudou.

---

## 6. ROTEIRO POR PARTES

Legenda: ✅ feito (código escrito; confirmação de compilação pendente do Actions) · ⏭ próxima · ☐ planejado

### FASE 1 — Fundação ✅ (v0.1.0, aberta no aparelho pelo usuário)

### FASE 2 — Importação, hierarquia, canvas, seleção, nova UI
- ✅ **2A — Motor de dados:** esquema v2, `Affine/Transform2D`, `PartTree`, `History/EditSession`, texturas no `.v2d`, testes.
- ✅ **2B — Importadores (puro Kotlin, testável):** PSD/ORA/PNG/JPEG → partes + texturas; `createFromImport`; 46 testes de JVM passaram na entrega B.
- ✅ **2C — Renderer e interação (código entregue; Actions/aparelho pendentes):** textura real por parte com cache/descarte GL e fallback visível; matriz `world`, visibilidade/opacidade herdadas, canvas xadrez; `HitTest` de ponto por triângulo e seleção retangular; seleção única/múltipla, arrasto com 1 dedo, pan/zoom com 2 dedos, desfazer/refazer; importação SAF para PSD/ORA/PNG/JPEG, criar projeto ou adicionar camadas.
- ✅ **2D — Workspace inspirado nas referências:** tema grafite; tela inicial refeita; paisagem; toolbar compacta; painéis recolhíveis Peças/Projeto + Deformadores e Detalhes da ferramenta/Inspetor/Parâmetros; árvore com expansão de grupos, visibilidade/bloqueio, agrupar/desagrupar, ordem frente/fundo; Inspetor para nome, visibilidade, bloqueio, posição X/Y, rotação, escala X/Y e opacidade; comandos conectados ao histórico. Animação/Física/Deformadores/Parâmetros avançados estão explicitamente desabilitados até suas fases. **Build Android/Actions e teste no aparelho pendentes.**
- Critério de conclusão da Fase 2: abrir uma ilustração em camadas, manipular partes e **reabrir o projeto sem perder dados**.
- ⏭ **Próxima parte: Fase 3 — Mesh Editor:** edição real de vértices/arestas, criação/ajuste de malha e deformação por buffer.

### FASES 3–8 (resumo; detalhar quando chegar a vez)
- **3 Mesh Editor:** malha automática (contorno por alfa + densidade), edição manual de vértices/arestas, deformação real por buffer.
- **4 Rigging:** Warp Deformer, Rotation Deformer, hierarquia de deformadores, parâmetros, keyforms, interpolação (linear/suave).
- **5 Física:** pêndulo/mola, grupos entrada→saída, preview.
- **6 Animação:** timeline, dope sheet, graph editor (Bézier), áudio, lip-sync por amplitude.
- **7 Exportação:** MP4, GIF, PNG/sequência, `.v2d`, modelo reutilizável (sem `.moc3`).
- **8 Otimização:** draw calls, memória, projetos pesados, testes no POCO X7 Pro.

---

## 7. PARTE 2D — IMPLEMENTAÇÃO ENTREGUE (verificação pendente)

A 2D substitui a UI provisória por uma área de trabalho compacta inspirada nas duas referências visuais enviadas. A compilação Gradle/Android e a validação em aparelho ainda dependem do GitHub Actions e do teste manual.

1. **Layout:** tela inicial redesenhada em grafite; editor em `sensorLandscape`; barra superior compacta; faixa de modos; canvas central; painel Peças/Projeto com Deformadores abaixo à esquerda e Detalhes da ferramenta/Inspetor/Parâmetros à direita. Os painéis podem ser ocultados pela toolbar. A largura é fixa nesta entrega.
2. **Árvore de peças:** hierarquia em pré-ordem com irmãs apresentadas em ordem visual invertida (frente no topo); grupos expandíveis/recolhíveis; indicadores de tipo; controles de visibilidade e bloqueio; seleção sincronizada com canvas.
3. **Operações reais:** agrupar/desagrupar, reordenar frente/fundo, excluir (incluindo descendentes), alternar visibilidade/bloqueio e renomear. Reordenação usa botões explícitos; arrastar para reordenar/reparentar e menu contextual ficam para refinamento.
4. **Inspetor:** nome, visibilidade, bloqueio, posição X/Y, rotação, escala X/Y e opacidade. As alterações passam por `EditSession` e são exibidas no renderer; desfazer/refazer preservados.
5. **Módulos futuros:** abas Animação/Física aparecem desabilitadas (F6/F5); Deformadores e Parâmetros avançados são apresentados como indisponíveis até F4. Não foi criada timeline falsa: timeline real será implementada na Fase 6.
6. **Referências:** imagens desta entrega salvas em `docs/ui-referencias/ref3-modelagem-usuario.jpg` e `ref4-controller-timeline-usuario.jpg`; as referências anteriores também foram preservadas.
7. **Verificação:** foi feita leitura estática e verificação de sintaxe Kotlin sem erros sintáticos reportados pelo parser local, mas esse parser foi executado sem classpath Android/Compose. **Não é uma compilação**. Não houve Gradle/AGP/Compose build, testes unitários via Actions, instalação ou teste visual no POCO X7 Pro.

**Fora do escopo da 2D:** Mesh Editor (F3), deformadores/parâmetros avançados (F4), física (F5), animação/timeline/áudio (F6), exportação (F7) e redimensionamento de painéis/menus contextuais/reparentação por arrasto (refinamentos de UI futuros).

---

## 8. LIMITAÇÕES CONHECIDAS E RISCOS

- **Verificação parcial:** o motor Kotlin puro (`geometry`, `mesh`, `imports`, `PartTree`) e seus testes foram compilados e executados na JVM com o kotlinc embutido no Gradle (2.0.21; o projeto usa 1.9.25 — diferenças pequenas possíveis). **Não verificados localmente:** `ProjectRepository`/`ProjectSerializer` (precisam de `org.json`; só foi feita checagem de tipos com stub), `rendering`, `ui`, Gradle/AGP. O **primeiro resultado do Actions continua sendo a verificação real**.
- PSD: testado só com arquivos sintéticos gerados no teste (não com PSDs reais do Photoshop/Krita/Clip Studio); se algum PSD real falhar, enviar o arquivo/mensagem de erro. Máscaras de camada e modos de mesclagem são ignorados (com aviso).
- Fase 1 só confirmada pelo usuário como "abriu". Canvas/GPU não validado em detalhe no POCO X7 Pro.
- UI 2D foi escrita, mas ainda não passou pelo Gradle/Actions nem foi vista no aparelho. Os painéis têm largura fixa; reparentação por arrasto, menu contextual, timeline, deformadores e parâmetros avançados ainda não existem.
- Renderer 2C escrito, mas ainda não validado no Actions/aparelho; ver seção 7. Decodificação inicial de texturas ainda ocorre na thread GL.
- Histórico de versões do projeto e recuperação de crash dedicada: parciais (só `.bak`); revisar na Fase 8.
- Release sem assinatura (não inventar chaves; o usuário configura).
- Android 16: importação já usa SAF/`ActivityResultContracts.OpenDocument`, sem permissão ampla; validar o fluxo com arquivos reais no aparelho.

---

## 9. REGISTRO DE ATUALIZAÇÕES (mais recente primeiro) — *a IA acrescenta uma entrada a cada entrega*

### 0.2.0-D — Fase 2, Parte D — 18/11/2026
- **Direção visual:** tema grafite, painéis `#323232`, fundo `#252525`, acento laranja `#E8A33D`, texto compacto; capturas de referência enviadas pelo usuário guardadas em `docs/ui-referencias/`.
- **Tela inicial:** lista de projetos redesenhada com cabeçalho técnico, linhas compactas, metadados e criação de projeto em destaque.
- **Editor:** layout horizontal `sensorLandscape`; toolbar com seleção, pan, retângulo, multi-seleção, wireframe, show/hide dos docks, undo/redo, fit, importação e salvar.
- **Dock esquerdo:** abas Peças/Projeto; árvore de peças com hierarquia, expansão/recolhimento de grupos, ordem visual invertida, controles de visibilidade/bloqueio, agrupar/desagrupar, mover frente/fundo e excluir; seção Deformadores identificada como Fase 4.
- **Dock direito:** Detalhes da ferramenta e Inspetor funcional para renomear, visibilidade, bloqueio, posição X/Y, rotação, escala X/Y, opacidade e ordem de desenho. Alterações usam `EditSession` e alimentam o renderer.
- **Módulos não implementados:** Deformadores e parâmetros avançados identificados como Fase 4; abas Animação/Física desabilitadas (F6/F5). Timeline real não simulada; entra na Fase 6.
- **Limitações desta entrega:** painéis com largura fixa; sem alças de resize, menu contextual, drag-reorder ou drag-reparent; seleção da árvore e canvas já sincronizada.
- **Verificação:** sem Gradle/Android SDK/Compose classpath neste ambiente. Parser Kotlin local não reportou erros sintáticos, mas isso não comprova compilação. Actions e teste no POCO X7 Pro pendentes.

### 0.2.0-C — Fase 2, Parte C — 18/11/2026
- **Renderer:** substituída a textura de teste por texturas PNG/JPEG do projeto; cache por `assetId`, descarte de assets não usados, marcador xadrez magenta para ausência/erro/tamanho GL excedido, fundo xadrez de transparência e recuperação após novo contexto.
- **Transformações:** renderer usa matriz mundial de `PartTree` e opacidade/visibilidade herdadas; contorno laranja para peça selecionada.
- **Seleção:** novo pacote `selection/HitTest` (triângulos, ordem frente/trás, bloqueio/visibilidade, retângulo por AABB transformado) + cinco testes JUnit.
- **Editor:** `EditSession` passou a controlar mudanças da UI; selecionar/arrastar, multi-seleção, seleção retangular, Pan, pinça, undo/redo; exclusão de grupo remove descendentes.
- **Importação:** seletor SAF PSD/ORA/PNG/JPEG; bytes limitados a 512 MB e analisados fora da main thread; permite criar projeto novo ou inserir partes/texturas no atual com um comando de desfazer.
- **Verificação local:** fontes Kotlin puras de geometria/seleção compiladas com `kotlinc`; cinco métodos do `HitTestTest` executados com runner local compatível e smoke test com 7 verificações OK. Isso não substitui Gradle/JUnit; Compose, renderer e aparelho não verificados.

### 0.2.0-B — Fase 2, Parte B — 18/11/2026
- Contexto: a conversa anterior estourou o limite; esta entrega retoma do zip `mobile2dstudio-fase2a.zip` e faz a próxima parte do roteiro (2B), sem tocar na UI.
- **Adicionado (pacote `imports`):** `ImageInfoReader` (dimensões PNG/JPEG), `PngEncoder`, `OraImporter` (anti-XXE, anti path traversal, limites anti zip-bomb), `PsdImporter` (parser próprio: RGB/cinza, 8/16 bits, raw/RLE/ZIP/ZIP+predição, grupos aninhados, nomes Unicode, opacidade, visibilidade, bloco `Lr16`), `LayerImport`, `DocumentImporter` (detecção por conteúdo), `ProjectRepository.createFromImport`.
- **Testes novos:** `ImageCodecTest`, `PsdImporterTest` (gerador de PSD sintético), `OraImporterTest`, `ProjectImportTest`. Rodados localmente na JVM: 46 testes OK (todos exceto `ProjectImportTest`, que precisa de `org.json`).
- **Bug achado e corrigido pelos testes:** ORA truncado lançava `EOFException` em vez de `ImportException`.
- **Mudança visível no app:** nenhuma. Versão do app: `0.2.0-B`.
- **Não verificado:** build Gradle/Actions, `ProjectImportTest`, PSD reais, aparelho.

### 0.2.0-A — Fase 2, Parte A — 18/11/2026
- Contexto: a conversa anterior (Fase 2 + UI estilo Cubism) estourou o limite antes de entregar; esta entrega retoma do zip `mobile2dstudio-fase1.zip` + referências de UI do vídeo.
- **Adicionado:** `.v2d` esquema 2 (partes com `kind/opacity/transform/textureId`, lista de texturas no ZIP, migração do esquema 1); `Affine`/`Transform2D`; `PartTree` (hierarquia completa e pura); `History/EditSession` (desfazer/refazer por comandos com fusão de arrasto); gravação/leitura/verificação de texturas no repositório; `build.yml` aceitando projeto na raiz ou `.zip` único.
- **Testes novos:** `AffineTest`, `PartTreeTest`, `EditSessionTest`, `ProjectV2FormatTest` (+ os 4 arquivos de teste existentes continuam).
- **Mudança visível no app:** nenhuma (motor apenas). Versão do app: `0.2.0-A`.
- **Não verificado:** compilação e execução dos testes (aguardando Actions); comportamento em aparelho.

### 0.1.0 — Fase 1 (outra IA)
- Projeto Android, renderer GLES 3.0 com malhas/wireframe/pan/zoom, `.v2d` esquema 1 (atômico + `.bak`), gerenciador de projetos, autosave, editor simples, testes (câmera, malha, serialização, repositório), Actions com APK debug.

---

## 10. CHECKLIST DE CADA ENTREGA (a IA confere antes de enviar)

- [ ] Parte pequena e coerente (uma única parte do roteiro).
- [ ] Código novo respeita as convenções da seção 3.1; nada existente removido sem justificativa.
- [ ] Testes unitários novos para a lógica nova; `build.yml` ainda roda `testDebugUnitTest` + `assembleDebug`.
- [ ] Esquema do `.v2d` migrado se mudou.
- [ ] `CHANGELOG.md` e **este `.md` atualizados** (versão no topo, seções 3, 6, 7, 9).
- [ ] Zip do projeto completo (com `.github/workflows/build.yml`) + este `.md` entregues juntos.
- [ ] Resposta ao usuário diz claramente: o que foi feito, o que **não** foi verificado, e qual é a próxima parte.

---

## 11. PROMPT DE CONTINUAÇÃO (copiar e colar em qualquer IA)

> Você vai continuar o desenvolvimento do **Mobile 2D Studio**. Anexei: `PROJETO_CONTEXTO.md` (leia inteiro primeiro), `master_prompt_mobile_2d_studio.md`, o zip do projeto atual e as imagens de referência da UI. Siga as regras da seção 0. Faça **apenas a próxima parte do roteiro (seção 6/7)**, sem tentar fazer tudo de uma vez. Entregue: zip atualizado com `build.yml`, **o `PROJETO_CONTEXTO.md` atualizado**, e um resumo curto em português dizendo o que foi feito, o que não foi verificado e qual é a próxima parte. Se o log de um build do GitHub Actions falhado for enviado, corrija os erros antes de qualquer funcionalidade nova.
