# Changelog

## 0.2.0-D — Fase 2, Parte D (nova interface de modelagem)
- Tela inicial reformulada com tema grafite, lista de projetos compacta e botão de criação destacado.
- Editor em paisagem (`sensorLandscape`) com barra de comandos compacta: seleção, pan, seleção retangular, multi-seleção, wireframe, painéis recolhíveis, undo/redo, ajustar, importar e salvar.
- Dock esquerdo com abas Peças/Projeto e seção Deformadores abaixo; árvore hierárquica expandível/recolhível, ordem visual (frente no topo), visibilidade, bloqueio, agrupar/desagrupar, ordem frente/fundo e exclusão.
- Dock direito com Detalhes da ferramenta, Inspetor funcional e seção Parâmetros futura: renomear, visibilidade, bloqueio, posição X/Y, rotação, escala X/Y, opacidade e ordem de desenho. As mudanças passam pelo `EditSession` e atualizam o renderer.
- Parâmetros avançados e Deformadores aparecem identificados como Fase 4; abas Animação/Física ficam desabilitadas para F6/F5. Nenhuma timeline fictícia foi criada; a timeline real será feita na Fase 6.
- Referências visuais do usuário adicionadas a `docs/ui-referencias/`.
- Não verificado: build Gradle/Android, testes no GitHub Actions e execução no POCO X7 Pro. O parser Kotlin local não apontou erros sintáticos, mas foi executado sem classpath Android/Compose e não substitui compilação.
- Limitações: docks com largura fixa; resize por alça, menu contextual, reordenação/reparentação por arrasto ainda pendentes.

## 0.2.0-C — Fase 2, Parte C (renderer e interação)
- Renderer: texturas PNG/JPEG reais por `assetId`, cache GL com descarte de assets não usados e recriação após perda do contexto; textura ausente/corrompida ou grande demais ganha marcador xadrez magenta em vez de crash.
- Renderização: matriz mundial hierárquica por parte, visibilidade/opacidade herdadas, alfa pré-multiplicado, canvas xadrez de transparência e contorno laranja da seleção.
- Seleção pura Kotlin: hit test por triângulos na ordem visual (frente primeiro), ignorando partes invisíveis/bloqueadas; seleção por retângulo via limites transformados.
- Interação: selecionar/arrastar peças com um dedo, pan alternável, pinça com dois dedos, seleção múltipla e por retângulo; desfazer/refazer ligados ao `EditSession` (um arrasto = um comando).
- Importação Android (SAF): seletor de arquivos para PSD/ORA/PNG/JPEG, leitura limitada a 512 MB, processamento fora da thread principal, resumo/avisos e ações para criar projeto novo ou adicionar as camadas ao projeto atual em um único passo de desfazer.
- Testes novos: `HitTestTest` (5 métodos). Fontes Kotlin puras compiladas com `kotlinc`; os 5 métodos foram executados com runner JVM local compatível (não substitui o Gradle/JUnit do projeto), e smoke test separado de 7 verificações passou. O conjunto Gradle/Actions ainda precisa ser executado.
- Não verificado: compilação Android/Compose, renderer no POCO X7 Pro, PSDs/ORAs reais e desempenho de primeira decodificação de texturas.

## 0.2.0-B — Fase 2, Parte B (importadores)  [sem mudança visível na UI]
- Novo pacote `imports` (Kotlin puro): PSD (parser próprio, RGB/cinza 8/16 bits, compressões raw/RLE/ZIP/ZIP+predição, grupos aninhados, nomes Unicode, opacidade, visibilidade), ORA (OpenRaster, seguro contra XXE/path traversal/zip-bomb), PNG e JPEG simples.
- `PngEncoder` e leitura de dimensões PNG/JPEG sem decodificar pixels.
- `LayerImport`: documento importado → partes (grupos e malhas 1x1 posicionadas no mundo) + texturas; `ProjectRepository.createFromImport` cria projeto com o tamanho do documento.
- Erros claros (PSB, CMYK, Lab, 32 bits, PSD sem camadas, arquivo truncado/corrompido); perdas viram avisos (máscaras, mesclagem, 16→8 bits, camadas vazias).
- Testes: codec, PSD sintético (todas as compressões, grupos, 16 bits, cinza, erros, corrupção), ORA, projeto importado.
- Verificado na JVM local (46 testes OK); Gradle/Actions e aparelho ainda não.

## 0.2.0-A — Fase 2, Parte A (motor de dados e hierarquia)  [sem mudança visível na UI]
- `.v2d` esquema 2: partes com `kind` (GROUP/MESH), `opacity`, `transform` (T/R/S local) e `textureId`;
  projeto com lista de texturas (`textures/<id>.png|jpg` dentro do ZIP). Projetos do esquema 1 abrem normalmente.
- `Affine` + `Transform2D` (composição, inversa, decomposição, matriz 4x4 para GL).
- `PartTree`: hierarquia pura (ordem canônica, resolver mundo/visibilidade/bloqueio/opacidade herdados,
  adicionar, remover, renomear, mover com preservação da posição visual, reordenar, agrupar, desagrupar,
  deslocar no mundo). Dados inconsistentes (pai inexistente, ciclos) são normalizados, não derrubam o projeto.
- `History`/`EditSession`: desfazer/refazer por comandos com fusão de arrasto (um gesto = um desfazer), limite 200.
- Repositório: texturas gravadas no `.v2d`, verificação de integridade das texturas, textura ausente não destrói o projeto.
- `build.yml`: aceita projeto na raiz OU um `.zip` do projeto dentro do repositório.
- Testes novos: Affine, PartTree, EditSession, formato v2 (migração v1, texturas, recurso ausente).
- NÃO testado em compilador/aparelho: o primeiro resultado do Actions é a verificação real.

## 0.1.0 — Fase 1 (fundação)
- Projeto Android (Kotlin, Compose, Material 3), minSdk 26, compile/target 35.
- Renderer OpenGL ES 3.0: malhas com VAO/VBO, textura de teste, wireframe, contorno do canvas,
  recriação de recursos após perda de contexto, atualização de posições sem recriar buffers.
- Câmera 2D (pan, zoom em ponto de foco, ajustar) com conversão mundo<->tela testada.
- ArtMesh + gerador de malha em grade + validação (índices, degenerados, UVs).
- Formato `.v2d` (ZIP + project.json, esquema versionado), gravação atômica, backup `.bak`,
  recuperação do backup, listagem ignorando arquivos corrompidos.
- Gerenciador de projetos: criar, abrir, renomear, duplicar, excluir, salvar, autosave (20 s) e
  salvamento ao sair do app; FPS e resolução configuráveis.
- Editor: canvas GPU, painel de camadas simples (visibilidade, excluir), "+ Parte de teste".
- Testes unitários: câmera, malha, serialização, repositório.
- GitHub Actions: testes + APK Debug como artifact.
