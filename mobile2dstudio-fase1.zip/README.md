# Mobile 2D Studio

Editor de personagens 2D e animação para Android (inspirado no fluxo de trabalho de editores
profissionais de rigging). Implementação independente, sem código ou recursos de terceiros proprietários.

## Como gerar o APK (sem PC)
1. Suba todo o conteúdo desta pasta para um repositório do GitHub (inclusive a pasta oculta `.github`).
2. GitHub → **Actions** → **Build Android APK** → **Run workflow**.
3. Ao terminar, baixe o artifact **mobile2dstudio-debug-apk** e instale o `.apk`.
4. O artifact **gradle-wrapper-files** contém `gradlew` e `gradle/wrapper/`: commite-os para que as
   próximas execuções não precisem gerar o wrapper (o workflow gera sozinho se faltarem).

## Estado da Fase 1
| Item | Estado |
|---|---|
| Arquitetura em pacotes (geometry, mesh, project, rendering, ui) | Implementado |
| Canvas GPU (OpenGL ES 3.0), malhas, wireframe, pan/zoom | Implementado, **não testado em aparelho** |
| Projetos `.v2d` (criar/abrir/duplicar/renomear/excluir/salvar/backup) | Implementado, com testes unitários |
| Autosave | Implementado (a cada 20 s se houver alterações + ao sair do app) |
| Histórico de versões, recuperação de crash dedicada | Parcial (só `.bak` da versão anterior) |
| Importação PSD/ORA/PNG, hierarquia, seleção, mover partes | Planejado (Fase 2) |
| Edição de malha, deformação, rigging, física, animação, exportação | Planejado (Fases 3–7) |

## Limitações conhecidas
- A textura é gerada por código (xadrez "TOPO"): ainda não há importação de imagens.
- O editor de camadas é plano (sem hierarquia); a parte de teste existe só para exercitar o pipeline GPU.
- Um dedo arrasta o canvas temporariamente; na Fase 2 passa a selecionar/mover partes.
- Build Release não está assinado (sem chaves inventadas).
- O código foi escrito sem acesso a compilador/Android SDK: o primeiro resultado do Actions é a verificação real.
