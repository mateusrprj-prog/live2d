package com.mobile2dstudio.rendering

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.opengl.GLES20
import android.opengl.GLES30
import android.opengl.GLSurfaceView
import android.opengl.GLUtils
import com.mobile2dstudio.geometry.CanvasCamera
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

/**
 * Renderer OpenGL ES 3.0 do canvas. Todos os métodos públicos (exceto os da interface
 * GLSurfaceView.Renderer, que o próprio GL chama) devem ser invocados na thread do GL,
 * via [GLCanvasView.update].
 */
class MeshRenderer : GLSurfaceView.Renderer {
    val camera = CanvasCamera()

    private var scene = RenderScene(emptyList(), 1080f, 1920f, true)
    private var fitPending = true
    private var surfaceReady = false

    private var textured: ShaderProgram? = null
    private var solid: ShaderProgram? = null
    private var texMvp = 0
    private var texSampler = 0
    private var texAlpha = 0
    private var solidMvp = 0
    private var solidColor = 0

    private val meshes = HashMap<String, GpuMesh>()
    private val textures = HashMap<String, Int>()

    private var frameVao = 0
    private var frameVbo = 0
    private var frameW = 0f
    private var frameH = 0f

    private val mvp = FloatArray(16)

    fun setScene(newScene: RenderScene) {
        if (newScene.canvasWidth != scene.canvasWidth || newScene.canvasHeight != scene.canvasHeight) {
            fitPending = true
        }
        scene = newScene
    }

    fun requestFit() {
        fitPending = true
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        // Contexto novo: todos os nomes de objetos GL anteriores são inválidos.
        meshes.clear()
        textures.clear()
        frameVao = 0
        frameVbo = 0
        frameW = 0f
        frameH = 0f

        val t = ShaderProgram(Shaders.TEXTURED_VERTEX, Shaders.TEXTURED_FRAGMENT)
        texMvp = t.uniform("uMvp")
        texSampler = t.uniform("uTex")
        texAlpha = t.uniform("uAlpha")
        textured = t

        val s = ShaderProgram(Shaders.SOLID_VERTEX, Shaders.SOLID_FRAGMENT)
        solidMvp = s.uniform("uMvp")
        solidColor = s.uniform("uColor")
        solid = s

        GLES20.glClearColor(0.09f, 0.09f, 0.11f, 1f)
        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_ONE, GLES20.GL_ONE_MINUS_SRC_ALPHA)
        GLES20.glDisable(GLES20.GL_DEPTH_TEST)
        GLES20.glDisable(GLES20.GL_CULL_FACE)
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        GLES20.glViewport(0, 0, width, height)
        camera.setViewport(width, height)
        surfaceReady = width > 0 && height > 0
        fitPending = true
    }

    override fun onDrawFrame(gl: GL10?) {
        val texProgram = textured ?: return
        val solidProgram = solid ?: return

        if (fitPending && surfaceReady) {
            camera.fit(scene.canvasWidth, scene.canvasHeight, 0.9f)
            fitPending = false
        }

        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        camera.projectionMatrix(mvp)

        syncMeshes()
        ensureFrame()

        // Fundo da área de trabalho + contorno.
        solidProgram.use()
        GLES20.glUniformMatrix4fv(solidMvp, 1, false, mvp, 0)
        GLES20.glUniform4f(solidColor, 0.17f, 0.17f, 0.20f, 1f)
        GLES30.glBindVertexArray(frameVao)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_FAN, 0, 4)

        // Partes com textura.
        texProgram.use()
        GLES20.glUniformMatrix4fv(texMvp, 1, false, mvp, 0)
        GLES20.glUniform1i(texSampler, 0)
        GLES20.glUniform1f(texAlpha, 1f)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        for (part in scene.parts) {
            if (!part.visible) continue
            val gpu = meshes[part.id] ?: continue
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, textureFor(part.id))
            GLES30.glBindVertexArray(gpu.vaoTriangles)
            GLES20.glDrawElements(GLES20.GL_TRIANGLES, gpu.triangleIndexCount, GLES20.GL_UNSIGNED_INT, 0)
        }

        // Topologia (arestas).
        solidProgram.use()
        if (scene.showWireframe) {
            GLES20.glUniform4f(solidColor, 1f, 1f, 1f, 0.55f)
            for (part in scene.parts) {
                if (!part.visible) continue
                val gpu = meshes[part.id] ?: continue
                GLES30.glBindVertexArray(gpu.vaoEdges)
                GLES20.glDrawElements(GLES20.GL_LINES, gpu.edgeIndexCount, GLES20.GL_UNSIGNED_INT, 0)
            }
        }

        // Contorno do canvas.
        GLES20.glUniform4f(solidColor, 0.95f, 0.75f, 0.2f, 1f)
        GLES30.glBindVertexArray(frameVao)
        GLES20.glDrawArrays(GLES20.GL_LINE_LOOP, 0, 4)

        GLES30.glBindVertexArray(0)
    }

    private fun syncMeshes() {
        val current = scene.parts
        val keep = HashSet<String>()
        for (part in current) {
            keep.add(part.id)
            val existing = meshes[part.id]
            if (existing == null) {
                meshes[part.id] = GpuMesh.create(part.mesh)
            } else if (existing.source !== part.mesh) {
                if (existing.canUpdateFrom(part.mesh)) {
                    existing.updatePositions(part.mesh)
                } else {
                    existing.release()
                    meshes[part.id] = GpuMesh.create(part.mesh)
                }
            }
        }
        val it = meshes.entries.iterator()
        while (it.hasNext()) {
            val entry = it.next()
            if (entry.key !in keep) {
                entry.value.release()
                it.remove()
                textures.remove(entry.key)?.let { tex ->
                    GLES20.glDeleteTextures(1, intArrayOf(tex), 0)
                }
            }
        }
    }

    private fun ensureFrame() {
        if (frameVao != 0 && frameW == scene.canvasWidth && frameH == scene.canvasHeight) return
        if (frameVao != 0) {
            GLES30.glDeleteVertexArrays(1, intArrayOf(frameVao), 0)
            GLES20.glDeleteBuffers(1, intArrayOf(frameVbo), 0)
        }
        val vaos = IntArray(1)
        val vbos = IntArray(1)
        GLES30.glGenVertexArrays(1, vaos, 0)
        GLES20.glGenBuffers(1, vbos, 0)
        val hw = scene.canvasWidth / 2f
        val hh = scene.canvasHeight / 2f
        val buf = directFloatBuffer(8)
        buf.put(floatArrayOf(-hw, -hh, hw, -hh, hw, hh, -hw, hh))
        buf.position(0)
        GLES30.glBindVertexArray(vaos[0])
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vbos[0])
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, 8 * 4, buf, GLES20.GL_STATIC_DRAW)
        GLES20.glEnableVertexAttribArray(0)
        GLES20.glVertexAttribPointer(0, 2, GLES20.GL_FLOAT, false, 0, 0)
        GLES30.glBindVertexArray(0)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
        frameVao = vaos[0]
        frameVbo = vbos[0]
        frameW = scene.canvasWidth
        frameH = scene.canvasHeight
    }

    /** Textura de teste gerada por parte (a importação de imagens entra na Fase 2). */
    private fun textureFor(partId: String): Int {
        textures[partId]?.let { return it }
        val hue = ((partId.hashCode() and 0x7fffffff) % 360).toFloat()
        val bitmap = createTestBitmap(hue)
        val ids = IntArray(1)
        GLES20.glGenTextures(1, ids, 0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, ids[0])
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bitmap, 0)
        bitmap.recycle()
        textures[partId] = ids[0]
        return ids[0]
    }

    /** Xadrez colorido, cantos arredondados transparentes e a palavra TOPO (confere orientação/UV/alfa). */
    private fun createTestBitmap(hue: Float): Bitmap {
        val size = 512
        val cells = 8
        val cell = size / cells
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val clip = Path()
        clip.addRoundRect(RectF(0f, 0f, size.toFloat(), size.toFloat()), 72f, 72f, Path.Direction.CW)
        canvas.clipPath(clip)
        val light = Color.HSVToColor(floatArrayOf(hue, 0.50f, 0.95f))
        val dark = Color.HSVToColor(floatArrayOf(hue, 0.60f, 0.62f))
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        for (j in 0 until cells) {
            for (i in 0 until cells) {
                paint.color = if ((i + j) % 2 == 0) light else dark
                canvas.drawRect(
                    (i * cell).toFloat(), (j * cell).toFloat(),
                    ((i + 1) * cell).toFloat(), ((j + 1) * cell).toFloat(), paint
                )
            }
        }
        paint.color = Color.WHITE
        paint.textSize = 64f
        paint.textAlign = Paint.Align.CENTER
        paint.isFakeBoldText = true
        canvas.drawText("TOPO", size / 2f, 120f, paint)
        return bmp
    }
}
