package com.mobile2dstudio.rendering

import com.mobile2dstudio.mesh.ArtMesh

/** Parte a ser desenhada. A ordem da lista é a ordem de desenho (primeiro = fundo). */
class RenderPart(val id: String, val mesh: ArtMesh, val visible: Boolean)

class RenderScene(
    val parts: List<RenderPart>,
    val canvasWidth: Float,
    val canvasHeight: Float,
    val showWireframe: Boolean
)
