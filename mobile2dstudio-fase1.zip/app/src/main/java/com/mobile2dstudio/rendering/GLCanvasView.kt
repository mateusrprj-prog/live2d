package com.mobile2dstudio.rendering

import android.content.Context
import android.opengl.GLSurfaceView
import android.view.MotionEvent
import android.view.ScaleGestureDetector

/**
 * View do canvas acelerado por GPU. Gestos (temporários até as ferramentas da Fase 2):
 *  - 1 dedo: arrasta o canvas;
 *  - 2 dedos: pinça = zoom no ponto de foco, e o deslocamento do foco move o canvas.
 */
class GLCanvasView(context: Context) : GLSurfaceView(context) {
    private val meshRenderer = MeshRenderer()
    private var lastX = 0f
    private var lastY = 0f
    private var lastFocusX = 0f
    private var lastFocusY = 0f

    private val scaleDetector = ScaleGestureDetector(
        context,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScaleBegin(detector: ScaleGestureDetector): Boolean {
                lastFocusX = detector.focusX
                lastFocusY = detector.focusY
                return true
            }

            override fun onScale(detector: ScaleGestureDetector): Boolean {
                val fx = detector.focusX
                val fy = detector.focusY
                val dx = fx - lastFocusX
                val dy = fy - lastFocusY
                lastFocusX = fx
                lastFocusY = fy
                val factor = detector.scaleFactor
                update {
                    camera.panByScreen(dx, dy)
                    camera.zoomAt(factor, fx, fy)
                }
                return true
            }
        }
    )

    init {
        setEGLContextClientVersion(3)
        preserveEGLContextOnPause = true
        setRenderer(meshRenderer)
        renderMode = RENDERMODE_WHEN_DIRTY
    }

    /** Executa [block] na thread do GL e redesenha. */
    fun update(block: MeshRenderer.() -> Unit) {
        queueEvent {
            meshRenderer.block()
            requestRender()
        }
    }

    fun fitToCanvas() {
        update { requestFit() }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(event)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = event.x
                lastY = event.y
            }
            MotionEvent.ACTION_POINTER_UP -> {
                // Evita salto: passa a acompanhar o dedo que restou.
                val remaining = if (event.actionIndex == 0) 1 else 0
                lastX = event.getX(remaining)
                lastY = event.getY(remaining)
            }
            MotionEvent.ACTION_MOVE -> {
                if (event.pointerCount == 1 && !scaleDetector.isInProgress) {
                    val dx = event.x - lastX
                    val dy = event.y - lastY
                    lastX = event.x
                    lastY = event.y
                    if (dx != 0f || dy != 0f) update { camera.panByScreen(dx, dy) }
                }
            }
        }
        return true
    }
}
