package com.mobile2dstudio.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.mobile2dstudio.project.Part
import com.mobile2dstudio.project.ProjectFactory
import com.mobile2dstudio.project.ProjectRepository
import com.mobile2dstudio.project.V2dProject
import com.mobile2dstudio.rendering.GLCanvasView
import com.mobile2dstudio.rendering.RenderPart
import com.mobile2dstudio.rendering.RenderScene
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(repository: ProjectRepository, projectId: String, onClose: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val glView = remember { GLCanvasView(context) }
    val saveMutex = remember { Mutex() }

    var project by remember { mutableStateOf<V2dProject?>(null) }
    var loadError by remember { mutableStateOf<String?>(null) }
    var dirty by remember { mutableStateOf(false) }
    var showWire by remember { mutableStateOf(true) }
    var showLayers by remember { mutableStateOf(true) }
    var status by remember { mutableStateOf("") }

    LaunchedEffect(projectId) {
        try {
            project = withContext(Dispatchers.IO) { repository.load(projectId) }
        } catch (e: Exception) {
            loadError = e.message ?: "Falha ao abrir o projeto"
        }
    }

    suspend fun save(): Boolean {
        val snapshot = project ?: return true
        return saveMutex.withLock {
            try {
                val saved = withContext(Dispatchers.IO) { repository.save(snapshot) }
                project = project?.copy(meta = saved.meta)
                // Só considera "limpo" se nada mudou durante o salvamento.
                if (project?.parts === snapshot.parts) dirty = false
                status = "Salvo"
                true
            } catch (e: Exception) {
                status = "Erro ao salvar: ${e.message}"
                false
            }
        }
    }

    fun closeAfterSave() {
        scope.launch {
            if (!dirty || save()) onClose()
        }
    }

    fun mutateParts(change: (List<Part>) -> List<Part>) {
        val current = project ?: return
        project = current.copy(parts = change(current.parts))
        dirty = true
    }

    BackHandler { closeAfterSave() }

    // Autosave periódico (não bloqueia a edição: roda em IO).
    LaunchedEffect(Unit) {
        while (true) {
            delay(20_000)
            if (dirty && save()) status = "Autosave concluído"
        }
    }

    // Ciclo de vida do GLSurfaceView + salvar ao sair do app.
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner, glView) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME -> glView.onResume()
                Lifecycle.Event.ON_PAUSE -> glView.onPause()
                Lifecycle.Event.ON_STOP -> scope.launch { if (dirty) save() }
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            glView.onPause()
        }
    }

    // Envia o estado do projeto para o renderer.
    val current = project
    LaunchedEffect(current?.parts, current?.meta?.width, current?.meta?.height, showWire) {
        val p = current ?: return@LaunchedEffect
        val scene = RenderScene(
            parts = p.parts.mapNotNull { part -> part.mesh?.let { RenderPart(part.id, it, part.visible) } },
            canvasWidth = p.meta.width.toFloat(),
            canvasHeight = p.meta.height.toFloat(),
            showWireframe = showWire
        )
        glView.update { setScene(scene) }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(current?.meta?.name ?: "Abrindo…", maxLines = 1) },
                navigationIcon = {
                    IconButton(onClick = { closeAfterSave() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Voltar")
                    }
                }
            )
        },
        bottomBar = {
            Surface(tonalElevation = 3.dp) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .navigationBarsPadding()
                        .padding(horizontal = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    TextButton(onClick = { glView.fitToCanvas() }) { Text("Ajustar") }
                    TextButton(onClick = { showWire = !showWire }) {
                        Text(if (showWire) "Malha: ligada" else "Malha: oculta")
                    }
                    TextButton(onClick = { showLayers = !showLayers }) { Text("Camadas") }
                    TextButton(
                        enabled = current != null,
                        onClick = {
                            val p = project ?: return@TextButton
                            mutateParts { parts ->
                                parts + ProjectFactory.testPart(p.meta.width, p.meta.height, parts.size)
                            }
                        }
                    ) { Text("+ Parte de teste") }
                    TextButton(enabled = current != null, onClick = { scope.launch { save() } }) { Text("Salvar") }
                }
            }
        }
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            AndroidView(factory = { glView }, modifier = Modifier.fillMaxSize())

            if (current != null && showLayers) {
                LayersPanel(
                    parts = current.parts,
                    modifier = Modifier.align(Alignment.TopEnd).padding(8.dp),
                    onVisibleChange = { id, visible ->
                        mutateParts { parts -> parts.map { if (it.id == id) it.copy(visible = visible) else it } }
                    },
                    onDelete = { id -> mutateParts { parts -> parts.filter { it.id != id } } }
                )
            }

            if (current != null) {
                val vertices = current.parts.sumOf { it.mesh?.vertexCount ?: 0 }
                val triangles = current.parts.sumOf { it.mesh?.triangleCount ?: 0 }
                Surface(
                    modifier = Modifier.align(Alignment.BottomStart).padding(8.dp),
                    shape = MaterialTheme.shapes.small,
                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.85f)
                ) {
                    Text(
                        buildString {
                            append("${current.parts.size} partes • $vertices vértices • $triangles triângulos")
                            if (dirty) append(" • não salvo")
                            if (status.isNotEmpty()) append(" • $status")
                        },
                        modifier = Modifier.padding(8.dp),
                        style = MaterialTheme.typography.labelMedium
                    )
                }
            }

            loadError?.let { message ->
                Surface(
                    modifier = Modifier.align(Alignment.Center).padding(24.dp),
                    shape = MaterialTheme.shapes.medium,
                    color = MaterialTheme.colorScheme.errorContainer
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Text(message, color = MaterialTheme.colorScheme.onErrorContainer)
                        TextButton(onClick = onClose) { Text("Voltar à lista") }
                    }
                }
            }
        }
    }
}

@Composable
private fun LayersPanel(
    parts: List<Part>,
    modifier: Modifier,
    onVisibleChange: (id: String, visible: Boolean) -> Unit,
    onDelete: (id: String) -> Unit
) {
    Surface(
        modifier = modifier.width(240.dp),
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.92f),
        tonalElevation = 4.dp
    ) {
        Column(Modifier.padding(8.dp)) {
            Text("Camadas (${parts.size})", style = MaterialTheme.typography.titleSmall)
            if (parts.isEmpty()) {
                Text("Nenhuma parte. Use “+ Parte de teste”.", style = MaterialTheme.typography.bodySmall)
            }
            LazyColumn(Modifier.heightIn(max = 320.dp)) {
                items(parts, key = { it.id }) { part ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = part.visible, onCheckedChange = { onVisibleChange(part.id, it) })
                        Text(part.name, Modifier.weight(1f), maxLines = 1, style = MaterialTheme.typography.bodyMedium)
                        IconButton(onClick = { onDelete(part.id) }) {
                            Icon(Icons.Default.Delete, contentDescription = "Excluir ${part.name}")
                        }
                    }
                }
            }
        }
    }
}
