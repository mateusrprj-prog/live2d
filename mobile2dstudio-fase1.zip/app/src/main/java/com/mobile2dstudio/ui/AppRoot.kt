package com.mobile2dstudio.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import com.mobile2dstudio.project.ProjectRepository

@Composable
fun AppRoot(repository: ProjectRepository) {
    var openId by rememberSaveable { mutableStateOf<String?>(null) }
    val id = openId
    if (id == null) {
        ProjectListScreen(repository, onOpen = { openId = it })
    } else {
        EditorScreen(repository, id, onClose = { openId = null })
    }
}
