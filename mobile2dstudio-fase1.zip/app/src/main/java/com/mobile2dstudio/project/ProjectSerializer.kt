package com.mobile2dstudio.project

import com.mobile2dstudio.mesh.ArtMesh
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject

/** Converte projeto <-> JSON (conteúdo de project.json dentro do .v2d). */
object ProjectSerializer {

    fun toJson(project: V2dProject): String {
        val root = JSONObject()
        root.put("schemaVersion", CURRENT_SCHEMA)
        root.put("generator", "Mobile 2D Studio")
        root.put("meta", metaToJson(project.meta))
        val parts = JSONArray()
        for (p in project.parts) parts.put(partToJson(p))
        root.put("parts", parts)
        return root.toString()
    }

    fun fromJson(text: String): V2dProject {
        try {
            val root = migrate(JSONObject(text))
            val meta = metaFromJson(root.getJSONObject("meta"))
            val partsJson = root.getJSONArray("parts")
            val parts = ArrayList<Part>(partsJson.length())
            for (i in 0 until partsJson.length()) parts += partFromJson(partsJson.getJSONObject(i))
            return V2dProject(meta, parts)
        } catch (e: JSONException) {
            throw ProjectFormatException("Arquivo de projeto inválido: ${e.message}", e)
        }
    }

    fun metaFromJson(text: String): ProjectMeta {
        try {
            val root = migrate(JSONObject(text))
            return metaFromJson(root.getJSONObject("meta"))
        } catch (e: JSONException) {
            throw ProjectFormatException("Arquivo de projeto inválido: ${e.message}", e)
        }
    }

    /** Ponto único para migrações entre versões do esquema. */
    private fun migrate(root: JSONObject): JSONObject {
        val version = root.optInt("schemaVersion", -1)
        if (version < 1) throw ProjectFormatException("Projeto sem versão de esquema válida")
        if (version > CURRENT_SCHEMA) {
            throw ProjectFormatException(
                "Projeto criado por uma versão mais nova do app (esquema $version, suportado até $CURRENT_SCHEMA)"
            )
        }
        // Esquema 1 é o atual; migrações futuras entram aqui (version -> version + 1).
        return root
    }

    private fun metaToJson(m: ProjectMeta): JSONObject {
        val o = JSONObject()
        o.put("id", m.id)
        o.put("name", m.name)
        o.put("createdAt", m.createdAt)
        o.put("modifiedAt", m.modifiedAt)
        o.put("width", m.width)
        o.put("height", m.height)
        o.put("fps", m.fps)
        return o
    }

    private fun metaFromJson(o: JSONObject) = ProjectMeta(
        id = o.getString("id"),
        name = o.getString("name"),
        createdAt = o.getLong("createdAt"),
        modifiedAt = o.getLong("modifiedAt"),
        width = o.getInt("width"),
        height = o.getInt("height"),
        fps = o.getInt("fps")
    )

    private fun partToJson(p: Part): JSONObject {
        val o = JSONObject()
        o.put("id", p.id)
        o.put("name", p.name)
        o.put("parentId", p.parentId ?: JSONObject.NULL)
        o.put("visible", p.visible)
        o.put("locked", p.locked)
        val mesh = p.mesh
        if (mesh == null) {
            o.put("mesh", JSONObject.NULL)
        } else {
            val problems = mesh.validate()
            if (problems.isNotEmpty()) {
                throw ProjectFormatException("Malha inválida na parte '${p.name}': ${problems.joinToString("; ")}")
            }
            val m = JSONObject()
            m.put("positions", floatsToJson(mesh.positions))
            m.put("uvs", floatsToJson(mesh.uvs))
            m.put("indices", intsToJson(mesh.indices))
            o.put("mesh", m)
        }
        return o
    }

    private fun partFromJson(o: JSONObject): Part {
        var mesh: ArtMesh? = null
        if (!o.isNull("mesh")) {
            val m = o.getJSONObject("mesh")
            val parsed = ArtMesh(
                positions = jsonToFloats(m.getJSONArray("positions")),
                uvs = jsonToFloats(m.getJSONArray("uvs")),
                indices = jsonToInts(m.getJSONArray("indices"))
            )
            val problems = parsed.validate()
            if (problems.isNotEmpty()) {
                throw ProjectFormatException(
                    "Malha inválida na parte '${o.optString("name")}': ${problems.joinToString("; ")}"
                )
            }
            mesh = parsed
        }
        return Part(
            id = o.getString("id"),
            name = o.getString("name"),
            parentId = if (o.isNull("parentId")) null else o.getString("parentId"),
            visible = o.getBoolean("visible"),
            locked = o.getBoolean("locked"),
            mesh = mesh
        )
    }

    private fun floatsToJson(a: FloatArray): JSONArray {
        val j = JSONArray()
        for (v in a) j.put(v.toDouble())
        return j
    }

    private fun intsToJson(a: IntArray): JSONArray {
        val j = JSONArray()
        for (v in a) j.put(v)
        return j
    }

    private fun jsonToFloats(j: JSONArray) = FloatArray(j.length()) { j.getDouble(it).toFloat() }

    private fun jsonToInts(j: JSONArray) = IntArray(j.length()) { j.getInt(it) }
}
