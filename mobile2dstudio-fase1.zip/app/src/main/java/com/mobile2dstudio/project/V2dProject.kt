package com.mobile2dstudio.project

import com.mobile2dstudio.mesh.ArtMesh
import com.mobile2dstudio.mesh.MeshGenerator
import java.util.UUID

/** Versão atual do esquema do arquivo .v2d. */
const val CURRENT_SCHEMA = 1

data class ProjectMeta(
    val id: String,
    val name: String,
    val createdAt: Long,
    val modifiedAt: Long,
    val width: Int,
    val height: Int,
    val fps: Int
)

/** Parte do personagem. Na Fase 1 a lista é plana (parentId ainda não é usado pela UI). */
data class Part(
    val id: String,
    val name: String,
    val parentId: String?,
    val visible: Boolean,
    val locked: Boolean,
    val mesh: ArtMesh?
)

data class V2dProject(val meta: ProjectMeta, val parts: List<Part>)

data class ProjectInfo(val meta: ProjectMeta, val sizeBytes: Long)

class ProjectFormatException(message: String, cause: Throwable? = null) : Exception(message, cause)

object ProjectFactory {
    /**
     * Parte de teste com malha em grade 8x8 (textura de teste gerada pelo renderer).
     * Existe só para exercitar o pipeline de malha/GPU até a importação (Fase 2).
     */
    fun testPart(canvasWidth: Int, canvasHeight: Int, index: Int): Part {
        val size = minOf(canvasWidth, canvasHeight) * 0.4f
        val shift = index * size * 0.15f
        val mesh = MeshGenerator.grid(size, size, 8, 8, -size / 2f + shift, -size / 2f - shift)
        return Part(
            id = UUID.randomUUID().toString(),
            name = "Parte de teste ${index + 1}",
            parentId = null,
            visible = true,
            locked = false,
            mesh = mesh
        )
    }
}
