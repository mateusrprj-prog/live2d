# Changelog

## 0.1.0 — Fase 1 (fundação)
- Projeto Android (Kotlin, Compose, Material 3), minSdk 26, compile/target 35.
- Renderer OpenGL ES 3.0: malhas com VAO/VBO, textura de teste, wireframe, contorno do canvas,
  recriação de recursos após perda de contexto, atualização de posições sem recriar buffers.
- Câmera 2D (pan, zoom em ponto de foco, ajustar) com conversão mundo<->tela testada.
- ArtMesh + gerador de malha em grade + validação (índices, degenerados, UVs).
- Formato `.v2d` (ZIP + project.json, esquema versionado), gravação atômica, backup `.bak`,
  recuperação do backup, listagem ignorando arquivos corrompidos.
- Gerenciador de projetos: criar, abrir, renomear, duplicar, excluir, salvar, autosave (20 s) e
  salvamento ao sair do app; FPS e resolução configuráveis.
- Editor: canvas GPU, painel de camadas simples (visibilidade, excluir), "+ Parte de teste".
- Testes unitários: câmera, malha, serialização, repositório.
- GitHub Actions: testes + APK Debug como artifact.
